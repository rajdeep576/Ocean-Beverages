import 'package:supabase_flutter/supabase_flutter.dart';

class StorageHelper {
  // Utility to transform storage path to public URL
  static String getPublicUrl(String? path, String bucket, String placeholder) {
    if (path == null || path.isEmpty) return placeholder;
    if (path.startsWith('http')) return path; // Already an absolute URL

    return Supabase.instance.client.storage.from(bucket).getPublicUrl(path);
  }
}

class Artist {
  final String id;
  final String name;
  final String heroImageUrl;

  Artist({required this.id, required this.name, required this.heroImageUrl});

  factory Artist.fromJson(Map<String, dynamic> json) {
    return Artist(
      id: json['id'] ?? '',
      name: json['name'] ?? 'Unknown Artist',
      heroImageUrl: StorageHelper.getPublicUrl(
        json['hero_image_url'],
        'artist-images',
        'https://picsum.photos/600/600',
      ),
    );
  }
}

class Album {
  final String id;
  final String title;
  final String coverUrl;
  final String? genre;
  final int? releaseYear;
  final Artist? artist;

  Album({
    required this.id,
    required this.title,
    required this.coverUrl,
    this.genre,
    this.releaseYear,
    this.artist,
  });

  factory Album.fromJson(Map<String, dynamic> json) {
    // PostgREST returns a to-one embed as a map and a to-many embed as a list.
    final nestedArtist = json['artists'];

    // release_year may come back as an int or, from some clients, a string.
    final rawYear = json['release_year'];
    int? year;
    if (rawYear is int) {
      year = rawYear;
    } else if (rawYear is String) {
      year = int.tryParse(rawYear);
    }

    return Album(
      id: json['id'] ?? '',
      title: json['title'] ?? 'Untitled Album',
      coverUrl: StorageHelper.getPublicUrl(
        json['cover_url'],
        'album-covers',
        'https://picsum.photos/600/600',
      ),
      genre: json['genre'] as String?,
      releaseYear: year,
      artist: nestedArtist is Map
          ? Artist.fromJson(Map<String, dynamic>.from(nestedArtist))
          : null,
    );
  }
}

class Song {
  final String id;
  final String title;
  final String audioUrl;
  final String? coverUrl;
  final String? artistName;

  /// Track length in seconds as stored in `songs.duration_seconds`.
  final int? durationSeconds;

  /// The album this track belongs to, populated by queries that embed it.
  final Album? album;

  final bool isPublished;

  /// Whether the row actually carried an `is_published` value.
  ///
  /// Distinct from [isPublished] because the column comes from
  /// supabase/admin_setup.sql and does not exist until it is applied. While it
  /// is missing every row decodes to `isPublished == false`, which would
  /// label the entire seeded catalogue "Draft" — so the Manage Songs screen
  /// uses this to show one setup notice instead of a list of false statuses.
  final bool hasPublishingColumn;

  final String? createdBy;

  /// Bucket-relative path of the audio object, e.g. `songs/<uuid>/audio.mp3`.
  ///
  /// NULL for seeded tracks, whose `audio_url` is an absolute external URL
  /// (SoundHelix). [audioUrl] is what the player streams; this is only for
  /// removing the object from storage when an uploaded track is deleted.
  final String? audioPath;

  /// Bucket-relative path of the cover art, same caveat as [audioPath].
  final String? coverPath;

  Song({
    required this.id,
    required this.title,
    required this.audioUrl,
    this.coverUrl,
    this.artistName,
    this.durationSeconds,
    this.album,
    this.isPublished = false,
    this.hasPublishingColumn = false,
    this.createdBy,
    this.audioPath,
    this.coverPath,
  });

  /// The track this song came from, as shown next to a queue row.
  String? get albumTitle => album?.title;

  /// "3:08" — falls back to an em dash when the length is unknown.
  String get durationLabel {
    final seconds = durationSeconds;
    if (seconds == null || seconds <= 0) return '--:--';
    final minutes = seconds ~/ 60;
    final remainder = seconds % 60;
    return '$minutes:${remainder.toString().padLeft(2, '0')}';
  }

  factory Song.fromJson(Map<String, dynamic> json) {
    // Parse nested album cover if present. PostgREST returns a to-one embed as
    // a map and a to-many embed as a list, so handle both without throwing.
    Map<String, dynamic>? albumJson;
    String? cover;
    final nestedAlbum = json['albums'];
    if (nestedAlbum is Map && nestedAlbum['cover_url'] != null) {
      albumJson = Map<String, dynamic>.from(nestedAlbum);
      cover = nestedAlbum['cover_url'];
    } else if (nestedAlbum is List && nestedAlbum.isNotEmpty) {
      final first = nestedAlbum.first;
      if (first is Map && first['cover_url'] != null) {
        albumJson = Map<String, dynamic>.from(first);
        cover = first['cover_url'];
      }
    } else if (json['cover_url'] != null) {
      cover = json['cover_url'];
    }

    // Parse nested artist name if present. PostgREST can embed the artist
    // directly (songs -> artists) or via the album (songs -> albums ->
    // artists), so accept both shapes.
    String? artist;
    if (json['artists'] != null && json['artists']['name'] != null) {
      artist = json['artists']['name'];
    } else if (json['albums'] != null &&
        json['albums']['artists'] != null &&
        json['albums']['artists']['name'] != null) {
      artist = json['albums']['artists']['name'];
    } else if (json['artist_name'] != null) {
      artist = json['artist_name'];
    }

    // duration_seconds may arrive as an int or a numeric string.
    final rawDuration = json['duration_seconds'];
    int? durationSeconds;
    if (rawDuration is int) {
      durationSeconds = rawDuration;
    } else if (rawDuration is num) {
      durationSeconds = rawDuration.toInt();
    } else if (rawDuration is String) {
      durationSeconds = int.tryParse(rawDuration);
    }

    return Song(
      id: json['id'] ?? '',
      title: json['title'] ?? 'Untitled Track',
      audioUrl: StorageHelper.getPublicUrl(
        json['audio_url'],
        'audio-files',
        '',
      ),
      coverUrl: cover != null
          ? StorageHelper.getPublicUrl(
              cover,
              'album-covers',
              'https://picsum.photos/600/600',
            )
          : null,
      artistName: artist ?? 'Unknown Artist',
      durationSeconds: durationSeconds,
      // Rebuild the embedded album so it carries title/genre/year too. Skip it
      // when the caller only selected cover_url, or Album.fromJson would
      // invent an "Untitled Album" for a row that simply didn't ask for one.
      album: albumJson != null && albumJson['title'] != null
          ? Album.fromJson(albumJson)
          : null,
      isPublished: json['is_published'] == true,
      hasPublishingColumn: json.containsKey('is_published'),
      createdBy: json['created_by']?.toString(),
      audioPath: json['audio_path']?.toString(),
      coverPath: json['cover_path']?.toString(),
    );
  }
}

class Playlist {
  final String id;
  final String title;
  final String coverUrl;

  Playlist({required this.id, required this.title, required this.coverUrl});

  factory Playlist.fromJson(Map<String, dynamic> json) {
    return Playlist(
      id: json['id'] ?? '',
      title: json['title'] ?? 'Untitled Playlist',
      coverUrl: StorageHelper.getPublicUrl(
        json['cover_url'],
        'album-covers',
        'https://picsum.photos/600/600',
      ),
    );
  }
}
