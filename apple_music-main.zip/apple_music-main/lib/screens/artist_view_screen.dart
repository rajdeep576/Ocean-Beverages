import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:snortify/providers/playback_provider.dart';
import 'package:snortify/models/music_models.dart';
import 'package:snortify/widgets/add_to_playlist_sheet.dart';
import 'package:snortify/widgets/favorite_button.dart';
import 'package:snortify/layout_breakpoints.dart';

class ArtistViewScreen extends StatefulWidget {
  final Artist artist;
  final List<Song>? topSongs;
  final List<Album>? albums;

  const ArtistViewScreen({
    super.key,
    required this.artist,
    this.topSongs,
    this.albums,
  });

  @override
  State<ArtistViewScreen> createState() => _ArtistViewScreenState();
}

class _ArtistViewScreenState extends State<ArtistViewScreen> {
  late List<Song> _topSongs;
  late List<Album> _albums;
  bool _isFavorite = false;

  @override
  void initState() {
    super.initState();
    _topSongs = widget.topSongs ?? [];
    _albums = widget.albums ?? [];
    _loadArtistData();
  }

  Future<void> _loadArtistData() async {
    // Load additional artist data if needed
    // This can be expanded to fetch more detailed artist info from Supabase
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        final narrow = isMobileWidth(width);
        // A 380px hero with a 48px name and four actions only fits a wide
        // window. On a phone the hero, the name and the action row all scale
        // down, and the two content columns stack instead of sitting side by
        // side with a 56px gutter between them.
        final heroHeight = narrow ? 300.0 : 380.0;
        final gutter = pageGutter(width);

        return Scaffold(
          backgroundColor: const Color(0xFF1A1A1A),
          body: CustomScrollView(
            slivers: [
              // Hero Banner with Artist Info
              SliverAppBar(
                expandedHeight: heroHeight,
                pinned: false,
                backgroundColor: const Color(0xFF1A1A1A),
                flexibleSpace: FlexibleSpaceBar(
                  background: Stack(
                    children: [
                      // Banner Image
                      Image.network(
                        widget.artist.heroImageUrl,
                        fit: BoxFit.cover,
                        width: double.infinity,
                        height: heroHeight,
                        errorBuilder: (context, error, stackTrace) => Container(
                          color: Colors.grey[800],
                          child: Center(
                            child: Icon(
                              Icons.person,
                              color: Colors.white54,
                              size: narrow ? 80 : 120,
                            ),
                          ),
                        ),
                      ),

                      // Bottom gradient overlay
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.transparent,
                              Colors.black.withValues(alpha: 0.3),
                              Colors.black.withValues(alpha: 0.7),
                              const Color(0xFF1A1A1A),
                            ],
                          ),
                        ),
                      ),

                      // Artist Name and Action Buttons (bottom-left)
                      Positioned(
                        bottom: narrow ? 20 : 32,
                        left: gutter,
                        right: gutter,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            // Artist Name
                            Text(
                              widget.artist.name.toUpperCase(),
                              style: TextStyle(
                                fontSize: narrow ? 28 : 48,
                                fontWeight: FontWeight.w900,
                                color: Colors.white,
                                letterSpacing: narrow ? 0.6 : 1.2,
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),

                            SizedBox(height: narrow ? 14 : 24),

                            // Action Button Row: Play, Shuffle, Favorite.
                            // Play and Shuffle shrink; the two icon buttons
                            // take a fixed 40dp target. Nothing here is allowed
                            // to size to its content, because four controls
                            // overflow a 360dp row otherwise.
                            Row(
                              children: [
                                Flexible(
                                  child: _buildActionButton(
                                    icon: Icons.play_circle_filled,
                                    label: 'Play',
                                    onPressed: () {
                                      // Play artist's top songs
                                      if (_topSongs.isNotEmpty) {
                                        context
                                            .read<PlaybackProvider>()
                                            .playQueue(_topSongs, 0);
                                      }
                                    },
                                    isPrimary: true,
                                    compact: narrow,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Flexible(
                                  child: _buildActionButton(
                                    icon: Icons.shuffle,
                                    label: 'Shuffle',
                                    onPressed: () {
                                      // Shuffle play artist's songs
                                      if (_topSongs.isNotEmpty) {
                                        _topSongs.shuffle();
                                        context
                                            .read<PlaybackProvider>()
                                            .playQueue(_topSongs, 0);
                                      }
                                    },
                                    compact: narrow,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                _buildIconButton(
                                  icon: _isFavorite
                                      ? Icons.favorite
                                      : Icons.favorite_border,
                                  onPressed: () {
                                    setState(() => _isFavorite = !_isFavorite);
                                  },
                                  tooltip: 'Favorite Artist',
                                  compact: narrow,
                                ),
                                const SizedBox(width: 12),
                                _buildIconButton(
                                  icon: Icons.more_horiz,
                                  onPressed: () {},
                                  tooltip: 'More Options',
                                  compact: narrow,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // Two-Column Content: Top Songs (left) + Latest Release /
              // Essential Albums (right). Below 600px the columns stack —
              // a 3:2 split of a 360dp page leaves 90px for a whole column.
              SliverPadding(
                padding: pagePadding(width, top: 24, bottom: 32),
                sliver: SliverToBoxAdapter(
                  child: narrow
                      ? Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _buildTopSongsColumn(),
                            const SizedBox(height: 40),
                            _buildAlbumsColumn(),
                          ],
                        )
                      : Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          spacing: 56,
                          children: [
                            Expanded(flex: 3, child: _buildTopSongsColumn()),
                            Expanded(flex: 2, child: _buildAlbumsColumn()),
                          ],
                        ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  /// Top Songs column: the numbered tracklist.
  Widget _buildTopSongsColumn() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Top Songs',
          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
            color: Colors.white,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 24),
        if (_topSongs.isEmpty)
          Container(
            padding: const EdgeInsets.all(32),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.05),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Center(
              child: Text(
                'No songs available',
                style: TextStyle(color: Colors.white54),
              ),
            ),
          )
        else
          Column(
            children: List.generate(
              _topSongs.length,
              (index) => _buildTopSongTile(_topSongs[index], index + 1),
            ),
          ),
      ],
    );
  }

  /// Right column: the latest release plus the remaining albums, two-up.
  Widget _buildAlbumsColumn() {
    final narrow = MediaQuery.sizeOf(context).width < 600;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Latest Release',
          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
            color: Colors.white,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 24),
        if (_albums.isNotEmpty)
          _buildAlbumCard(_albums.first)
        else
          _emptyNote('No albums available'),
        const SizedBox(height: 48),
        Text(
          'Essential Albums',
          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
            color: Colors.white,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 24),
        if (_albums.length <= 1)
          _emptyNote('No additional albums')
        else
          // One album per row on a phone: two 1:1 covers plus a 24px gutter
          // need 360px, which a 328dp content column does not have.
          LayoutBuilder(
            builder: (context, constraints) {
              final perRow = narrow
                  ? 1
                  : gridColumnCount(
                      constraints.maxWidth,
                      minItemWidth: 150,
                      spacing: 24,
                      min: 1,
                      max: 2,
                    );
              final remaining = _albums.length - 1;
              final rows = (remaining + perRow - 1) ~/ perRow;

              return Column(
                children: List.generate(rows, (rowIndex) {
                  final start = 1 + rowIndex * perRow;
                  final end = (start + perRow).clamp(0, _albums.length);
                  final rowAlbums = _albums.sublist(start, end);

                  return Padding(
                    padding: EdgeInsets.only(
                      bottom: rowIndex == rows - 1 ? 0 : 24,
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      spacing: 24,
                      children: [
                        for (final album in rowAlbums)
                          Expanded(child: _buildAlbumCard(album)),
                        // Keeps a half-filled final row's cards the same width
                        // as every other card instead of stretching them.
                        for (int i = rowAlbums.length; i < perRow; i++)
                          const Expanded(child: SizedBox.shrink()),
                      ],
                    ),
                  );
                }),
              );
            },
          ),
      ],
    );
  }

  Widget _emptyNote(String message) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Center(
        child: Text(
          message,
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.white54),
        ),
      ),
    );
  }

  /// Builds a top song tile with row actions (Download, Favorite, More)
  ///
  /// The three trailing actions are 48dp each; with the 48dp rank tile and a
  /// title they overflow a 360dp row, so the row drops the download button
  /// below the phone breakpoint.
  Widget _buildTopSongTile(Song song, int index) {
    final narrow = MediaQuery.sizeOf(context).width < 600;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: Material(
        color: Colors.white.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(8),
        clipBehavior: Clip.antiAlias,
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 8,
          ),
          leading: Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(4),
            ),
            child: Center(
              child: Text(
                '$index',
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
          title: Text(
            song.title,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w500,
              fontSize: 15,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          subtitle: Text(
            song.artistName ?? 'Unknown Artist',
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.6),
              fontSize: 13,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            spacing: 8,
            children: [
              if (!narrow)
                _buildIconButton(
                  icon: Icons.download_outlined,
                  onPressed: () {},
                  tooltip: 'Download',
                ),
              FavoriteButton(songId: song.id, iconSize: 20),
              _buildIconButton(
                icon: Icons.more_horiz,
                compact: narrow,
                onPressed: () => showAddToPlaylistSheet(
                  context,
                  songId: song.id,
                  songTitle: song.title,
                ),
                tooltip: 'Add to Playlist',
              ),
            ],
          ),
          onTap: () {
            // Play this song
            context.read<PlaybackProvider>().playSong(song);
          },
        ),
      ),
    );
  }

  /// Builds an album card with cover image and metadata
  Widget _buildAlbumCard(Album album) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: () {
          // Navigate to album detail
        },
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            color: Colors.white.withValues(alpha: 0.05),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Album Cover
              ClipRRect(
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(12),
                ),
                child: AspectRatio(
                  aspectRatio: 1,
                  child: Image.network(
                    album.coverUrl,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) => Container(
                      color: Colors.grey[800],
                      child: const Center(
                        child: Icon(
                          Icons.album,
                          color: Colors.white54,
                          size: 60,
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              // Album Metadata
              Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      album.title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 15,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      album.artist?.name ?? 'Unknown Artist',
                      style: TextStyle(
                        color: Colors.white.withValues(alpha: 0.6),
                        fontSize: 13,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Builds a primary or secondary action button (Play, Shuffle)
  ///
  /// [compact] tightens the padding and label so both buttons fit beside the
  /// two icon buttons on a phone; `ElevatedButton.icon`'s default horizontal
  /// padding is 32px a side, which alone is wider than a 320dp row can spare.
  Widget _buildActionButton({
    required IconData icon,
    required String label,
    required VoidCallback onPressed,
    bool isPrimary = false,
    bool compact = false,
  }) {
    return ElevatedButton.icon(
      onPressed: onPressed,
      icon: Icon(icon, size: compact ? 18 : 20),
      label: Text(
        label,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(fontSize: compact ? 13 : null),
      ),
      style: ElevatedButton.styleFrom(
        backgroundColor: isPrimary
            ? Colors.white
            : Colors.white.withValues(alpha: 0.2),
        foregroundColor: isPrimary ? Colors.black : Colors.white,
        padding: EdgeInsets.symmetric(
          horizontal: compact ? 12 : 20,
          vertical: compact ? 8 : 12,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        elevation: isPrimary ? 4 : 0,
      ),
    );
  }

  /// Builds an icon button with tooltip
  Widget _buildIconButton({
    required IconData icon,
    required VoidCallback onPressed,
    String tooltip = '',
    bool compact = false,
  }) {
    return Tooltip(
      message: tooltip,
      child: IconButton(
        icon: Icon(icon, color: Colors.white, size: 20),
        onPressed: onPressed,
        splashRadius: 24,
        hoverColor: Colors.white.withValues(alpha: 0.1),
        // IconButton insists on a 48dp target, which is fine on its own but
        // not next to three more controls in a phone-width row.
        padding: EdgeInsets.zero,
        constraints: BoxConstraints.tightFor(
          width: compact ? 40 : 48,
          height: compact ? 40 : 48,
        ),
      ),
    );
  }
}
