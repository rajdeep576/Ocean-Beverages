import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:snortify/models/music_models.dart';
import 'package:snortify/providers/playback_provider.dart';
import 'package:snortify/repository/music_repository.dart';
import 'package:snortify/screens/album_detail_screen.dart';
import 'package:snortify/widgets/content_shelf.dart';
import 'package:snortify/widgets/song_list_item.dart';
import 'package:snortify/layout_breakpoints.dart';

/// Browse tab: genre tiles, new releases, and a charts shelf.
///
/// Every shelf fetches from Supabase; genre tiles are derived from the genres
/// actually present in the catalogue rather than a hardcoded list.
class BrowseScreen extends StatefulWidget {
  const BrowseScreen({super.key});

  @override
  State<BrowseScreen> createState() => _BrowseScreenState();
}

class _BrowseScreenState extends State<BrowseScreen> {
  final MusicRepository _repository = MusicRepository();

  late Future<List<Album>> _newReleases;
  late Future<List<String>> _genres;
  late Future<List<Song>> _topSongs;

  @override
  void initState() {
    super.initState();
    _loadAll();
  }

  void _loadAll() {
    setState(() {
      _newReleases = _repository.fetchNewReleases();
      _genres = _repository.fetchGenres();
      _topSongs = _repository.fetchTopSongs();
    });
  }

  Future<void> _playSongs(List<Song> songs, int index) async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      await context.read<PlaybackProvider>().playQueue(songs, index);
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('Could not play: $e')));
    }
  }

  void _openAlbum(Album album) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => AlbumDetailScreen(album: album)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;

        return Scaffold(
          backgroundColor: const Color(0xFF121212),
          body: RefreshIndicator(
            onRefresh: () async => _loadAll(),
            color: Colors.white,
            backgroundColor: const Color(0xFF2C2C2E),
            child: ListView(
              padding: pagePadding(
                width,
                // No AppBar on this scaffold, so the "Browse" heading has to
                // clear the status bar itself.
                top: pageTopInset(context, base: 24),
                bottom: 24,
              ),
              children: [
                Text(
                  'Browse',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: isMobileWidth(width) ? 28 : 34,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 28),

                // Genre tiles
                FutureBuilder<List<String>>(
                  future: _genres,
                  builder: (context, snapshot) {
                    final genres = snapshot.data ?? const <String>[];
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return _GenreSkeleton(
                        columns: isMobileWidth(width) ? 2 : 4,
                      );
                    }
                    if (snapshot.hasError || genres.isEmpty) {
                      return const SizedBox.shrink();
                    }
                    return _buildGenreGrid(genres);
                  },
                ),
                const SizedBox(height: 40),

                // New releases
                FutureBuilder<List<Album>>(
                  future: _newReleases,
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const _ShelfSkeleton(height: 226);
                    }
                    if (snapshot.hasError) {
                      return _ShelfError(onRetry: _loadAll);
                    }
                    final albums = snapshot.data ?? const <Album>[];
                    if (albums.isEmpty) return const SizedBox.shrink();

                    return ContentShelf(
                      title: 'New Releases',
                      itemCount: albums.length,
                      itemBuilder: (context, index) {
                        final album = albums[index];
                        return ShelfTile(
                          title: album.title,
                          subtitle: album.artist?.name,
                          networkUrl: album.coverUrl,
                          onTap: () => _openAlbum(album),
                        );
                      },
                    );
                  },
                ),
                const SizedBox(height: 40),

                // Charts. Rows rather than a shelf of tiles, because a song
                // needs its "…" menu to be actionable — a ShelfTile is just
                // artwork and a label.
                FutureBuilder<List<Song>>(
                  future: _topSongs,
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const _ShelfSkeleton(height: 226);
                    }
                    if (snapshot.hasError) {
                      return _ShelfError(onRetry: _loadAll);
                    }
                    final songs = snapshot.data ?? const <Song>[];
                    if (songs.isEmpty) return const SizedBox.shrink();

                    return Consumer<PlaybackProvider>(
                      builder: (context, playback, _) => Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Top Songs',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          const Text(
                            'Most played across the catalogue',
                            style: TextStyle(
                              color: Colors.white38,
                              fontSize: 12,
                            ),
                          ),
                          const SizedBox(height: 14),
                          for (int index = 0; index < songs.length; index++)
                            SongListItem(
                              trackNumber: index + 1,
                              title: songs[index].title,
                              songId: songs[index].id,
                              duration: songs[index].durationLabel,
                              isActive:
                                  playback.currentSong?.id == songs[index].id &&
                                  playback.isPlaying,
                              onTap: () => _playSongs(songs, index),
                            ),
                        ],
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildGenreGrid(List<String> genres) {
    // Colour is derived from the genre name so a tile keeps the same colour
    // between launches without storing a mapping.
    const palette = [
      Color(0xFFFA2D48),
      Color(0xFFF93F9B),
      Color(0xFF7B4FE0),
      Color(0xFF2D8CF0),
      Color(0xFF00B3A4),
      Color(0xFF6B7A8F),
    ];

    return LayoutBuilder(
      builder: (context, constraints) {
        const spacing = 16.0;
        // The old `clamp(2, 6)` forced two columns even when a tile was 60px
        // wide, which pushed the text past the tile edge.
        final columns = gridColumnCount(
          constraints.maxWidth,
          minItemWidth: 150,
          spacing: spacing,
          min: 1,
          max: 6,
        );
        final tileWidth =
            (constraints.maxWidth - spacing * (columns - 1)) / columns;

        return Wrap(
          spacing: spacing,
          runSpacing: spacing,
          children: [
            for (int i = 0; i < genres.length; i++)
              SizedBox(
                width: tileWidth,
                height: 88,
                child: _GenreTile(
                  genre: genres[i],
                  color: palette[genres[i].hashCode.abs() % palette.length],
                  onTap: () => _showGenre(genres[i]),
                ),
              ),
          ],
        );
      },
    );
  }

  void _showGenre(String genre) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF1C1C1E),
      isScrollControlled: true,
      builder: (sheetContext) => _GenreSheet(genre: genre),
    );
  }
}

class _GenreSheet extends StatefulWidget {
  final String genre;

  const _GenreSheet({required this.genre});

  @override
  State<_GenreSheet> createState() => _GenreSheetState();
}

class _GenreSheetState extends State<_GenreSheet> {
  late final Future<List<Album>> _albums = MusicRepository().fetchAlbumsByGenre(
    widget.genre,
  );

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.6,
      maxChildSize: 0.9,
      builder: (context, scrollController) {
        return Column(
          children: [
            const SizedBox(height: 12),
            Container(
              width: 36,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 12),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      widget.genre,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: FutureBuilder<List<Album>>(
                future: _albums,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(
                      child: CircularProgressIndicator(color: Colors.white24),
                    );
                  }
                  if (snapshot.hasError) {
                    return const Center(
                      child: Text(
                        "Couldn't load this genre",
                        style: TextStyle(color: Colors.white54),
                      ),
                    );
                  }

                  final albums = snapshot.data ?? const <Album>[];
                  if (albums.isEmpty) {
                    return const Center(
                      child: Text(
                        'Nothing here yet',
                        style: TextStyle(color: Colors.white54),
                      ),
                    );
                  }

                  return LayoutBuilder(
                    builder: (context, constraints) {
                      // Three columns of album tiles overflowed a phone-width
                      // sheet; the count follows the sheet's own width.
                      const spacing = 20.0;
                      final columns = gridColumnCount(
                        constraints.maxWidth - 48,
                        minItemWidth: 130,
                        spacing: spacing,
                        min: 2,
                        max: 3,
                      );
                      // Sized from the cell width rather than a fixed 0.8,
                      // which left the title's second line clipped.
                      final tileWidth = gridTileWidth(
                        constraints.maxWidth - 48,
                        columns,
                        spacing: spacing,
                      );

                      return GridView.builder(
                        controller: scrollController,
                        padding: const EdgeInsets.fromLTRB(24, 0, 24, 32),
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: columns,
                          childAspectRatio: tileChildAspectRatio(tileWidth),
                          crossAxisSpacing: spacing,
                          mainAxisSpacing: spacing,
                        ),
                        itemCount: albums.length,
                        itemBuilder: (context, index) {
                          final album = albums[index];
                          return ShelfTile(
                            title: album.title,
                            subtitle: album.artist?.name,
                            networkUrl: album.coverUrl,
                            onTap: () {
                              Navigator.of(context).pop();
                              Navigator.of(context).push(
                                MaterialPageRoute<void>(
                                  builder: (_) =>
                                      AlbumDetailScreen(album: album),
                                ),
                              );
                            },
                          );
                        },
                      );
                    },
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }
}

class _GenreTile extends StatelessWidget {
  final String genre;
  final Color color;
  final VoidCallback onTap;

  const _GenreTile({
    required this.genre,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      child: GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: Container(
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(12),
          ),
          padding: const EdgeInsets.all(14),
          alignment: Alignment.bottomLeft,
          child: Text(
            genre,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ),
    );
  }
}

class _ShelfSkeleton extends StatelessWidget {
  final double height;

  const _ShelfSkeleton({required this.height});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          for (int i = 0; i < 3; i++) ...[
            Expanded(
              child: Container(
                height: height - 46,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.05),
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            if (i < 2) const SizedBox(width: 18),
          ],
        ],
      ),
    );
  }
}

class _GenreSkeleton extends StatelessWidget {
  final int columns;

  const _GenreSkeleton({required this.columns});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        for (int i = 0; i < 2; i++) ...[
          Row(
            children: [
              for (int j = 0; j < columns; j++) ...[
                Expanded(
                  child: Container(
                    height: 88,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.05),
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                if (j < columns - 1) const SizedBox(width: 16),
              ],
            ],
          ),
          if (i == 0) const SizedBox(height: 16),
        ],
      ],
    );
  }
}

class _ShelfError extends StatelessWidget {
  final VoidCallback onRetry;

  const _ShelfError({required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 160,
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              "Couldn't load this shelf",
              style: TextStyle(color: Colors.white54, fontSize: 14),
            ),
            const SizedBox(height: 10),
            OutlinedButton(
              onPressed: onRetry,
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.white,
                side: const BorderSide(color: Colors.white24),
              ),
              child: const Text('Try Again'),
            ),
          ],
        ),
      ),
    );
  }
}
