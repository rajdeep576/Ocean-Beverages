import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:snortify/models/music_models.dart';
import 'package:snortify/providers/favorites_provider.dart';
import 'package:snortify/providers/playback_provider.dart';
import 'package:snortify/repository/music_repository.dart';
import 'package:snortify/screens/artist_view_screen.dart';
import 'package:snortify/screens/playlist_detail_screen.dart';
import 'package:snortify/widgets/artwork_image.dart';
import 'package:snortify/widgets/song_list_item.dart';
import 'package:snortify/screens/album_detail_screen.dart';
import 'package:snortify/screens/tabs/search_screen.dart';
import 'package:snortify/screens/tabs/library_screen.dart'
    show LibrarySection;
import 'package:snortify/layout_breakpoints.dart';

/// The phone layout for the Library tab.
///
/// Single column: a compact header with back arrow and the sort / layout /
/// search actions, then a two-up grid of square composite cards for Pins and
/// Playlists, then the favourites list as full-width rows.
class MobileLibraryView extends StatefulWidget {
  final LibrarySection section;

  const MobileLibraryView({super.key, required this.section});

  @override
  State<MobileLibraryView> createState() => _MobileLibraryViewState();
}

enum _LibraryLayout { grid, list }

enum _SortOrder { recentlyAdded, alphabetical, trackCount }

class _MobileLibraryViewState extends State<MobileLibraryView> {
  final MusicRepository _repository = MusicRepository();

  late Future<List<Playlist>> _playlists;
  late Future<Map<String, int>> _playlistCounts;
  late Future<List<Song>> _favorites;
  late Future<List<Artist>> _artists;
  late Future<List<Album>> _albums;

  _LibraryLayout _layout = _LibraryLayout.grid;
  _SortOrder _sort = _SortOrder.recentlyAdded;

  /// Re-pulls the favourites next frame when a heart is toggled elsewhere — the
  /// mini player, an album tracklist, the artist page.
  Set<String> _lastFavoritesSnapshot = const {};

  @override
  void initState() {
    super.initState();
    _loadAll();
  }

  @override
  void didUpdateWidget(MobileLibraryView oldWidget) {
    super.didUpdateWidget(oldWidget);
    // The layout reuses one Library instance across sections, so a new section
    // has to be pushed in rather than remounted.
    if (oldWidget.section != widget.section) _loadAll();
  }

  void _loadAll() {
    setState(() {
      _playlists = _repository.fetchUserPlaylists();
      _playlistCounts = _repository.fetchPlaylistSongCounts();
      _favorites = _repository.fetchFavoriteSongs();
      _artists = _repository.fetchAllArtists();
      _albums = _repository.fetchNewReleases(limit: 50);
    });
  }

  String get _heading => switch (widget.section) {
    LibrarySection.playlists => 'Library',
    LibrarySection.songs => 'Songs',
    LibrarySection.artists => 'Artists',
    LibrarySection.albums => 'Albums',
  };

  Future<void> _play(List<Song> songs, int index) async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      await context.read<PlaybackProvider>().playQueue(songs, index);
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('Could not play: $e')));
    }
  }

  Future<void> _removeFavorite(Song song) async {
    final messenger = ScaffoldMessenger.of(context);
    // Un-heart through the shared provider so every other heart on screen
    // clears at the same moment, then re-pull the row out of the list.
    final result = await context.read<FavoritesProvider>().toggle(song.id);
    if (result != false) {
      messenger.showSnackBar(
        SnackBar(content: Text("Couldn't update ${song.title}")),
      );
      return;
    }
    messenger.showSnackBar(
      SnackBar(content: Text('Removed ${song.title} from Favourites')),
    );
    _loadAll();
  }

  void _scheduleFavoritesReload(FavoritesProvider favorites) {
    final snapshot = favorites.favoriteIds;
    if (snapshot == _lastFavoritesSnapshot) return;
    _lastFavoritesSnapshot = snapshot;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _loadAll();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<FavoritesProvider>(
      builder: (context, favorites, _) {
        _scheduleFavoritesReload(favorites);

        return RefreshIndicator(
          onRefresh: () async => _loadAll(),
          color: Colors.white,
          backgroundColor: const Color(0xFF2C2C2E),
          child: ListView(
            // Bottom padding clears the mini player and nav pill that float
            // over the content in the mobile shell; the top padding clears the
            // status bar, which this screen's back arrow and heading would
            // otherwise sit under.
            padding: pagePadding(
              MediaQuery.sizeOf(context).width,
              top: pageTopInset(context, base: 8),
              bottom: 24,
            ),
            children: [
              _buildHeader(),
              const SizedBox(height: 16),
              if (widget.section == LibrarySection.playlists) ...[
                _buildPinsGrid(),
                const SizedBox(height: 28),
                _buildPlaylistsGrid(),
                const SizedBox(height: 32),
                _buildFavorites(),
              ] else if (widget.section == LibrarySection.songs)
                _buildFavorites()
              else if (widget.section == LibrarySection.artists)
                _buildArtists()
              else
                _buildAlbums(),
            ],
          ),
        );
      },
    );
  }

  Widget _buildHeader() {
    // A back arrow, a 26px heading and three 48dp actions do not fit a 320dp
    // phone. The heading is the elastic child, the actions shrink to a 40dp
    // tap target, and the whole group drops to a shorter title if even that
    // leaves the heading under ~80px.
    return LayoutBuilder(
      builder: (context, constraints) {
        final tight = constraints.maxWidth < 360;
        return Row(
          children: [
            IconButton(
              iconSize: 22,
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
              icon: const Icon(
                Icons.arrow_back_ios_new,
                color: Colors.white,
                size: 18,
              ),
              onPressed: () => Navigator.of(context).maybePop(),
              tooltip: 'Back',
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                _heading,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: tight ? 20 : 26,
                  fontWeight: FontWeight.bold,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            _HeaderAction(
              icon: Icons.swap_vert,
              tooltip: 'Sort',
              onPressed: _showSortSheet,
            ),
            _HeaderAction(
              icon: _layout == _LibraryLayout.grid
                  ? Icons.view_agenda_outlined
                  : Icons.grid_view_rounded,
              tooltip: _layout == _LibraryLayout.grid
                  ? 'List layout'
                  : 'Grid layout',
              onPressed: () => setState(() {
                _layout = _layout == _LibraryLayout.grid
                    ? _LibraryLayout.list
                    : _LibraryLayout.grid;
              }),
            ),
            _HeaderAction(
              icon: Icons.search,
              tooltip: 'Search',
              onPressed: () => _openSearch(context),
            ),
          ],
        );
      },
    );
  }

  void _showSortSheet() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF1C1C1E),
      builder: (sheetContext) => SafeArea(
        child: RadioGroup<_SortOrder>(
          groupValue: _sort,
          onChanged: (value) {
            if (value == null) return;
            Navigator.of(sheetContext).pop();
            setState(() => _sort = value);
          },
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              for (final option in _SortOrder.values)
                RadioListTile<_SortOrder>(
                  value: option,
                  activeColor: const Color(0xFFFA2D48),
                  title: Text(switch (option) {
                    _SortOrder.recentlyAdded => 'Recently Added',
                    _SortOrder.alphabetical => 'Alphabetical',
                    _SortOrder.trackCount => 'Track Count',
                  }, style: const TextStyle(color: Colors.white, fontSize: 15)),
                ),
            ],
          ),
        ),
      ),
    );
  }

  /// Opens the app's search screen rather than duplicating its UI here.
  void _openSearch(BuildContext context) {
    Navigator.of(
      context,
    ).push(MaterialPageRoute<void>(builder: (_) => const SearchScreen()));
  }

  /// Sorts playlists by the current [_sort], falling back to album order when
  /// two playlists tie.
  List<Playlist> _sorted(List<Playlist> playlists, Map<String, int> counts) {
    final sorted = List<Playlist>.of(playlists);
    switch (_sort) {
      case _SortOrder.recentlyAdded:
        break;
      case _SortOrder.alphabetical:
        sorted.sort(
          (a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()),
        );
      case _SortOrder.trackCount:
        sorted.sort((a, b) => (counts[b.id] ?? 0).compareTo(counts[a.id] ?? 0));
    }
    return sorted;
  }

  Widget _buildPinsGrid() {
    return _SectionGrid(
      title: 'Pins',
      itemCount: 2,
      itemBuilder: (context, index) => const _CompositeCard(
        title: 'Recently Added',
        subtitle: '12 Songs',
        gradient: [Color(0xFFFA2D48), Color(0xFF831010)],
        icon: Icons.push_pin,
      ),
    );
  }

  Widget _buildPlaylistsGrid() {
    return FutureBuilder<List<Playlist>>(
      future: _playlists,
      builder: (context, playlistSnapshot) {
        if (playlistSnapshot.connectionState == ConnectionState.waiting) {
          return const _SectionGridSkeleton(title: 'Playlists');
        }
        if (playlistSnapshot.hasError) {
          return _ErrorCard(
            message: "${playlistSnapshot.error}",
            onRetry: _loadAll,
          );
        }

        final countsFuture = _playlistCounts;
        return FutureBuilder<Map<String, int>>(
          future: countsFuture,
          builder: (context, countSnapshot) {
            final playlists = _sorted(
              playlistSnapshot.data ?? const <Playlist>[],
              countSnapshot.data ?? const {},
            );

            if (playlists.isEmpty) {
              return const _EmptySection(
                title: 'Playlists',
                message: 'Playlists you create will show up here.',
              );
            }

            return _SectionGrid(
              title: 'Playlists',
              itemCount: playlists.length,
              itemBuilder: (context, index) {
                final playlist = playlists[index];
                final count = countSnapshot.data?[playlist.id];

                return _CompositeCard(
                  title: playlist.title,
                  subtitle: count == null ? null : '$count Songs',
                  networkUrl: playlist.coverUrl,
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => PlaylistDetailScreen(playlist: playlist),
                    ),
                  ),
                );
              },
            );
          },
        );
      },
    );
  }

  Widget _buildFavorites() {
    return FutureBuilder<List<Song>>(
      future: _favorites,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const _SectionSkeleton(title: 'Songs');
        }
        if (snapshot.hasError) {
          return _ErrorCard(message: "${snapshot.error}", onRetry: _loadAll);
        }

        final songs = snapshot.data ?? const <Song>[];
        if (songs.isEmpty) {
          return const _EmptySection(
            title: 'Songs',
            message: 'Tap the heart on any track to add it here.',
          );
        }

        final totalMinutes =
            songs.fold<int>(
              0,
              (sum, song) => sum + (song.durationSeconds ?? 0),
            ) ~/
            60;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'Songs',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Text(
                  '${songs.length} songs'
                  '${totalMinutes > 0 ? ', $totalMinutes min' : ''}',
                  style: const TextStyle(color: Colors.white38, fontSize: 12),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Consumer<PlaybackProvider>(
              builder: (context, playback, _) => Column(
                children: [
                  for (int index = 0; index < songs.length; index++)
                    Dismissible(
                      key: ValueKey(songs[index].id),
                      direction: DismissDirection.endToStart,
                      background: Container(
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 20),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFA2D48),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.favorite, color: Colors.white),
                      ),
                      onDismissed: (_) => _removeFavorite(songs[index]),
                      child: SongListItem(
                        trackNumber: index + 1,
                        title: songs[index].title,
                        songId: songs[index].id,
                        duration: songs[index].durationLabel,
                        isActive:
                            playback.currentSong?.id == songs[index].id &&
                            playback.isPlaying,
                        onTap: () => _play(songs, index),
                      ),
                    ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildArtists() {
    return FutureBuilder<List<Artist>>(
      future: _artists,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const _SectionGridSkeleton(title: 'Artists');
        }
        if (snapshot.hasError) {
          return _ErrorCard(message: "${snapshot.error}", onRetry: _loadAll);
        }

        final artists = snapshot.data ?? const <Artist>[];
        if (artists.isEmpty) {
          return const _EmptySection(
            title: 'Artists',
            message: 'Artists you follow will show up here.',
          );
        }

        return _SectionGrid(
          title: 'Artists',
          itemCount: artists.length,
          itemBuilder: (context, index) {
            final artist = artists[index];
            return _CompositeCard(
              title: artist.name,
              networkUrl: artist.heroImageUrl,
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => ArtistViewScreen(artist: artist),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildAlbums() {
    return FutureBuilder<List<Album>>(
      future: _albums,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const _SectionGridSkeleton(title: 'Albums');
        }
        if (snapshot.hasError) {
          return _ErrorCard(message: "${snapshot.error}", onRetry: _loadAll);
        }

        final albums = snapshot.data ?? const <Album>[];
        if (albums.isEmpty) {
          return const _EmptySection(
            title: 'Albums',
            message: 'Albums you save will show up here.',
          );
        }

        return _SectionGrid(
          title: 'Albums',
          itemCount: albums.length,
          itemBuilder: (context, index) {
            final album = albums[index];
            return _CompositeCard(
              title: album.title,
              subtitle: album.artist?.name,
              networkUrl: album.coverUrl,
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => AlbumDetailScreen(album: album),
                ),
              ),
            );
          },
        );
      },
    );
  }
}

class _HeaderAction extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final VoidCallback onPressed;

  const _HeaderAction({
    required this.icon,
    required this.tooltip,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    // Three of these sit beside a heading in a header row — 40dp keeps the row
    // inside a 320dp viewport where IconButton's 48dp default does not.
    return SizedBox(
      width: 40,
      height: 40,
      child: IconButton(
        iconSize: 20,
        color: Colors.white70,
        tooltip: tooltip,
        padding: EdgeInsets.zero,
        constraints: const BoxConstraints.tightFor(width: 40, height: 40),
        icon: Icon(icon),
        onPressed: onPressed,
      ),
    );
  }
}

/// A titled two-up grid of [itemBuilder] cards.
class _SectionGrid extends StatelessWidget {
  final String title;
  final int itemCount;
  final Widget Function(BuildContext context, int index) itemBuilder;

  const _SectionGrid({
    required this.title,
    required this.itemCount,
    required this.itemBuilder,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          padding: EdgeInsets.zero,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            // 1:1 cards, matching the composite artwork the design uses.
            childAspectRatio: 1,
          ),
          itemCount: itemCount,
          itemBuilder: itemBuilder,
        ),
      ],
    );
  }
}

/// A square card: cover art (or a gradient) with the title and track count
/// overlaid along the bottom edge.
class _CompositeCard extends StatelessWidget {
  final String title;
  final String? subtitle;
  final String? networkUrl;
  final List<Color>? gradient;
  final IconData? icon;
  final VoidCallback? onTap;

  const _CompositeCard({
    required this.title,
    this.subtitle,
    this.networkUrl,
    this.gradient,
    this.icon,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (networkUrl != null)
              ArtworkImage(networkUrl: networkUrl!)
            else
              DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors:
                        gradient ??
                        const [Color(0xFF3A3A3C), Color(0xFF1C1C1E)],
                  ),
                ),
                child: icon == null
                    ? null
                    : Icon(icon, color: Colors.white38, size: 36),
              ),

            // Scrim so the label stays readable over bright artwork.
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.center,
                  end: Alignment.bottomCenter,
                  colors: [Colors.transparent, Color(0xCC000000)],
                ),
              ),
            ),

            Positioned(
              left: 10,
              right: 10,
              bottom: 8,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (subtitle != null)
                    Text(
                      subtitle!,
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 11,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionGridSkeleton extends StatelessWidget {
  final String title;

  const _SectionGridSkeleton({required this.title});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          padding: EdgeInsets.zero,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 1,
          children: List.generate(
            4,
            (_) => Container(
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.05),
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _SectionSkeleton extends StatelessWidget {
  final String title;

  const _SectionSkeleton({required this.title});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        for (int i = 0; i < 5; i++)
          Container(
            height: 46,
            margin: const EdgeInsets.symmetric(vertical: 4),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.05),
              borderRadius: BorderRadius.circular(6),
            ),
          ),
      ],
    );
  }
}

class _EmptySection extends StatelessWidget {
  final String title;
  final String message;

  const _EmptySection({required this.title, required this.message});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          message,
          style: const TextStyle(color: Colors.white38, fontSize: 13),
        ),
      ],
    );
  }
}

class _ErrorCard extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;

  const _ErrorCard({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.04),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Couldn't load your library",
            style: TextStyle(
              color: Colors.white,
              fontSize: 15,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            message,
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Colors.white38, fontSize: 12),
          ),
          const SizedBox(height: 12),
          OutlinedButton(
            onPressed: onRetry,
            style: OutlinedButton.styleFrom(
              foregroundColor: Colors.white,
              side: const BorderSide(color: Colors.white24),
            ),
            child: const Text('Try Again'),
          ),
        ],
      ),
    );
  }
}
