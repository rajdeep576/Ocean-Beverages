import 'package:flutter/material.dart';
import 'package:snortify/screens/tabs/base_screen.dart';

class RadioScreen extends StatelessWidget {
  const RadioScreen({super.key});

  @override
  Widget build(BuildContext context) => const BaseScreen(title: 'Radio');
}
