import 'package:flutter/material.dart';
import 'package:snortify/models/music_models.dart';
import 'package:snortify/repository/music_repository.dart';
import 'package:snortify/screens/artist_view_screen.dart';
import 'package:provider/provider.dart';
import 'package:snortify/providers/playback_provider.dart';
import 'package:snortify/layout_breakpoints.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _searchController = TextEditingController();
  final MusicRepository _repository = MusicRepository();

  List<Song> _songs = [];
  List<Album> _albums = [];
  List<Artist> _artists = [];

  bool _isLoading = false;
  String _lastQuery = '';

  @override
  void initState() {
    super.initState();
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _onSearchChanged() async {
    final query = _searchController.text;

    // Debounce: only search if query changed and wait a bit
    if (query == _lastQuery) return;
    _lastQuery = query;

    if (query.isEmpty) {
      setState(() {
        _songs = [];
        _albums = [];
        _artists = [];
        _isLoading = false;
      });
      return;
    }

    // Small delay to avoid excessive queries while typing
    await Future.delayed(const Duration(milliseconds: 300));

    if (!mounted) return;

    setState(() => _isLoading = true);

    try {
      final results = await _repository.searchAll(query);
      if (mounted) {
        setState(() {
          _songs = results['songs'] as List<Song>;
          _albums = results['albums'] as List<Album>;
          _artists = results['artists'] as List<Artist>;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Search failed: $e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final hasResults =
        _songs.isNotEmpty || _albums.isNotEmpty || _artists.isNotEmpty;
    final isEmpty = _searchController.text.isEmpty;

    return Scaffold(
      backgroundColor: const Color(0xFF1A1A1A),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final width = constraints.maxWidth;

          return Column(
            children: [
              // Search Input Bar
              Padding(
                padding: pagePadding(
                  width,
                  // No AppBar on this scaffold, so the search field has to
                  // clear the status bar itself.
                  top: pageTopInset(context, base: 16),
                  bottom: 8,
                ),
                child: _buildSearchBar(width),
              ),

              // Results Content
              Expanded(
                child: isEmpty
                    ? _buildEmptyState()
                    : _isLoading
                    ? _buildLoadingState()
                    : hasResults
                    ? _buildResults(width)
                    : _buildNoResultsState(),
              ),
            ],
          );
        },
      ),
    );
  }

  /// Search input field with clear button
  Widget _buildSearchBar(double width) {
    final narrow = isMobileWidth(width);
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withValues(alpha: 0.12)),
      ),
      child: TextField(
        controller: _searchController,
        style: const TextStyle(color: Colors.white, fontSize: 16),
        decoration: InputDecoration(
          hintText: narrow
              ? 'Search music'
              : 'Search for artists, songs, or albums',
          hintStyle: TextStyle(
            color: Colors.white.withValues(alpha: 0.5),
            fontSize: 15,
          ),
          prefixIcon: Icon(
            Icons.search,
            color: Colors.white.withValues(alpha: 0.6),
            size: 20,
          ),
          suffixIcon: _searchController.text.isNotEmpty
              ? GestureDetector(
                  onTap: () {
                    _searchController.clear();
                    setState(() {
                      _songs = [];
                      _albums = [];
                      _artists = [];
                    });
                  },
                  child: Icon(
                    Icons.close,
                    color: Colors.white.withValues(alpha: 0.6),
                    size: 20,
                  ),
                )
              : null,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 12),
        ),
      ),
    );
  }

  /// Empty state placeholder
  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.search,
            size: 80,
            color: Colors.white.withValues(alpha: 0.2),
          ),
          const SizedBox(height: 24),
          Text(
            'Search for artists, songs, or albums',
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.5),
              fontSize: 18,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Start typing to discover music',
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.3),
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  /// Loading state indicator
  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 48,
            height: 48,
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation(
                Colors.white.withValues(alpha: 0.7),
              ),
              strokeWidth: 2,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'Searching...',
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.6),
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }

  /// No results found state
  Widget _buildNoResultsState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.music_note_outlined,
            size: 80,
            color: Colors.white.withValues(alpha: 0.2),
          ),
          const SizedBox(height: 24),
          Text(
            'No results found',
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.6),
              fontSize: 18,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Try searching with different keywords',
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.3),
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  /// Main results view with categorized sections
  Widget _buildResults(double width) {
    final narrow = isMobileWidth(width);
    return ListView(
      padding: pagePadding(width, top: 16, bottom: 32),
      children: [
        // Top Result Card (best match)
        if (_artists.isNotEmpty || _albums.isNotEmpty)
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Top Result',
                style: Theme.of(context).textTheme.labelLarge?.copyWith(
                  color: Colors.white.withValues(alpha: 0.6),
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.5,
                ),
              ),
              const SizedBox(height: 16),
              if (_artists.isNotEmpty)
                _buildTopResultArtistCard(_artists.first, width)
              else
                _buildTopResultAlbumCard(_albums.first, width),
              const SizedBox(height: 48),
            ],
          ),

        // Songs Section
        if (_songs.isNotEmpty) ...[
          Text(
            'Songs',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              color: Colors.white,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 16),
          ..._songs.asMap().entries.map((entry) {
            final song = entry.value;
            return _buildSongTile(song);
          }),
          const SizedBox(height: 48),
        ],

        // Albums Section
        if (_albums.isNotEmpty) ...[
          Text(
            'Albums',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              color: Colors.white,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            // A 160px card plus its two-line label needs 250px; the strip used
            // to be pinned at 220px, which clipped the bottom of every card.
            height: narrow ? 232 : 250,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: _albums.length,
              itemBuilder: (context, index) => Padding(
                padding: EdgeInsets.only(
                  right: index == _albums.length - 1 ? 0 : 16,
                ),
                child: _buildAlbumCard(_albums[index], narrow),
              ),
            ),
          ),
          const SizedBox(height: 48),
        ],

        // Artists Section
        if (_artists.isNotEmpty) ...[
          Text(
            'Artists',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              color: Colors.white,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            // 140px avatar + 12px gap + two lines of name, with slack for a
            // large system font.
            height: narrow ? 212 : 224,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: _artists.length,
              itemBuilder: (context, index) => Padding(
                padding: EdgeInsets.only(
                  right: index == _artists.length - 1 ? 0 : 16,
                ),
                child: _buildArtistCard(_artists[index], narrow),
              ),
            ),
          ),
        ],
      ],
    );
  }

  /// Top result artist card (prominent feature)
  Widget _buildTopResultArtistCard(Artist artist, double width) {
    final narrow = isMobileWidth(width);
    final art = narrow ? 64.0 : 100.0;
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ArtistViewScreen(artist: artist),
          ),
        );
      },
      child: Container(
        padding: EdgeInsets.all(narrow ? 14 : 24),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withValues(alpha: 0.12)),
        ),
        child: Row(
          children: [
            // Artist Avatar
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.network(
                artist.heroImageUrl,
                width: art,
                height: art,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) => Container(
                  width: art,
                  height: art,
                  decoration: BoxDecoration(
                    color: Colors.grey[800],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: Icon(
                      Icons.person,
                      color: Colors.white54,
                      size: art / 2,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(width: narrow ? 14 : 24),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Artist',
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.6),
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    artist.name,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.w700,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            Icon(
              Icons.chevron_right,
              color: Colors.white.withValues(alpha: 0.4),
              size: 24,
            ),
          ],
        ),
      ),
    );
  }

  /// Top result album card (prominent feature)
  Widget _buildTopResultAlbumCard(Album album, double width) {
    final narrow = isMobileWidth(width);
    final art = narrow ? 64.0 : 100.0;
    return GestureDetector(
      onTap: () {
        // Navigate to album detail
      },
      child: Container(
        padding: EdgeInsets.all(narrow ? 14 : 24),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withValues(alpha: 0.12)),
        ),
        child: Row(
          children: [
            // Album Cover
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.network(
                album.coverUrl,
                width: art,
                height: art,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) => Container(
                  width: art,
                  height: art,
                  decoration: BoxDecoration(
                    color: Colors.grey[800],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: Icon(
                      Icons.album,
                      color: Colors.white54,
                      size: art / 2,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(width: narrow ? 14 : 24),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Album',
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.6),
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    album.title,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: narrow ? 19 : 24,
                      fontWeight: FontWeight.w700,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    album.artist?.name ?? 'Unknown Artist',
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.6),
                      fontSize: 14,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            Icon(
              Icons.chevron_right,
              color: Colors.white.withValues(alpha: 0.4),
              size: 24,
            ),
          ],
        ),
      ),
    );
  }

  /// Individual song tile with play button (FIXED: Material wraps ListTile)
  Widget _buildSongTile(Song song) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: Material(
        color: Colors.white.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(8),
        clipBehavior: Clip.antiAlias,
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 6,
          ),
          leading: ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: Container(
              width: 48,
              height: 48,
              color: Colors.grey[800],
              child: song.coverUrl != null
                  ? Image.network(
                      song.coverUrl!,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) =>
                          const Center(
                            child: Icon(
                              Icons.music_note,
                              color: Colors.white54,
                              size: 24,
                            ),
                          ),
                    )
                  : const Center(
                      child: Icon(
                        Icons.music_note,
                        color: Colors.white54,
                        size: 24,
                      ),
                    ),
            ),
          ),
          title: Text(
            song.title,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w500,
              fontSize: 15,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          subtitle: Text(
            song.artistName ?? 'Unknown Artist',
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.6),
              fontSize: 13,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          trailing: IconButton(
            icon: Icon(
              Icons.play_circle_filled,
              color: Colors.white.withValues(alpha: 0.7),
              size: 24,
            ),
            onPressed: () {
              context.read<PlaybackProvider>().playSong(song);
            },
            tooltip: 'Play',
          ),
          onTap: () {
            context.read<PlaybackProvider>().playSong(song);
          },
        ),
      ),
    );
  }

  /// Album card for horizontal scrolling view
  Widget _buildAlbumCard(Album album, bool narrow) {
    return GestureDetector(
      onTap: () {
        // Navigate to album detail
      },
      child: Container(
        width: narrow ? 140 : 160,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: Colors.white.withValues(alpha: 0.05),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Album Cover
            ClipRRect(
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(12),
              ),
              child: AspectRatio(
                aspectRatio: 1,
                child: Image.network(
                  album.coverUrl,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => Container(
                    color: Colors.grey[800],
                    child: const Center(
                      child: Icon(Icons.album, color: Colors.white54, size: 40),
                    ),
                  ),
                ),
              ),
            ),
            // Album Info
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    album.title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 14,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    album.artist?.name ?? 'Unknown Artist',
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.6),
                      fontSize: 12,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Artist card for horizontal scrolling view (circular avatar)
  Widget _buildArtistCard(Artist artist, bool narrow) {
    final avatar = narrow ? 110.0 : 140.0;
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ArtistViewScreen(artist: artist),
          ),
        );
      },
      child: Column(
        children: [
          // Circular Avatar
          Container(
            width: avatar,
            height: avatar,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.1),
                width: 2,
              ),
            ),
            child: ClipOval(
              child: Image.network(
                artist.heroImageUrl,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) => Container(
                  color: Colors.grey[800],
                  child: Center(
                    child: Icon(
                      Icons.person,
                      color: Colors.white54,
                      size: avatar * 0.43,
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          // Artist Name
          SizedBox(
            width: narrow ? 140 : 160,
            child: Text(
              artist.name,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w600,
                fontSize: 14,
              ),
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}
