import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:snortify/models/music_models.dart';
import 'package:snortify/providers/playback_provider.dart';
import 'package:snortify/providers/favorites_provider.dart';
import 'package:snortify/repository/music_repository.dart';
import 'package:snortify/screens/album_detail_screen.dart';
import 'package:snortify/screens/artist_view_screen.dart';
import 'package:snortify/screens/playlist_detail_screen.dart';
import 'package:snortify/widgets/content_shelf.dart';
import 'package:snortify/widgets/song_list_item.dart';
import 'package:snortify/layout_breakpoints.dart';

/// Which slice of the library the screen is showing.
///
/// The sidebar routes "Songs", "Artists" and "Albums" here with a different
/// section, rather than duplicating a screen per item.
enum LibrarySection { playlists, songs, artists, albums }

/// Library tab: playlists and favourites, both scoped to the signed-in user.
class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key, this.section = LibrarySection.playlists});

  final LibrarySection section;

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  final MusicRepository _repository = MusicRepository();

  late Future<List<Playlist>> _playlists;
  late Future<List<Song>> _favorites;
  late Future<List<Album>> _albums;
  late Future<List<Artist>> _artists;

  @override
  void initState() {
    super.initState();
    _loadAll();
  }

  @override
  void didUpdateWidget(LibraryScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    // The sidebar reuses one Library instance across sections, so reload when
    // the sidebar switches which section is showing.
    if (oldWidget.section != widget.section) _loadAll();
  }

  void _loadAll() {
    setState(() {
      _playlists = _repository.fetchUserPlaylists();
      _favorites = _repository.fetchFavoriteSongs();
      _albums = _repository.fetchNewReleases(limit: 50);
      _artists = _repository.fetchAllArtists();
    });
  }

  bool get _isSignedIn => Supabase.instance.client.auth.currentUser != null;

  String get _heading => switch (widget.section) {
    LibrarySection.playlists => 'Library',
    LibrarySection.songs => 'Songs',
    LibrarySection.artists => 'Artists',
    LibrarySection.albums => 'Albums',
  };

  Future<void> _play(List<Song> songs, int index) async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      await context.read<PlaybackProvider>().playQueue(songs, index);
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('Could not play: $e')));
    }
  }

  Future<void> _removeFavorite(Song song) async {
    final messenger = ScaffoldMessenger.of(context);
    // Un-heart through the shared provider so every other heart on screen
    // clears at the same moment, then re-pull the row out of the list.
    final result = await context.read<FavoritesProvider>().toggle(song.id);
    if (result != false) {
      messenger.showSnackBar(
        SnackBar(content: Text("Couldn't update ${song.title}")),
      );
      return;
    }
    messenger.showSnackBar(
      SnackBar(content: Text('Removed ${song.title} from Favourites')),
    );
    _loadAll();
  }

  /// Re-fetches the favourites list the next frame when the favourited-id set
  /// changes. Deferred to a post-frame callback because this runs from build,
  /// and `setState` (which `_loadAll` uses) cannot be called during a build.
  void _scheduleFavoritesReload(FavoritesProvider favorites) {
    final snapshot = favorites.favoriteIds;
    if (snapshot == _lastFavoritesSnapshot) return;
    _lastFavoritesSnapshot = snapshot;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _loadAll();
    });
  }

  Set<String> _lastFavoritesSnapshot = const {};

  @override
  Widget build(BuildContext context) {
    // Re-pull the favourites whenever a heart is toggled anywhere else — the
    // mini player, an album tracklist, the artist page — so this list keeps up
    // without the user having to pull to refresh.
    return Consumer<FavoritesProvider>(
      builder: (context, favorites, _) {
        _scheduleFavoritesReload(favorites);

        return Scaffold(
          backgroundColor: const Color(0xFF121212),
          body: RefreshIndicator(
            onRefresh: () async => _loadAll(),
            color: Colors.white,
            backgroundColor: const Color(0xFF2C2C2E),
            child: ListView(
              padding: pagePadding(
                MediaQuery.sizeOf(context).width,
                // No AppBar on this scaffold, so the heading has to clear the
                // status bar itself.
                top: pageTopInset(context, base: 24),
                bottom: 140,
              ),
              children: [
                Text(
                  _heading,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: isMobileWidth(MediaQuery.sizeOf(context).width)
                        ? 28
                        : 34,
                    fontWeight: FontWeight.bold,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 24),

                if (!_isSignedIn)
                  const _SignInPrompt()
                else ...[
                  if (widget.section == LibrarySection.playlists) ...[
                    _buildPlaylists(),
                    const SizedBox(height: 40),
                    _buildFavorites(),
                  ] else if (widget.section == LibrarySection.songs)
                    _buildFavorites()
                  else if (widget.section == LibrarySection.artists)
                    _buildArtists()
                  else
                    _buildAlbums(),
                ],
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildPlaylists() {
    return FutureBuilder<List<Playlist>>(
      future: _playlists,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const _ShelfSkeleton();
        }
        if (snapshot.hasError) {
          return _LibraryError(message: "$snapshot.error", onRetry: _loadAll);
        }

        final playlists = snapshot.data ?? const <Playlist>[];
        if (playlists.isEmpty) {
          return const _EmptySection(
            title: 'Playlists',
            message: 'Playlists you create will show up here.',
          );
        }

        return ContentShelf(
          title: 'Playlists',
          itemCount: playlists.length,
          itemBuilder: (context, index) {
            final playlist = playlists[index];
            return ShelfTile(
              title: playlist.title,
              networkUrl: playlist.coverUrl,
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => PlaylistDetailScreen(playlist: playlist),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildFavorites() {
    return FutureBuilder<List<Song>>(
      future: _favorites,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const _ShelfSkeleton(height: 220);
        }
        if (snapshot.hasError) {
          return _LibraryError(message: "$snapshot.error", onRetry: _loadAll);
        }

        final songs = snapshot.data ?? const <Song>[];
        if (songs.isEmpty) {
          return const _EmptySection(
            title: 'Songs',
            message: 'Tap the heart on any track to add it here.',
          );
        }

        final totalMinutes =
            songs.fold<int>(
              0,
              (sum, song) => sum + (song.durationSeconds ?? 0),
            ) ~/
            60;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'Songs',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Text(
                  '${songs.length} songs'
                  '${totalMinutes > 0 ? ', $totalMinutes min' : ''}',
                  style: const TextStyle(color: Colors.white38, fontSize: 12),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Consumer<PlaybackProvider>(
              builder: (context, playback, _) => Column(
                children: [
                  for (int index = 0; index < songs.length; index++)
                    Dismissible(
                      key: ValueKey(songs[index].id),
                      direction: DismissDirection.endToStart,
                      background: Container(
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 24),
                        color: const Color(0xFFFA2D48),
                        child: const Icon(Icons.favorite, color: Colors.white),
                      ),
                      onDismissed: (_) => _removeFavorite(songs[index]),
                      child: SongListItem(
                        trackNumber: index + 1,
                        title: songs[index].title,
                        songId: songs[index].id,
                        duration: songs[index].durationLabel,
                        isActive:
                            playback.currentSong?.id == songs[index].id &&
                            playback.isPlaying,
                        onTap: () => _play(songs, index),
                      ),
                    ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildAlbums() {
    return FutureBuilder<List<Album>>(
      future: _albums,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const _ShelfSkeleton();
        }
        if (snapshot.hasError) {
          return _LibraryError(message: "$snapshot.error", onRetry: _loadAll);
        }

        final albums = snapshot.data ?? const <Album>[];
        if (albums.isEmpty) {
          return const _EmptySection(
            title: 'Albums',
            message: 'Albums you save will show up here.',
          );
        }

        return ContentShelf(
          title: 'Albums',
          subtitle: '${albums.length} in your library',
          itemCount: albums.length,
          itemBuilder: (context, index) {
            final album = albums[index];
            return ShelfTile(
              title: album.title,
              subtitle: album.artist?.name,
              networkUrl: album.coverUrl,
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => AlbumDetailScreen(album: album),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildArtists() {
    return FutureBuilder<List<Artist>>(
      future: _artists,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const _ShelfSkeleton();
        }
        if (snapshot.hasError) {
          return _LibraryError(message: "$snapshot.error", onRetry: _loadAll);
        }

        final artists = snapshot.data ?? const <Artist>[];
        if (artists.isEmpty) {
          return const _EmptySection(
            title: 'Artists',
            message: 'Artists you follow will show up here.',
          );
        }

        return ContentShelf(
          title: 'Artists',
          subtitle: '${artists.length} in your library',
          itemCount: artists.length,
          itemBuilder: (context, index) {
            final artist = artists[index];
            return ShelfTile(
              title: artist.name,
              networkUrl: artist.heroImageUrl,
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => ArtistViewScreen(artist: artist),
                ),
              ),
            );
          },
        );
      },
    );
  }
}

class _SignInPrompt extends StatelessWidget {
  const _SignInPrompt();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.04),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
      ),
      child: Column(
        children: [
          const Icon(Icons.person_outline, color: Colors.white38, size: 40),
          const SizedBox(height: 16),
          const Text(
            'Sign in to see your library',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Your playlists and favourites are tied to your Snortify account.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white54, fontSize: 13),
          ),
        ],
      ),
    );
  }
}

class _EmptySection extends StatelessWidget {
  final String title;
  final String message;

  const _EmptySection({required this.title, required this.message});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          message,
          style: const TextStyle(color: Colors.white38, fontSize: 13),
        ),
      ],
    );
  }
}

class _ShelfSkeleton extends StatelessWidget {
  final double height;

  const _ShelfSkeleton({this.height = 226});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          for (int i = 0; i < 4; i++) ...[
            Expanded(
              child: Container(
                height: height - 46,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.05),
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            const SizedBox(width: 18),
          ],
        ],
      ),
    );
  }
}

class _LibraryError extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;

  const _LibraryError({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.04),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Couldn't load your library",
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            message,
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Colors.white38, fontSize: 12),
          ),
          const SizedBox(height: 16),
          OutlinedButton(
            onPressed: onRetry,
            style: OutlinedButton.styleFrom(
              foregroundColor: Colors.white,
              side: const BorderSide(color: Colors.white24),
            ),
            child: const Text('Try Again'),
          ),
        ],
      ),
    );
  }
}
