import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:snortify/models/music_models.dart';
import 'package:snortify/providers/playback_provider.dart';
import 'package:snortify/repository/music_repository.dart';
import 'package:snortify/widgets/artwork_image.dart';
import 'package:snortify/widgets/song_list_item.dart';
import 'package:snortify/layout_breakpoints.dart';

/// Full album view: cover, metadata, action bar and the ordered tracklist.
///
/// Takes an [album] (not an id) so it can render immediately from whatever the
/// parent already has, then fetches the tracklist for [Album.id].
class AlbumDetailScreen extends StatefulWidget {
  final Album album;

  const AlbumDetailScreen({super.key, required this.album});

  @override
  State<AlbumDetailScreen> createState() => _AlbumDetailScreenState();
}

class _AlbumDetailScreenState extends State<AlbumDetailScreen> {
  late Future<List<Song>> _songsFuture;

  @override
  void initState() {
    super.initState();
    _songsFuture = MusicRepository().fetchSongsForAlbum(widget.album.id);
  }

  void _reload() {
    setState(() {
      _songsFuture = MusicRepository().fetchSongsForAlbum(widget.album.id);
    });
  }

  Future<void> _play(List<Song> songs, {bool shuffle = false}) async {
    if (songs.isEmpty) return;

    final messenger = ScaffoldMessenger.of(context);
    final playback = context.read<PlaybackProvider>();

    // Shuffle up front so the queue order is shuffled before the first track
    // loads — toggling it afterwards would reshuffle around the current song.
    if (shuffle && !playback.shuffleEnabled) {
      playback.toggleShuffle();
    } else if (!shuffle && playback.shuffleEnabled) {
      playback.toggleShuffle();
    }

    try {
      await playback.playQueue(songs, 0);
    } catch (e) {
      messenger.showSnackBar(
        SnackBar(content: Text('Could not play ${widget.album.title}: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final album = widget.album;

    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;

        return Scaffold(
          backgroundColor: const Color(0xFF121212),
          body: FutureBuilder<List<Song>>(
            future: _songsFuture,
            builder: (context, snapshot) {
              final songs = snapshot.data ?? const <Song>[];
              final playback = context.watch<PlaybackProvider>();

              return CustomScrollView(
                slivers: [
                  _buildAppBar(album),
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: pagePadding(width, top: 8, bottom: 24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildHeader(album, songs, width),
                          const SizedBox(height: 24),
                          _buildActionBar(songs),
                          const SizedBox(height: 24),
                          if (snapshot.connectionState ==
                              ConnectionState.waiting)
                            const _TrackListSkeleton()
                          else if (snapshot.hasError)
                            _TrackListMessage(
                              icon: Icons.cloud_off,
                              message: "Couldn't load tracks",
                              actionLabel: 'Try Again',
                              onAction: _reload,
                            )
                          else if (songs.isEmpty)
                            const _TrackListMessage(
                              icon: Icons.music_off,
                              message: 'No tracks in this album yet.',
                            )
                          else
                            ...List.generate(songs.length, (index) {
                              final song = songs[index];
                              final isCurrent =
                                  playback.currentSong?.id == song.id &&
                                  playback.isPlaying;
                              return SongListItem(
                                trackNumber: index + 1,
                                title: song.title,
                                songId: song.id,
                                duration: song.durationLabel,
                                isActive: isCurrent,
                                onTap: () => _playFrom(songs, index),
                              );
                            }),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        );
      },
    );
  }

  Future<void> _playFrom(List<Song> songs, int index) async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      await context.read<PlaybackProvider>().playQueue(songs, index);
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('Could not play: $e')));
    }
  }

  Widget _buildAppBar(Album album) {
    return SliverAppBar(
      pinned: true,
      expandedHeight: 0,
      backgroundColor: const Color(0xFF121212),
      surfaceTintColor: Colors.transparent,
      title: Text(
        album.title,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(color: Colors.white, fontSize: 16),
      ),
    );
  }

  Widget _buildHeader(Album album, List<Song> songs, double width) {
    final totalSeconds = songs.fold<int>(
      0,
      (sum, song) => sum + (song.durationSeconds ?? 0),
    );

    final details = <String>[
      if (album.genre != null) album.genre!,
      if (album.releaseYear != null) album.releaseYear.toString(),
      if (songs.isNotEmpty) '${songs.length} songs',
      if (totalSeconds > 0) _formatMinutes(totalSeconds),
    ].join(' · ');

    final artwork = ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: SizedBox(
        // A fixed 220px cover plus a 32px gap left under 70px for the title on
        // a 360dp phone, which forced the header column to wrap to one word
        // per line. Size it to the gutter instead.
        width: isMobileWidth(width) ? 120 : 220,
        height: isMobileWidth(width) ? 120 : 220,
        child: ArtworkImage(networkUrl: album.coverUrl),
      ),
    );

    final text = Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            album.title,
            style: TextStyle(
              fontSize: isMobileWidth(width) ? 24 : 34,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 6),
          if (album.artist != null)
            Text(
              album.artist!.name,
              style: const TextStyle(fontSize: 18, color: Colors.white70),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          const SizedBox(height: 8),
          if (details.isNotEmpty)
            Text(
              details,
              style: const TextStyle(color: Colors.white54, fontSize: 13),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
        ],
      ),
    );

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        artwork,
        SizedBox(width: isMobileWidth(width) ? 16 : 32),
        text,
      ],
    );
  }

  Widget _buildActionBar(List<Song> songs) {
    final canPlay = songs.isNotEmpty;

    return Row(
      children: [
        ElevatedButton.icon(
          onPressed: canPlay ? () => _play(songs) : null,
          icon: const Icon(Icons.play_arrow, size: 20),
          label: const Text('Play'),
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFFA2D48),
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
        ),
        const SizedBox(width: 16),
        // The secondary actions scroll rather than squeeze the Play button —
        // five icon buttons plus the label do not fit a 360dp row.
        Expanded(
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            reverse: true,
            child: Row(
              children: [
                IconButton(
                  iconSize: 26,
                  color: Colors.white70,
                  icon: const Icon(Icons.shuffle),
                  onPressed: canPlay ? () => _play(songs, shuffle: true) : null,
                ),
                IconButton(
                  iconSize: 26,
                  color: Colors.white70,
                  icon: const Icon(Icons.star_border),
                  onPressed: () {},
                ),
                IconButton(
                  iconSize: 26,
                  color: Colors.white70,
                  icon: const Icon(Icons.bookmark_border),
                  onPressed: () {},
                ),
                IconButton(
                  iconSize: 26,
                  color: Colors.white70,
                  icon: const Icon(Icons.download),
                  onPressed: () {},
                ),
                IconButton(
                  iconSize: 26,
                  color: Colors.white70,
                  icon: const Icon(Icons.more_horiz),
                  onPressed: () {},
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  static String _formatMinutes(int totalSeconds) {
    final minutes = totalSeconds ~/ 60;
    return '$minutes min';
  }
}

class _TrackListSkeleton extends StatelessWidget {
  const _TrackListSkeleton();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: List.generate(
        5,
        (index) => Container(
          height: 42,
          margin: const EdgeInsets.symmetric(vertical: 4),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.04),
            borderRadius: BorderRadius.circular(6),
          ),
        ),
      ),
    );
  }
}

class _TrackListMessage extends StatelessWidget {
  final IconData icon;
  final String message;
  final String? actionLabel;
  final VoidCallback? onAction;

  const _TrackListMessage({
    required this.icon,
    required this.message,
    this.actionLabel,
    this.onAction,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 40),
      child: Center(
        child: Column(
          children: [
            Icon(icon, color: Colors.white24, size: 32),
            const SizedBox(height: 12),
            Text(
              message,
              style: const TextStyle(color: Colors.white70, fontSize: 15),
            ),
            if (actionLabel != null) ...[
              const SizedBox(height: 12),
              OutlinedButton(
                onPressed: onAction,
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.white,
                  side: const BorderSide(color: Colors.white24),
                ),
                child: Text(actionLabel!),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
