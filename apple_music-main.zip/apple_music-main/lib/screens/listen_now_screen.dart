import 'package:flutter/material.dart';
import 'package:snortify/widgets/music_tile.dart';
import 'package:snortify/widgets/artwork_image.dart';
import 'package:snortify/widgets/content_shelf.dart';
import 'package:snortify/models/music_models.dart';
import 'package:snortify/repository/music_repository.dart';
import 'package:snortify/screens/album_detail_screen.dart';
import 'package:snortify/screens/tabs/radio_screen.dart';
import 'package:snortify/layout_breakpoints.dart';

/// Sections of the Listen Now tab, in pill order.
///
/// [feed] is the page itself; the rest are not real destinations yet — Radio
/// has a stub screen, Charts has no play-count data behind it, and Music
/// Videos / Spatial Audio need streams this catalogue does not have. They
/// exist so the pills respond to taps and can show a real selected state
/// rather than six dead labels.
enum _ListenNowSection { feed, new_, charts, radio, videos, spatial }

extension on _ListenNowSection {
  String get label => switch (this) {
    _ListenNowSection.feed => 'For You',
    _ListenNowSection.new_ => 'New',
    _ListenNowSection.charts => 'Charts',
    _ListenNowSection.radio => 'Radio',
    _ListenNowSection.videos => 'Music Videos',
    _ListenNowSection.spatial => 'Spatial Audio',
  };

  /// Why the section has no feed of its own yet, shown under the pills.
  String? get placeholder => switch (this) {
    _ListenNowSection.feed => null,
    _ListenNowSection.new_ => 'New releases are coming soon.',
    _ListenNowSection.charts => 'Charts need play-count data.',
    _ListenNowSection.radio => 'Radio stations are coming soon.',
    _ListenNowSection.videos => 'Music videos are coming soon.',
    _ListenNowSection.spatial => 'Spatial Audio is coming soon.',
  };
}

/// One entry in an editorial shelf that is built from local assets rather than
/// the catalogue.
///
/// Kept as a class instead of a plain record so the mood tiles can carry the
/// fallback colour the design shows when there is no cover to lean on.
class _ShelfEntry {
  final String title;
  final String subtitle;
  final String asset;
  final Color color;

  const _ShelfEntry({
    required this.title,
    required this.subtitle,
    required this.asset,
    required this.color,
  });
}

/// "Find Your Mood" — six coloured, text-forward tiles.
///
/// Local artwork only. The mood copy is editorial rather than catalogue-backed
/// because the catalogue has no mood tagging; the images are the app's own
/// playlist art, so nothing here reaches the network.
const List<_ShelfEntry> _moodTiles = [
  _ShelfEntry(
    title: 'Chill',
    subtitle: 'Relax & unwind',
    asset: 'assets/playlists/chill.jpg',
    color: Color(0xFF2E5A78),
  ),
  _ShelfEntry(
    title: 'Feel Good',
    subtitle: 'Bright & upbeat',
    asset: 'assets/playlists/favourites.webp',
    color: Color(0xFF7A3B6B),
  ),
  _ShelfEntry(
    title: 'Pop Hits',
    subtitle: 'Right now',
    asset: 'assets/featured/pop_deluxe.jpg',
    color: Color(0xFF8A4A3C),
  ),
  _ShelfEntry(
    title: 'Metal',
    subtitle: 'Heavy rotation',
    asset: 'assets/playlists/metal.jpg',
    color: Color(0xFF3A3A42),
  ),
  _ShelfEntry(
    title: 'Linkin Park',
    subtitle: 'Essential tracks',
    asset: 'assets/playlists/linkinpark.jpeg',
    color: Color(0xFF4A4A54),
  ),
  _ShelfEntry(
    title: 'International',
    subtitle: 'Sounds of the world',
    asset: 'assets/playlists/international.webp',
    color: Color(0xFF2F6B5E),
  ),
];

/// "Essentials" — the standing playlists a new listener is steered to first.
const List<_ShelfEntry> _essentialsTiles = [
  _ShelfEntry(
    title: 'Pop Essentials',
    subtitle: 'Snortify Pop',
    asset: 'assets/featured/pop_deluxe.jpg',
    color: Color(0xFF8A4A3C),
  ),
  _ShelfEntry(
    title: 'Recently Added',
    subtitle: 'Snortify',
    asset: 'assets/albums/album03.jpg',
    color: Color(0xFF3C4A6B),
  ),
  _ShelfEntry(
    title: 'Chill Mix',
    subtitle: 'Snortify',
    asset: 'assets/playlists/chill.jpg',
    color: Color(0xFF2E5A78),
  ),
  _ShelfEntry(
    title: 'Hip-Hop Essentials',
    subtitle: 'Snortify',
    asset: 'assets/albums/album05.jpg',
    color: Color(0xFF6B3C4A),
  ),
  _ShelfEntry(
    title: 'Rock Essentials',
    subtitle: 'Snortify',
    asset: 'assets/albums/album07.jpg',
    color: Color(0xFF5A4A2E),
  ),
];

class ListenNowScreen extends StatefulWidget {
  const ListenNowScreen({super.key});

  @override
  State<ListenNowScreen> createState() => _ListenNowScreenState();
}

class _MoodTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final String assetPath;
  final Color color;

  const _MoodTile({
    required this.title,
    required this.subtitle,
    required this.assetPath,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: Stack(
        fit: StackFit.expand,
        children: [
          ArtworkImage(assetPath: assetPath),
          // A flat tint first, so the artwork reads as tinted rather than as a
          // greyed-out photo, then a bottom scrim for the text.
          ColoredBox(color: color.withValues(alpha: 0.55)),
          DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.bottomCenter,
                end: Alignment.topCenter,
                colors: [
                  Colors.black.withValues(alpha: 0.72),
                  Colors.transparent,
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.2,
                  ),
                ),
                const SizedBox(height: 1),
                Text(
                  subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 10,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ListenNowScreenState extends State<ListenNowScreen> {
  late Future<List<Album>> _albumsFuture;

  _ListenNowSection _section = _ListenNowSection.feed;

  /// Created on first use so a rebuilt frame doesn't hand the pill strip a
  /// fresh controller and reset its scroll position.
  ScrollController? _pillScrollController;

  /// Albums handed to the mobile "Latest Albums" shelf.
  ///
  /// Kept as plain state rather than read straight off the future inside
  /// `build`, because a shelf states its item count up front — a
  /// `FutureBuilder` can only hand the whole shelf over as one future child,
  /// and dropping one inside the shelf's slot would put a scroll view inside a
  /// scroll view.
  List<Album> _albumsPreview = const <Album>[];
  bool _albumsSampled = false;

  @override
  void dispose() {
    _pillScrollController?.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _albumsFuture = MusicRepository().fetchFeaturedAlbums();
  }

  void _reload() {
    setState(() {
      _albumsFuture = MusicRepository().fetchFeaturedAlbums();
      // Let the sampled copy be taken again from the new future, otherwise
      // the shelf keeps showing the albums from the failed fetch.
      _albumsSampled = false;
      _albumsPreview = const <Album>[];
    });
  }

  void _selectSection(_ListenNowSection section) {
    if (_section == section) return;
    setState(() => _section = section);
  }

  /// Opens the full album view, where tracks can be inspected and played.
  void _openAlbum(Album album) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => AlbumDetailScreen(album: album)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        final isMobile = isMobileWidth(width);
        // The scaffold has no AppBar, so nothing claims the status bar for us —
        // the pill strip would otherwise start at y=0, under the clock and the
        // camera cutout.
        final topInset = pageTopInset(context, base: 20);

        // Only the phone branch needs the sampled copy below; desktop reads
        // `_albumsFuture` through its own `FutureBuilder`. Both share one
        // future, so this is not a second request.
        if (isMobile && !_albumsSampled) {
          _albumsFuture.then((albums) {
            if (!mounted || _albumsSampled) return;
            setState(() {
              _albumsSampled = true;
              _albumsPreview = albums.take(10).toList();
            });
          });
        }

        return Scaffold(
          backgroundColor: const Color(0xFF121212),
          body: SingleChildScrollView(
            padding: pagePadding(width, top: topInset, bottom: 40),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Top Navigation Pill — scrolls sideways once its tabs stop
                // fitting, instead of overflowing the page.
                Align(alignment: Alignment.centerLeft, child: _buildNavPill()),

                // "Radio" is a real tab, so it opens the same screen the bottom
                // nav does rather than a placeholder.
                if (_section == _ListenNowSection.radio)
                  _buildSectionPlaceholder(context)
                else if (isMobile)
                  // The phone layout is the editorial one: a stack of shelves
                  // rather than a single full-width grid. Desktop keeps its own
                  // branch below — this is a layout split, not a restyle, so
                  // neither side can affect the other.
                  ..._buildMobileFeed(context)
                else ...[
                  if (_section != _ListenNowSection.feed)
                    _buildSectionPlaceholder(context),

                  const SizedBox(height: 32),

                  // Featured cards. Two-up on a phone, still two-up on desktop —
                  // each card just gets wider.
                  //
                  // No `crossAxisAlignment` here on purpose. A Column inside a
                  // SingleChildScrollView hands its children an unbounded height,
                  // and `stretch` then resolves each child's cross-axis size
                  // against that infinity — "BoxConstraints forces an infinite
                  // height" at the Row. Each card states its own height, and both
                  // cards use the same one, so the Row sizes to it.
                  Row(
                    children: [
                      _buildFeaturedCard(
                        'PRE-ADD NOW',
                        'Cloud 9',
                        'Megan Moroney',
                        'assets/featured/claud9.webp',
                        height: isMobile ? 190 : 280,
                      ),
                      const SizedBox(width: 24),
                      _buildFeaturedCard(
                        'UPDATED PLAYLIST',
                        'Pop Deluxe',
                        'Apple Music Pop',
                        'assets/featured/pop_deluxe.jpg',
                        height: isMobile ? 190 : 280,
                      ),
                    ],
                  ),
                  const SizedBox(height: 48),

                  // New Releases For You
                  _buildNewReleasesSection(isMobile: isMobile),
                  const SizedBox(height: 48),

                  // "Latest Albums For You" — live from Supabase
                  const Text(
                    "Latest Albums For You",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 20),
                  FutureBuilder<List<Album>>(
                    future: _albumsFuture,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState ==
                          ConnectionState.waiting) {
                        return const SizedBox(
                          height: 220,
                          child: Center(
                            child: CircularProgressIndicator(
                              color: Colors.white24,
                            ),
                          ),
                        );
                      }

                      if (snapshot.hasError) {
                        return _buildErrorState(snapshot.error!);
                      }

                      final albums = snapshot.data ?? const <Album>[];
                      if (albums.isEmpty) {
                        return _buildEmptyState();
                      }

                      return LayoutBuilder(
                        builder: (context, gridConstraints) {
                          // Columns follow the available width rather than being
                          // fixed at four — four columns on a 360dp phone left
                          // each tile ~60dp wide and overflowed.
                          const spacing = 16.0;
                          final columns = gridColumnCount(
                            gridConstraints.maxWidth,
                            minItemWidth: isMobile ? 140 : 160,
                            spacing: spacing,
                            max: 4,
                          );
                          // Ratio derived from the cell width the delegate is
                          // about to produce. The previous constant 0.85 was
                          // about 35px short of what a two-line title plus a
                          // subtitle needs, so the second line was painted
                          // outside the cell and clipped.
                          final tileWidth = gridTileWidth(
                            gridConstraints.maxWidth,
                            columns,
                            spacing: spacing,
                          );

                          return GridView.builder(
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            gridDelegate:
                                SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: columns,
                              childAspectRatio: tileChildAspectRatio(
                                tileWidth,
                              ),
                              crossAxisSpacing: spacing,
                              mainAxisSpacing: spacing,
                            ),
                            itemCount: albums.length,
                            itemBuilder: (context, index) {
                              final album = albums[index];
                              final assetMap = {
                                'b2000000-0000-4000-8000-000000000001': 'assets/albums/album01.jpg',
                                'b2000000-0000-4000-8000-000000000002': 'assets/albums/album02.jpg',
                                'b2000000-0000-4000-8000-000000000003': 'assets/albums/album03.jpg',
                                'b2000000-0000-4000-8000-000000000004': 'assets/albums/album04.jpg',
                                'b2000000-0000-4000-8000-000000000005': 'assets/albums/album05.jpg',
                                'b2000000-0000-4000-8000-000000000006': 'assets/albums/album06.jpg',
                              };
                              final asset = assetMap[album.id];
                              return MusicTile(
                                title: album.title,
                                subtitle: album.artist?.name,
                                networkUrl: asset == null ? album.coverUrl : null,
                                assetPath: asset,
                                onTap: () => _openAlbum(album),
                              );
                            },
                          );
                        },
                      );
                    },
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }

  /// The phone feed, in the editorial order the mobile design uses.
  ///
  /// Returned as a list so it can be spread into the page `Column`; a single
  /// widget would need its own `Column` and a nested scroll view, and the
  /// shelves have to share the parent's one unbounded vertical axis.
  List<Widget> _buildMobileFeed(BuildContext context) {
    return [
      if (_section != _ListenNowSection.feed) ...[
        _buildSectionPlaceholder(context),
        const SizedBox(height: 24),
      ],

      const SizedBox(height: 20),

      // "Find Your Mood" — the coloured, text-forward tiles that lead the
      // phone design. Local assets only.
      const Text(
        'Find Your Mood',
        style: TextStyle(
          color: Colors.white,
          fontSize: 22,
          fontWeight: FontWeight.bold,
          letterSpacing: -0.4,
        ),
      ),
      const SizedBox(height: 16),
      _buildMoodShelf(),

      const SizedBox(height: 36),

      // Full-bleed hero. On the phone this is the "pre-add" card the design
      // leads with; it fills the width instead of sitting two-up, because a
      // half-width card is too small to read at 360dp.
      _buildFeaturedCard(
        'PRE-ADD NOW',
        'Cloud 9',
        'Megan Moroney',
        'assets/featured/claud9.webp',
        height: 220,
        expand: false,
      ),

      const SizedBox(height: 36),

      ContentShelf(
        title: 'New Releases For You',
        itemCount: _moodTiles.length,
        itemWidth: 160,
        itemBuilder: (context, index) {
          final mood = _moodTiles[index];
          return ShelfTile(
            title: mood.title,
            subtitle: mood.subtitle,
            assetPath: mood.asset,
          );
        },
      ),

      const SizedBox(height: 36),

      ContentShelf(
        title: 'Essentials',
        itemCount: _essentialsTiles.length,
        itemWidth: 160,
        itemBuilder: (context, index) {
          final tile = _essentialsTiles[index];
          return ShelfTile(
            title: tile.title,
            subtitle: tile.subtitle,
            assetPath: tile.asset,
          );
        },
      ),

      const SizedBox(height: 36),

      // "Latest Albums For You" — the same Supabase fetch the desktop grid
      // uses, laid out as a shelf so a phone never shows a four-column grid.
      ContentShelf(
        title: 'Latest Albums For You',
        itemCount: _albumsPreview.length,
        itemWidth: 160,
        itemBuilder: (context, index) {
          final album = _albumsPreview[index];
          // Simple mapping logic to use local assets for the demo
          final assetMap = {
            'b2000000-0000-4000-8000-000000000001': 'assets/albums/album01.jpg',
            'b2000000-0000-4000-8000-000000000002': 'assets/albums/album02.jpg',
            'b2000000-0000-4000-8000-000000000003': 'assets/albums/album03.jpg',
            'b2000000-0000-4000-8000-000000000004': 'assets/albums/album04.jpg',
            'b2000000-0000-4000-8000-000000000005': 'assets/albums/album05.jpg',
            'b2000000-0000-4000-8000-000000000006': 'assets/albums/album06.jpg',
          };
          final asset = assetMap[album.id];
          return ShelfTile(
            title: album.title,
            subtitle: album.artist?.name,
            networkUrl: asset == null ? album.coverUrl : null,
            assetPath: asset,
            onTap: () => _openAlbum(album),
          );
        },
      ),

      const SizedBox(height: 28),
    ];
  }

  /// The mood grid: up to three columns of coloured, text-only tiles.
  ///
  /// Height is fixed per tile rather than derived from [tileChildAspectRatio],
  /// because these have no artwork and no label block below — the text sits
  /// inside the block. The width comes from the same [gridTileWidth] the album
  /// grid uses, so the two stay in step at any phone width.
  Widget _buildMoodShelf() {
    const spacing = 12.0;
    return LayoutBuilder(
      builder: (context, constraints) {
        final columns = gridColumnCount(
          constraints.maxWidth,
          minItemWidth: 104,
          spacing: spacing,
          max: 3,
        );
        final tileWidth = gridTileWidth(
          constraints.maxWidth,
          columns,
          spacing: spacing,
        );

        return Wrap(
          spacing: spacing,
          runSpacing: spacing,
          children: [
            for (final mood in _moodTiles)
              SizedBox(
                width: tileWidth,
                height: tileWidth * 0.72,
                child: _MoodTile(
                  title: mood.title,
                  subtitle: mood.subtitle,
                  assetPath: mood.asset,
                  color: mood.color,
                ),
              ),
          ],
        );
      },
    );
  }

  /// The one-line note shown when a section has no feed yet.
  ///
  /// Sits directly under the pills so tapping a pill produces a visible change
  /// instead of the page appearing to ignore the tap. Radio is the exception:
  /// it has a screen of its own, so it offers that instead of a dead end.
    Widget _buildSectionPlaceholder(BuildContext context) {
      final message = _section.placeholder;
      if (message == null) return const SizedBox.shrink();

      if (_section == _ListenNowSection.radio) {
        return Padding(
          padding: const EdgeInsets.only(top: 20),
          child: OutlinedButton.icon(
            onPressed: () => Navigator.of(
              context,
            ).push(MaterialPageRoute<void>(builder: (_) => const RadioScreen())),
            icon: const Icon(Icons.radio, size: 18),
            label: const Text('Open Radio'),
            style: OutlinedButton.styleFrom(
              foregroundColor: Colors.white,
              side: const BorderSide(color: Colors.white24),
            ),
          ),
        );
      }

      return Padding(
        padding: const EdgeInsets.only(top: 20),
        child: Text(
          message,
          style: const TextStyle(color: Colors.white54, fontSize: 14),
        ),
      );
    }

    Widget _buildErrorState(Object error) {
      return SizedBox(
        height: 220,
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.cloud_off, color: Colors.white24, size: 32),
              const SizedBox(height: 12),
              const Text(
                "Couldn't load albums",
                style: TextStyle(color: Colors.white70, fontSize: 15),
              ),
              const SizedBox(height: 12),
              OutlinedButton(
                onPressed: _reload,
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.white,
                  side: const BorderSide(color: Colors.white24),
                ),
                child: const Text('Try Again'),
              ),
            ],
          ),
        ),
      );
    }

    Widget _buildEmptyState() {
      return SizedBox(
        height: 220,
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                "No albums yet",
                style: TextStyle(color: Colors.white70, fontSize: 15),
              ),
              const SizedBox(height: 12),
              OutlinedButton(
                onPressed: _reload,
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.white,
                  side: const BorderSide(color: Colors.white24),
                ),
                child: const Text('Refresh'),
              ),
            ],
          ),
        ),
      );
    }

    /// The category pill. Its six tabs are wider than any phone, so the strip
    /// scrolls horizontally inside a single-height row rather than overflowing.
    Widget _buildNavPill() {
      // A real scroll controller so selecting a pill can bring the chosen tab
      // back into view — without one, tapping "Spatial Audio" leaves the
      // highlight off-screen at the end of the strip.
      final controller = _pillScrollController ??= ScrollController();

      return SingleChildScrollView(
        controller: controller,
        scrollDirection: Axis.horizontal,
        // Vertical overflow is intentional here (items may be pulled slightly out
        // of view while scrolling); horizontal is the axis that must never
        // report an overflow.
        clipBehavior: Clip.none,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.03),
            borderRadius: BorderRadius.circular(50),
            border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              for (final section in _ListenNowSection.values)
                _navItem(section, controller: controller),
            ],
          ),
        ),
      );
    }

    /// One pill. A `GestureDetector` with an opaque hit-test behaviour rather
    /// than `InkWell`: the pill's own padding is what the user aims at, and
    /// `InkWell` needs a `Material` ancestor to paint its splash, which would
    /// mean giving the strip a background it does not have.
    Widget _navItem(
      _ListenNowSection section, {
      required ScrollController controller,
    }) {
      final selected = _section == section;
      final index = section.index;

      return Semantics(
        button: true,
        selected: selected,
        label: section.label,
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () {
            _selectSection(section);
            _revealPill(index, controller);
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            curve: Curves.easeOut,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            decoration: BoxDecoration(
              color: selected
                  ? Colors.white.withValues(alpha: 0.12)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(50),
            ),
            child: Text(
              section.label,
              style: TextStyle(
                color: selected ? Colors.white : Colors.white54,
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ),
      );
    }

    /// Scrolls the pill at [index] into view without changing the strip's size.
    ///
    /// [ensureVisible] needs a key-based lookup into the rendered tree, which the
    /// pill row does not expose. Estimating from the cumulative width of the
    /// labels is enough here — the strip is short and every pill has a fixed
    /// horizontal padding, so a small slop does not matter.
    void _revealPill(int index, ScrollController controller) {
      if (!controller.hasClients) return;

      // 32px of horizontal padding per pill, plus roughly half the average
      // label width. Only approximate, and only used as a scroll target.
      var offset = 0.0;
      for (var i = 0; i < index; i++) {
        offset += 32 + (_ListenNowSection.values[i].label.length * 7.2);
      }

      final position = controller.position;
      final target = (offset - position.viewportDimension / 2).clamp(
        position.minScrollExtent,
        position.maxScrollExtent,
      );

      controller.animateTo(
        target,
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOut,
      );
    }

    Widget _buildFeaturedCard(
      String label,
      String title,
      String artist,
      String assetPath, {
      required double height,
      bool expand = true,
    }) {
      // Expanded for the half-width, SizedBox for the height. The height is
      // declared here rather than via the Row's crossAxisAlignment so this card
      // can be dropped into a Column or a shrink-wrapped grid unchanged.
      //
      // `expand: false` is the phone variant: the same card, but full-bleed
      // instead of `Expanded`, so it can sit directly in the page Column without
      // a Row to divide it. `Expanded` outside a Flex is a layout error, which is
      // why the desktop two-up Row and the mobile hero cannot share one code
      // path.
      final card = SizedBox(
        height: height,
        child: Container(
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(16)),
          clipBehavior: Clip.antiAlias,
          child: Stack(
            children: [
              Positioned.fill(child: ArtworkImage(assetPath: assetPath)),
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.bottomCenter,
                      end: Alignment.topCenter,
                      colors: [
                        Colors.black.withValues(alpha: 0.6),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
              Positioned(
                bottom: 16,
                left: 14,
                // `right` matters as much as `left`: without it the label
                // column is unconstrained and a long title paints past the
                // card edge rather than ellipsising.
                right: 14,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      artist,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );

      return expand ? Expanded(child: card) : card;
    }

    Widget _buildNewReleasesSection({required bool isMobile}) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "New Releases For You >",
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 20),
          LayoutBuilder(
            builder: (context, constraints) {
              // One row per song on a phone, two on anything wider. The old
              // fixed two-up grid left each row ~90dp on a 360dp screen, which
              // the 50dp artwork plus padding could not fit.
              final columns = gridColumnCount(
                constraints.maxWidth,
                minItemWidth: isMobile ? 260 : 300,
                spacing: 16,
                max: 2,
              );

              return GridView.builder(
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: columns,
                  childAspectRatio: isMobile ? 3.4 : 4,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 12,
                ),
                itemCount: 6,
                itemBuilder: (context, index) {
                  return Row(
                    children: [
                      SizedBox(
                        width: 50,
                        height: 50,
                        child: ArtworkImage(
                          assetPath: 'assets/songs/song0${index + 1}.jpg',
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Song Title ${index + 1}",
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                              ),
                            ),
                            Text(
                              "Artist Name",
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.white54,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  );
                },
              );
            },
          ),
        ],
      );
    }
  }
