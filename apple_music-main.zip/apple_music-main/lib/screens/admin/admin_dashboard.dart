import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:snortify/screens/admin/upload_song_screen.dart';
import 'package:snortify/screens/admin/manage_songs_screen.dart';
import 'package:snortify/layout_breakpoints.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  bool _isAdmin = false;
  bool _checking = true;

  @override
  void initState() {
    super.initState();
    _checkAdmin();
  }

  Future<void> _checkAdmin() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) {
      setState(() => _checking = false);
      return;
    }
    try {
      final res = await Supabase.instance.client
          .from('profiles')
          .select('role')
          .eq('id', user.id)
          .maybeSingle();
      final role = res?['role']?.toString();
      if (mounted) setState(() { _isAdmin = role == 'admin'; _checking = false; });
    } catch (_) {
      if (mounted) setState(() => _checking = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final isMobile = isMobileWidth(width);

    if (_checking) {
      return Scaffold(
        backgroundColor: const Color(0xFF121212),
        body: const Center(child: CircularProgressIndicator(color: Colors.white70)),
      );
    }

    if (!_isAdmin) {
      // Deny: return safe screen, do not expose admin UI
      return Scaffold(
        backgroundColor: const Color(0xFF121212),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.lock, color: Colors.white24, size: 48),
              const SizedBox(height: 16),
              const Text('Access denied', style: TextStyle(color: Colors.white, fontSize: 18)),
              const SizedBox(height: 8),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Back', style: TextStyle(color: Colors.white70)),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.symmetric(horizontal: isMobile ? 16 : 40, vertical: 24),
          children: [
            // Header with back button and title
            Row(
              children: [
                // Back button
                Material(
                  color: Colors.transparent,
                  child: Tooltip(
                    message: 'Back',
                    child: IconButton(
                      onPressed: () => Navigator.of(context).maybePop(),
                      icon: const Icon(Icons.arrow_back_ios_new_rounded),
                      color: Colors.white70,
                      iconSize: 20,
                      splashRadius: 24,
                      style: IconButton.styleFrom(
                        backgroundColor: Colors.white.withValues(alpha: 0.08),
                        foregroundColor: Colors.white70,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      hoverColor: Colors.white.withValues(alpha: 0.12),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                // Title
                Text(
                  'ADMIN DASHBOARD',
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.6),
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 2,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: _AdminCard(
                    title: 'Upload Song',
                    subtitle: 'Audio + artwork + metadata',
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const UploadSongScreen())),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: _AdminCard(
                    title: 'Manage Songs',
                    subtitle: 'Edit, publish, delete',
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ManageSongsScreen())),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _AdminCard extends StatelessWidget {
  final String title, subtitle;
  final VoidCallback onTap;
  const _AdminCard({required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.05),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withValues(alpha: 0.1)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 4),
            Text(subtitle, style: TextStyle(color: Colors.white.withValues(alpha: 0.6), fontSize: 13)),
          ],
        ),
      ),
    );
  }
}
