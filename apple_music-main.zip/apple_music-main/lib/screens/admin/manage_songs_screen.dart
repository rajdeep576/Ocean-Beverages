import 'dart:async';

import 'package:flutter/material.dart';
import 'package:snortify/layout_breakpoints.dart';
import 'package:snortify/models/music_models.dart';
import 'package:snortify/repository/music_repository.dart';

/// Admin view over every track in the catalogue — published or not.
///
/// Reads and writes go through [MusicRepository]; authorization is RLS's job
/// (`public.is_admin()` in supabase/admin_setup.sql), so this screen shows the
/// controls but cannot be trusted to hide them — nor should it pretend to.
class ManageSongsScreen extends StatefulWidget {
  const ManageSongsScreen({super.key});

  @override
  State<ManageSongsScreen> createState() => _ManageSongsScreenState();
}

class _ManageSongsScreenState extends State<ManageSongsScreen> {
  final _repository = MusicRepository();
  final _searchController = TextEditingController();

  /// Every song as fetched, unfiltered. The search runs over this rather than
  /// as a server filter: PostgREST rejects `or()` on an embedded column
  /// (PGRST100) and silently ignores a plain filter on one, so an
  /// artist-or-album search would return unfiltered results while looking
  /// like it worked. Fine at catalogue scale.
  List<Song> _songs = const [];
  bool _isLoading = true;
  String? _error;
  String _query = '';

  /// Ids with a publish/unpublish or delete in flight, so their row's
  /// controls can be disabled instead of letting a double tap fire twice.
  final Set<String> _busy = {};

  /// True when admin_setup.sql has not been applied — drafts cannot be
  /// distinguished from published tracks without `is_published`.
  bool _publishingUnavailable = false;

  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    _searchController.addListener(_onSearchChanged);
    _load();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchController
      ..removeListener(_onSearchChanged)
      ..dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final songs = await _repository.fetchAllSongsAdmin();
      if (!mounted) return;
      setState(() {
        _songs = songs;
        _publishingUnavailable = songs.isNotEmpty &&
            songs.every((song) => !song.hasPublishingColumn);
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e is MusicRepositoryException
            ? e.message
            : "Couldn't load the catalogue";
        _isLoading = false;
      });
    }
  }

  void _onSearchChanged() {
    final query = _searchController.text;
    if (query == _query) return;
    _query = query;

    // Same 300ms debounce the Search tab uses, so typing feels the same here.
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 300), () {
      if (mounted) setState(() {});
    });
  }

  List<Song> get _visibleSongs {
    final query = _query.trim().toLowerCase();
    if (query.isEmpty) return _songs;

    return _songs.where((song) {
      final haystack = [
        song.title,
        song.artistName ?? '',
        song.albumTitle ?? '',
      ].join(' ').toLowerCase();
      return haystack.contains(query);
    }).toList();
  }

  Future<void> _togglePublished(Song song) async {
    final next = !song.isPublished;
    setState(() => _busy.add(song.id));
    try {
      final updated = await _repository.setSongPublished(song.id, next);
      if (!mounted) return;
      setState(() {
        _songs = _songs
            .map((s) => s.id == updated.id ? updated : s)
            .toList();
        _publishingUnavailable = false;
      });
    } catch (e) {
      if (!mounted) return;
      _showMessage(_messageFor(e));
    } finally {
      if (mounted) setState(() => _busy.remove(song.id));
    }
  }

  Future<void> _confirmDelete(Song song) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF2C2C2E),
        title: Text(
          'Delete "${song.title}"?',
          style: const TextStyle(color: Colors.white, fontSize: 17),
        ),
        content: Text(
          'This removes the track for everyone, along with its audio file and '
          'any playlist and favourite entries for it. It cannot be undone.',
          style: TextStyle(
            color: Colors.white.withValues(alpha: 0.7),
            fontSize: 13,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(
              'Cancel',
              style: TextStyle(color: Colors.white.withValues(alpha: 0.7)),
            ),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text(
              'Delete',
              style: TextStyle(color: Color(0xFFFF6B6B)),
            ),
          ),
        ],
      ),
    );

    if (confirmed != true) return;
    await _delete(song);
  }

  Future<void> _delete(Song song) async {
    setState(() => _busy.add(song.id));
    try {
      await _repository.deleteSong(song.id);
      if (!mounted) return;
      setState(() {
        _songs = _songs.where((s) => s.id != song.id).toList();
        _busy.remove(song.id);
      });
      _showMessage('Deleted "${song.title}"');
    } catch (e) {
      if (!mounted) return;
      setState(() => _busy.remove(song.id));
      _showMessage(_messageFor(e));
    }
  }

  String _messageFor(Object e) {
    final message =
        e is MusicRepositoryException ? e.message : 'Something went wrong';
    return message.contains('admin_setup.sql')
        ? 'Run supabase/admin_setup.sql first'
        : message;
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    final songs = _visibleSongs;

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        title: const Text('Manage Songs'),
        backgroundColor: Colors.black54,
        elevation: 0,
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.fromLTRB(
              pageGutter(width),
              16,
              pageGutter(width),
              12,
            ),
            child: _buildSearchBar(),
          ),
          if (_publishingUnavailable) _buildSetupNotice(),
          Expanded(child: _buildBody(songs, width)),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withValues(alpha: 0.12)),
      ),
      child: TextField(
        controller: _searchController,
        style: const TextStyle(color: Colors.white, fontSize: 16),
        decoration: InputDecoration(
          hintText: 'Search songs, artists, or albums',
          hintStyle: TextStyle(
            color: Colors.white.withValues(alpha: 0.5),
            fontSize: 15,
          ),
          prefixIcon: Icon(
            Icons.search,
            color: Colors.white.withValues(alpha: 0.6),
            size: 20,
          ),
          suffixIcon: _query.isEmpty
              ? null
              : GestureDetector(
                  onTap: () => _searchController.clear(),
                  child: Icon(
                    Icons.close,
                    color: Colors.white.withValues(alpha: 0.6),
                    size: 20,
                  ),
                ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 12),
        ),
      ),
    );
  }

  Widget _buildSetupNotice() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.orange.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.orange.withValues(alpha: 0.3)),
      ),
      child: Text(
        'Publishing is unavailable until supabase/admin_setup.sql is applied '
        'to the project. Everything below is being shown, published state '
        'included.',
        style: TextStyle(
          color: Colors.orange.withValues(alpha: 0.9),
          fontSize: 12,
          height: 1.4,
        ),
      ),
    );
  }

  Widget _buildBody(List<Song> songs, double width) {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(color: Colors.white70),
      );
    }

    if (_error != null) {
      return _buildMessage(
        _error!,
        action: TextButton(
          onPressed: _load,
          child: const Text(
            'Try again',
            style: TextStyle(color: Colors.white70),
          ),
        ),
      );
    }

    if (songs.isEmpty) {
      return _buildMessage(
        _query.trim().isEmpty
            ? 'No songs yet'
            : 'Nothing matches "${_query.trim()}"',
      );
    }

    return ListView.separated(
      padding: EdgeInsets.fromLTRB(
        pageGutter(width),
        0,
        pageGutter(width),
        24 + MediaQuery.paddingOf(context).bottom,
      ),
      itemCount: songs.length,
      separatorBuilder: (_, _) => const SizedBox(height: 8),
      itemBuilder: (context, index) => _buildRow(songs[index], width),
    );
  }

  Widget _buildMessage(String message, {Widget? action}) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white.withValues(alpha: 0.6),
                fontSize: 14,
              ),
            ),
            if (action != null) ...[const SizedBox(height: 12), action],
          ],
        ),
      ),
    );
  }

  Widget _buildRow(Song song, double width) {
    final busy = _busy.contains(song.id);
    final isPublished = !_publishingUnavailable && song.isPublished;

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.04),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
      ),
      child: Row(
        children: [
          _buildArtwork(song),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  song.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  [song.artistName, song.albumTitle]
                      .where((s) => s != null && s.isNotEmpty)
                      .join(' · '),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.55),
                    fontSize: 12,
                  ),
                ),
                const SizedBox(height: 6),
                _buildStatusPill(isPublished),
              ],
            ),
          ),
          const SizedBox(width: 8),
          _buildAction(
            icon: isPublished ? Icons.unpublished : Icons.publish,
            tooltip: isPublished ? 'Unpublish' : 'Publish',
            onTap: busy ? null : () => _togglePublished(song),
          ),
          _buildAction(
            icon: Icons.delete_outline,
            tooltip: 'Delete',
            color: const Color(0xFFFF6B6B),
            onTap: busy ? null : () => _confirmDelete(song),
          ),
          if (busy)
            const SizedBox(
              width: 18,
              height: 18,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: Colors.white54,
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildArtwork(Song song) {
    const size = 48.0;
    final cover = song.coverUrl;

    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: cover == null || cover.isEmpty
          ? Container(
              width: size,
              height: size,
              color: Colors.white.withValues(alpha: 0.08),
              child: Icon(
                Icons.music_note,
                size: 20,
                color: Colors.white.withValues(alpha: 0.4),
              ),
            )
          : Image.network(
              cover,
              width: size,
              height: size,
              fit: BoxFit.cover,
              // A broken cover should fall back to the placeholder rather than
              // throw the icon away — seeded rows point at picsum, which
              // 404s whenever the network is unavailable.
              errorBuilder: (context, _, _) => Container(
                width: size,
                height: size,
                color: Colors.white.withValues(alpha: 0.08),
                child: Icon(
                  Icons.music_note,
                  size: 20,
                  color: Colors.white.withValues(alpha: 0.4),
                ),
              ),
            ),
    );
  }

  Widget _buildStatusPill(bool isPublished) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: (isPublished ? Colors.green : Colors.white)
            .withValues(alpha: isPublished ? 0.2 : 0.08),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        isPublished ? 'Published' : 'Draft',
        style: TextStyle(
          color: isPublished
              ? const Color(0xFF4ADE80)
              : Colors.white.withValues(alpha: 0.5),
          fontSize: 10,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _buildAction({
    required IconData icon,
    required String tooltip,
    required VoidCallback? onTap,
    Color color = Colors.white70,
  }) {
    return IconButton(
      onPressed: onTap,
      icon: Icon(icon, size: 20),
      color: color,
      tooltip: tooltip,
      visualDensity: VisualDensity.compact,
      constraints: const BoxConstraints(minWidth: 40, minHeight: 40),
    );
  }
}