import 'dart:math';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:supabase/supabase.dart' show StorageException;
import 'package:snortify/layout_breakpoints.dart';
import 'package:snortify/repository/music_repository.dart';

/// Admin upload form: audio file, optional artwork, and metadata.
///
/// Note on the schema (verified against the live project, not assumed): the
/// `songs` table has no `cover_url`, `artist_name` or `genre` column of its
/// own — artwork lives on `albums.cover_url` and an artist hangs off
/// `albums.artist_id`. So an upload resolves or creates an artist and an
/// album, then points the new track at both. See [MusicRepository.insertSong].
class UploadSongScreen extends StatefulWidget {
  const UploadSongScreen({super.key});

  @override
  State<UploadSongScreen> createState() => _UploadSongScreenState();
}

class _UploadSongScreenState extends State<UploadSongScreen> {
  final _repository = MusicRepository();
  final _title = TextEditingController();
  final _artist = TextEditingController();
  final _album = TextEditingController();
  final _duration = TextEditingController();

  bool _isPublished = false;
  PlatformFile? _audioFile;
  PlatformFile? _artFile;
  bool _isSaving = false;
  String? _status;
  bool _statusIsError = false;

  @override
  void dispose() {
    _title.dispose();
    _artist.dispose();
    _album.dispose();
    _duration.dispose();
    super.dispose();
  }

  Future<void> _pickAudio() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.audio,
      withData: true,
    );
    if (result == null || result.files.isEmpty) return;
    setState(() {
      _audioFile = result.files.first;
      _status = null;
    });
  }

  Future<void> _pickArt() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.image,
      withData: true,
    );
    if (result == null || result.files.isEmpty) return;
    setState(() {
      _artFile = result.files.first;
      _status = null;
    });
  }

  /// Track length in whole seconds.
  ///
  /// `songs.duration_seconds` is NOT NULL, so this has to be a real number.
  /// Parsed from the form rather than sniffed from the file — reading an MP3
  /// frame header means dragging an audio parser into the app for one column.
  int? _parseDuration() {
    final raw = _duration.text.trim();
    if (raw.isEmpty) return null;

    final parts = raw.split(':');
    if (parts.length > 2) return null;

    final seconds = int.tryParse(parts.last);
    if (seconds == null || seconds < 0) return null;
    if (parts.length == 1) return seconds;

    final minutes = int.tryParse(parts.first);
    if (minutes == null || minutes < 0) return null;

    return minutes * 60 + seconds;
  }

  Future<void> _upload() async {
    if (_title.text.trim().isEmpty || _artist.text.trim().isEmpty) {
      _setStatus('Title and artist are required', isError: true);
      return;
    }
    if (_audioFile?.bytes == null) {
      _setStatus('Select an audio file', isError: true);
      return;
    }

    final duration = _parseDuration();
    if (duration == null) {
      _setStatus('Duration must be seconds, or m:ss', isError: true);
      return;
    }

    setState(() {
      _isSaving = true;
      _status = null;
    });

    try {
      // Debug: Check auth state at upload time
      final client = Supabase.instance.client;
      final currentUser = client.auth.currentUser;
      final currentSession = client.auth.currentSession;
      final userId = currentUser?.id;

      print('=== UPLOAD DEBUG ===');
      print('Current user ID: $userId');
      print('Current user email: ${currentUser?.email}');
      print('Has session: ${currentSession != null}');
      print('Session user ID: ${currentSession?.user.id}');

      // CRITICAL: If there's no session, the Storage upload will fail with RLS error
      if (currentSession == null) {
        _setStatus('Session expired - please sign in again', isError: true);
        return;
      }

      final songId = _newSongId();
      final extension = _extensionOf(_audioFile!.name, fallback: 'mp3');
      final audioPath = 'songs/$songId/audio.$extension';
      final artExtension = _extensionOf(
        _artFile?.name ?? '',
        fallback: 'webp',
      );
      final coverPath = 'songs/$songId/cover.$artExtension';

      final storage = client.storage;

      print('Audio bucket: audio-files');
      print('Audio path: $audioPath');
      print('Audio file size: ${_audioFile!.bytes!.length} bytes');

      // uploadBinary, not upload: file_picker hands back a Uint8List, and
      // storage_client's upload() takes a dart:io File — which does not exist
      // on web anyway, and is needless here since the bytes are already in
      // memory.
      //
      // The SupabaseClient automatically includes Authorization headers from
      // the current session, but only if currentSession is not null.
      try {
        await storage.from('audio-files').uploadBinary(
          audioPath,
          _audioFile!.bytes!,
          fileOptions: const FileOptions(contentType: 'audio/mpeg', upsert: true),
        );
        print('Audio upload succeeded');
      } catch (storageError) {
        print('Audio upload failed: $storageError');
        rethrow;
      }

      String? coverRelative;
      if (_artFile?.bytes != null) {
        print('Artwork bucket: album-covers');
        print('Artwork path: $coverPath');
        print('Artwork file size: ${_artFile!.bytes!.length} bytes');

        try {
          await storage.from('album-covers').uploadBinary(
            coverPath,
            _artFile!.bytes!,
            fileOptions: FileOptions(
              contentType: _contentTypeFor(artExtension),
              upsert: true,
            ),
          );
          print('Artwork upload succeeded');
          coverRelative = coverPath;
        } catch (storageError) {
          print('Artwork upload failed: $storageError');
          rethrow;
        }
      }

      // Artist and album are real rows, reused when the names already match so
      // repeated uploads by the same artist do not fragment the catalogue.
      final artistId = await _resolveArtist(_artist.text.trim());
      final albumId = _album.text.trim().isEmpty
          ? null
          : await _resolveAlbum(
              _album.text.trim(),
              artistId,
              coverRelative,
            );

      // Store the bucket-relative path, not a resolved URL:
      // StorageHelper.getPublicUrl turns one into the other on read, so the
      // same value serves playback, artwork, and the delete flow's audio_path.
      await _repository.insertSong(
        id: songId,
        title: _title.text.trim(),
        audioUrl: audioPath,
        audioPath: audioPath,
        durationSeconds: duration,
        artistId: artistId,
        albumId: albumId,
        coverUrl: coverRelative,
        isPublished: _isPublished,
      );

      print('Song row inserted successfully');

      if (!mounted) return;
      setState(() {
        _isSaving = false;
        _status = 'Uploaded "${_title.text.trim()}"';
        _statusIsError = false;
        _title.clear();
        _album.clear();
        _duration.clear();
        _audioFile = null;
        _artFile = null;
        _isPublished = false;
      });
    } catch (e) {
      print('Upload error: $e');
      print('Error type: ${e.runtimeType}');
      if (e is StorageException) {
        print('Storage error - statusCode: ${e.statusCode}');
        print('Storage error - message: ${e.message}');
        print('Storage error - error: ${e.error}');
      }

      if (!mounted) return;
      setState(() {
        _isSaving = false;
        _status = _friendlyError(e);
        _statusIsError = true;
      });
    }
  }

  Future<String> _resolveArtist(String name) async {
    return await _repository.findArtistIdByName(name) ??
        await _repository.createArtist(name);
  }

  Future<String> _resolveAlbum(
    String title,
    String artistId,
    String? coverRelative,
  ) async {
    final existing = await _repository.findAlbumIdByTitle(title, artistId);
    if (existing != null) return existing;

    // Only a genuinely new album takes the uploaded artwork — pointing an
    // existing album at a new cover would restyle every other track on it.
    return _repository.createAlbum(
      title: title,
      artistId: artistId,
      coverUrl: coverRelative,
    );
  }

  /// A v4 UUID.
  ///
  /// `songs.id` is a uuid column, so `DateTime.now().millisecondsSinceEpoch` —
  /// the previous value — would be rejected by Postgres outright.
  String _newSongId() {
    final random = Random.secure();
    final bytes = List<int>.generate(16, (_) => random.nextInt(256));

    // Version 4, variant 1.
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;

    final hex = bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
    return '${hex.substring(0, 8)}-${hex.substring(8, 12)}-'
        '${hex.substring(12, 16)}-${hex.substring(16, 20)}-'
        '${hex.substring(20)}';
  }

  /// The file's extension, lowercased and without the dot.
  String _extensionOf(String name, {required String fallback}) {
    final dot = name.lastIndexOf('.');
    if (dot < 0 || dot == name.length - 1) return fallback;
    final extension = name.substring(dot + 1).toLowerCase();
    return extension.isEmpty ? fallback : extension;
  }

  /// Matches the picker to what the extension actually is — a picker set to
  /// images happily returns a PNG, and telling Supabase it is a webp would
  /// leave it unable to serve it inline.
  String _contentTypeFor(String extension) => switch (extension) {
    'png' => 'image/png',
    'jpg' || 'jpeg' => 'image/jpeg',
    'gif' => 'image/gif',
    _ => 'image/webp',
  };

  String _friendlyError(Object e) {
    final message =
        e is MusicRepositoryException ? e.message : e.toString();
    if (message.contains('is_published')) {
      return 'Run supabase/admin_setup.sql before uploading';
    }
    if (message.contains('42501') || message.contains('row-level security')) {
      return 'Storage rejected the upload — check the admin policies';
    }
    return message;
  }

  void _setStatus(String message, {required bool isError}) {
    setState(() {
      _status = message;
      _statusIsError = isError;
    });
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;

    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      appBar: AppBar(
        title: const Text('Upload Song'),
        backgroundColor: Colors.black54,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.fromLTRB(
          pageGutter(width),
          20,
          pageGutter(width),
          24 + MediaQuery.paddingOf(context).bottom,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildField('Title *', _title),
            _buildField('Artist *', _artist),
            _buildField('Album', _album),
            _buildField('Duration (m:ss or seconds) *', _duration),
            SwitchListTile(
              value: _isPublished,
              onChanged: (value) => setState(() => _isPublished = value),
              activeThumbColor: Colors.white,
              title: const Text(
                'Published',
                style: TextStyle(color: Colors.white, fontSize: 15),
              ),
              subtitle: Text(
                'Off keeps the track out of Browse and Search.',
                style: TextStyle(
                  color: Colors.white.withValues(alpha: 0.5),
                  fontSize: 12,
                ),
              ),
              contentPadding: EdgeInsets.zero,
            ),
            const SizedBox(height: 8),
            _buildPicker(
              icon: Icons.music_note,
              label: _audioFile?.name ?? 'Select audio',
              onTap: _pickAudio,
            ),
            const SizedBox(height: 4),
            _buildPicker(
              icon: Icons.image,
              label: _artFile?.name ?? 'Select artwork (optional)',
              onTap: _pickArt,
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isSaving ? null : _upload,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: _isSaving
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Text(
                        'Upload Song',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
              ),
            ),
            if (_status != null) ...[
              const SizedBox(height: 12),
              Text(
                _status!,
                style: TextStyle(
                  color: _statusIsError
                      ? const Color(0xFFFF6B6B)
                      : const Color(0xFF4ADE80),
                  fontSize: 13,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildField(String label, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: Colors.white70),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }

  Widget _buildPicker({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.white.withValues(alpha: 0.05),
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white.withValues(alpha: 0.1)),
          ),
          child: Row(
            children: [
              Icon(icon, color: Colors.white70, size: 20),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}