import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:snortify/models/music_models.dart';
import 'package:snortify/providers/playback_provider.dart';
import 'package:snortify/repository/music_repository.dart';
import 'package:snortify/widgets/artwork_image.dart';
import 'package:snortify/widgets/favorite_button.dart';
import 'package:snortify/layout_breakpoints.dart';

/// Full playlist view: artwork, metadata, action bar and the tracklist.
///
/// Takes a [playlist] (not an id) so the header renders immediately from
/// whatever the parent already has, then fetches the tracks for
/// [Playlist.id].
class PlaylistDetailScreen extends StatefulWidget {
  final Playlist playlist;

  const PlaylistDetailScreen({super.key, required this.playlist});

  @override
  State<PlaylistDetailScreen> createState() => _PlaylistDetailScreenState();
}

class _PlaylistDetailScreenState extends State<PlaylistDetailScreen> {
  final MusicRepository _repository = MusicRepository();

  late Future<List<Song>> _songsFuture;

  /// Which track is mid-removal, so its row can show a spinner instead of
  /// firing a second delete while the first is in flight.
  String? _removingSongId;

  @override
  void initState() {
    super.initState();
    _songsFuture = _repository.fetchSongsForPlaylist(widget.playlist.id);
  }

  void _reload() {
    setState(() {
      _removingSongId = null;
      _songsFuture = _repository.fetchSongsForPlaylist(widget.playlist.id);
    });
  }

  Future<void> _play(List<Song> songs, int index) async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      await context.read<PlaybackProvider>().playQueue(songs, index);
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('Could not play: $e')));
    }
  }

  /// Loads the whole playlist into the queue and starts from the top.
  Future<void> _playAll(List<Song> songs, {required bool shuffle}) async {
    if (songs.isEmpty) return;

    final playback = context.read<PlaybackProvider>();

    // Set shuffle *before* loading the queue — playQueue() rebuilds the shuffle
    // order from the current flag, so flipping it afterwards would leave the
    // order unshuffled.
    if (playback.shuffleEnabled != shuffle) playback.toggleShuffle();

    await _play(songs, 0);
  }

  Future<void> _removeFromPlaylist(Song song) async {
    final messenger = ScaffoldMessenger.of(context);

    setState(() => _removingSongId = song.id);
    try {
      await _repository.removeSongFromPlaylist(widget.playlist.id, song.id);
      messenger.showSnackBar(
        SnackBar(content: Text('Removed ${song.title} from playlist')),
      );
      _reload();
    } catch (e) {
      if (!mounted) return;
      setState(() => _removingSongId = null);
      messenger.showSnackBar(
        SnackBar(content: Text("Couldn't remove ${song.title}")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final playlist = widget.playlist;

    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;

        return Scaffold(
          backgroundColor: const Color(0xFF121212),
          body: FutureBuilder<List<Song>>(
            future: _songsFuture,
            builder: (context, snapshot) {
              final playback = context.watch<PlaybackProvider>();

              return CustomScrollView(
                slivers: [
                  _buildAppBar(playlist),
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: pagePadding(width, top: 8, bottom: 24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // The header and action bar render from
                          // [playlist] alone, so they stay put while the
                          // tracklist loads — or fails. Passing an empty list
                          // while waiting would briefly claim "0 songs".
                          _buildHeader(
                            playlist,
                            snapshot.data ?? const <Song>[],
                            width,
                          ),
                          const SizedBox(height: 24),
                          _buildActionBar(snapshot.data ?? const <Song>[]),
                          const SizedBox(height: 24),
                          _buildTracklist(snapshot, playback),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        );
      },
    );
  }

  Widget _buildTracklist(
    AsyncSnapshot<List<Song>> snapshot,
    PlaybackProvider playback,
  ) {
    // Order matters: the error branch is checked before the empty branch, but
    // an empty list and a failed query are genuinely different states and must
    // not be collapsed. A failed fetch used to be reported as "couldn't load"
    // even when the real cause was simply that the playlist has no tracks.
    if (snapshot.connectionState == ConnectionState.waiting) {
      return const _TrackListSkeleton();
    }

    if (snapshot.hasError) {
      return _TrackListMessage(
        icon: Icons.cloud_off,
        message: "Couldn't load this playlist",
        actionLabel: 'Try Again',
        onAction: _reload,
      );
    }

    final songs = snapshot.data ?? const <Song>[];
    if (songs.isEmpty) {
      return _TrackListMessage(
        icon: Icons.music_off,
        message:
            'No songs in this playlist yet. Use "Add to Playlist" on any '
            'track to fill it.',
        // Nothing to retry — the empty list is the correct answer, so the
        // only action worth offering is the one that fills the playlist.
        actionLabel: null,
        onAction: null,
      );
    }

    return Column(
      children: List.generate(songs.length, (index) {
        return _buildTrackRow(
          songs: songs,
          index: index,
          isCurrent:
              playback.currentSong?.id == songs[index].id && playback.isPlaying,
        );
      }),
    );
  }

  Widget _buildAppBar(Playlist playlist) {
    return SliverAppBar(
      pinned: true,
      expandedHeight: 0,
      backgroundColor: const Color(0xFF121212),
      surfaceTintColor: Colors.transparent,
      title: Text(
        playlist.title,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(color: Colors.white, fontSize: 16),
      ),
    );
  }

  Widget _buildHeader(Playlist playlist, List<Song> songs, double width) {
    final totalSeconds = songs.fold<int>(
      0,
      (sum, song) => sum + (song.durationSeconds ?? 0),
    );

    // Empty while loading, while erroring, and for a genuinely empty playlist —
    // all three read better as "no metadata" than as a confident "0 songs".
    final details = <String>[
      if (songs.isNotEmpty) '${songs.length} songs',
      if (totalSeconds > 0) _formatMinutes(totalSeconds),
    ].join(' · ');

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: SizedBox(
            width: isMobileWidth(width) ? 120 : 220,
            height: isMobileWidth(width) ? 120 : 220,
            child: ArtworkImage(networkUrl: playlist.coverUrl),
          ),
        ),
        SizedBox(width: isMobileWidth(width) ? 16 : 32),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                playlist.title,
                style: TextStyle(
                  fontSize: isMobileWidth(width) ? 24 : 34,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 6),
              // Playlists here are per-user by construction (RLS scopes every
              // query to auth.uid()), so the creator is always the signed-in
              // user rather than something worth fetching.
              const Text(
                'By You',
                style: TextStyle(fontSize: 18, color: Colors.white70),
              ),
              if (details.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(
                  details,
                  style: const TextStyle(color: Colors.white54, fontSize: 13),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildActionBar(List<Song> songs) {
    final canPlay = songs.isNotEmpty;

    return Row(
      children: [
        ElevatedButton.icon(
          onPressed: canPlay ? () => _playAll(songs, shuffle: false) : null,
          icon: const Icon(Icons.play_arrow, size: 20),
          label: const Text('Play'),
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFFA2D48),
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            reverse: true,
            child: Row(
              children: [
                IconButton(
                  iconSize: 26,
                  color: Colors.white70,
                  icon: const Icon(Icons.shuffle),
                  onPressed: canPlay
                      ? () => _playAll(songs, shuffle: true)
                      : null,
                ),
                IconButton(
                  iconSize: 26,
                  color: Colors.white70,
                  icon: const Icon(Icons.download),
                  onPressed: () {},
                ),
                IconButton(
                  iconSize: 26,
                  color: Colors.white70,
                  icon: const Icon(Icons.more_horiz),
                  onPressed: () {},
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTrackRow({
    required List<Song> songs,
    required int index,
    required bool isCurrent,
  }) {
    final song = songs[index];
    final isRemoving = _removingSongId == song.id;

    return _PlaylistTrackRow(
      trackNumber: index + 1,
      song: song,
      isActive: isCurrent,
      isBusy: isRemoving,
      onTap: isRemoving ? null : () => _play(songs, index),
      onPlayNext: isRemoving ? null : () => _playNext(song),
      onRemove: isRemoving ? null : () => _confirmRemove(song),
    );
  }

  Future<void> _playNext(Song song) async {
    final messenger = ScaffoldMessenger.of(context);
    context.read<PlaybackProvider>().insertNext(song);
    messenger.showSnackBar(
      SnackBar(
        content: Text(
          context.read<PlaybackProvider>().hasQueue
              ? '${song.title} will play next'
              : 'Play something first, then queue tracks',
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  /// Removing a track isn't undoable from here, so ask first.
  Future<void> _confirmRemove(Song song) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: const Color(0xFF1C1C1E),
        title: const Text(
          'Remove from playlist?',
          style: TextStyle(color: Colors.white),
        ),
        content: Text(
          '"${song.title}" will be removed from ${widget.playlist.title}.',
          style: const TextStyle(color: Colors.white70, height: 1.4),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Remove'),
          ),
        ],
      ),
    );

    if (confirmed == true) await _removeFromPlaylist(song);
  }

  static String _formatMinutes(int totalSeconds) {
    final minutes = totalSeconds ~/ 60;
    return '$minutes min';
  }
}

/// One playlist row.
///
/// Unlike `SongListItem`, this shows the album alongside the title — a
/// playlist mixes tracks from many albums, so the album is what distinguishes
/// one row from another.
class _PlaylistTrackRow extends StatefulWidget {
  final int trackNumber;
  final Song song;
  final bool isActive;
  final bool isBusy;
  final VoidCallback? onTap;
  final VoidCallback? onPlayNext;
  final VoidCallback? onRemove;

  const _PlaylistTrackRow({
    required this.trackNumber,
    required this.song,
    required this.isActive,
    required this.isBusy,
    this.onTap,
    this.onPlayNext,
    this.onRemove,
  });

  @override
  State<_PlaylistTrackRow> createState() => _PlaylistTrackRowState();
}

class _PlaylistTrackRowState extends State<_PlaylistTrackRow> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    final song = widget.song;

    // Selection wins over hover so the playing row stays put while the mouse
    // travels across it.
    final background = widget.isActive
        ? Colors.white.withValues(alpha: 0.08)
        : _isHovered
        ? Colors.white.withValues(alpha: 0.05)
        : Colors.transparent;

    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      cursor: widget.onTap == null
          ? SystemMouseCursors.basic
          : SystemMouseCursors.click,
      child: GestureDetector(
        onTap: widget.onTap,
        behavior: HitTestBehavior.opaque,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          color: background,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Row(
            children: [
              SizedBox(
                width: 30,
                child: widget.isBusy
                    ? const SizedBox(
                        width: 14,
                        height: 14,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white38,
                        ),
                      )
                    : widget.isActive
                    ? const Icon(
                        Icons.graphic_eq,
                        color: Color(0xFFFA2D48),
                        size: 18,
                      )
                    : Text(
                        '${widget.trackNumber}',
                        style: const TextStyle(color: Colors.white70),
                      ),
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      song.title,
                      style: TextStyle(
                        color: widget.isActive
                            ? const Color(0xFFFA2D48)
                            : Colors.white,
                        fontSize: 15,
                        fontWeight: widget.isActive
                            ? FontWeight.w600
                            : FontWeight.normal,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      [
                        song.artistName,
                        song.albumTitle,
                      ].whereType<String>().join(' — '),
                      style: const TextStyle(
                        color: Colors.white54,
                        fontSize: 12,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              Text(
                song.durationLabel,
                style: const TextStyle(color: Colors.white70),
              ),
              const SizedBox(width: 8),
              FavoriteButton(songId: song.id, iconSize: 18),
              PopupMenuButton<String>(
                tooltip: 'More',
                iconSize: 18,
                icon: const Icon(Icons.more_horiz, color: Colors.white60),
                color: const Color(0xFF2C2C2E),
                onSelected: (value) {
                  if (value == 'playNext') widget.onPlayNext?.call();
                  if (value == 'remove') widget.onRemove?.call();
                },
                itemBuilder: (context) => [
                  const PopupMenuItem<String>(
                    value: 'playNext',
                    child: Row(
                      children: [
                        Icon(
                          Icons.playlist_play,
                          size: 18,
                          color: Colors.white70,
                        ),
                        SizedBox(width: 12),
                        Text('Play Next'),
                      ],
                    ),
                  ),
                  const PopupMenuItem<String>(
                    value: 'remove',
                    child: Row(
                      children: [
                        Icon(
                          Icons.playlist_remove,
                          size: 18,
                          color: Colors.white70,
                        ),
                        SizedBox(width: 12),
                        Text('Remove from Playlist'),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TrackListSkeleton extends StatelessWidget {
  const _TrackListSkeleton();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: List.generate(
        5,
        (index) => Container(
          height: 46,
          margin: const EdgeInsets.symmetric(vertical: 4),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.04),
            borderRadius: BorderRadius.circular(6),
          ),
        ),
      ),
    );
  }
}

class _TrackListMessage extends StatelessWidget {
  final IconData icon;
  final String message;
  final String? actionLabel;
  final VoidCallback? onAction;

  const _TrackListMessage({
    required this.icon,
    required this.message,
    this.actionLabel,
    this.onAction,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 40),
      child: Center(
        child: Column(
          children: [
            Icon(icon, color: Colors.white24, size: 32),
            const SizedBox(height: 12),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white70, fontSize: 15),
            ),
            if (actionLabel != null) ...[
              const SizedBox(height: 12),
              OutlinedButton(
                onPressed: onAction,
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.white,
                  side: const BorderSide(color: Colors.white24),
                ),
                child: Text(actionLabel!),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
