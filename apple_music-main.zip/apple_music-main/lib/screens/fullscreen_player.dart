import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:palette_generator/palette_generator.dart';
import 'package:snortify/providers/playback_provider.dart';
import 'package:snortify/providers/favorites_provider.dart';
import 'package:snortify/widgets/add_to_playlist_sheet.dart';
import 'package:snortify/models/music_models.dart';
import 'package:snortify/layout_breakpoints.dart';

class FullscreenPlayer extends StatefulWidget {
  const FullscreenPlayer({super.key});

  @override
  State<FullscreenPlayer> createState() => _FullscreenPlayerState();
}

class _FullscreenPlayerState extends State<FullscreenPlayer> {
  Color _backgroundColor = const Color(0xFF1a1a2e);
  double _volume = 0.7;

  /// Cover art of whichever track the palette currently reflects. Used to
  /// re-extract colours when the queue advances rather than only on mount.
  String? _paletteUrl;

  @override
  void initState() {
    super.initState();
    _paletteUrl = context.read<PlaybackProvider>().currentSong?.coverUrl;
    _updatePalette();
  }

  Future<void> _updatePalette() async {
    final song = context.read<PlaybackProvider>().currentSong;
    final imageUrl = song?.coverUrl;

    if (imageUrl != null && imageUrl.startsWith('http')) {
      try {
        final PaletteGenerator generator =
            await PaletteGenerator.fromImageProvider(NetworkImage(imageUrl));
        if (mounted) {
          setState(() {
            _backgroundColor =
                generator.dominantColor?.color ?? const Color(0xFF1a1a2e);
          });
        }
      } catch (e) {
        // Palette generation failed, use default
        if (mounted) {
          setState(() {
            _backgroundColor = const Color(0xFF1a1a2e);
          });
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<PlaybackProvider>(
      builder: (context, playback, child) {
        final song = playback.currentSong;

        // The gradient tracks the artwork in real time, so re-extract whenever
        // the track changes. Scheduled post-frame because this runs in build.
        if (song?.coverUrl != _paletteUrl) {
          _paletteUrl = song?.coverUrl;
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) _updatePalette();
          });
        }

        final isMobile = isMobileWidth(MediaQuery.sizeOf(context).width);

        return Scaffold(
          backgroundColor: Colors.transparent,
          body: Container(
            // Full viewport dark translucent background with gradient
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  _backgroundColor.withValues(alpha: 0.95),
                  Colors.black87,
                ],
              ),
            ),
            child: Stack(
              children: [
                // Main content first (rendered below)
                if (isMobile) _buildMobile(context, playback, song),

                // Main content: Two-Column Hero Layout
                if (!isMobile)
                  Positioned.fill(
                    // Scrollable so a short desktop window (or a scaled-up
                    // system font) scrolls the hero instead of overflowing it.
                    child: SingleChildScrollView(
                      child: Center(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 64,
                            vertical: 48,
                          ),
                          child: ConstrainedBox(
                            constraints: const BoxConstraints(maxWidth: 1200),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                // Left side: Large album artwork
                                Container(
                                  width: 350,
                                  height: 350,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withValues(
                                          alpha: 0.6,
                                        ),
                                        blurRadius: 40,
                                        offset: const Offset(0, 20),
                                        spreadRadius: 5,
                                      ),
                                    ],
                                  ),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(20),
                                    child: song?.coverUrl != null
                                        ? Image.network(
                                            song!.coverUrl!,
                                            fit: BoxFit.cover,
                                            errorBuilder:
                                                (context, error, stackTrace) =>
                                                    Container(
                                                      color: Colors.grey[800],
                                                      child: const Center(
                                                        child: Icon(
                                                          Icons.album,
                                                          color: Colors.white54,
                                                          size: 80,
                                                        ),
                                                      ),
                                                    ),
                                          )
                                        : Container(
                                            color: Colors.grey[800],
                                            child: const Center(
                                              child: Icon(
                                                Icons.album,
                                                color: Colors.white54,
                                                size: 80,
                                              ),
                                            ),
                                          ),
                                  ),
                                ),

                                const SizedBox(width: 80),

                                // Right side: Song info, actions, and controls
                                Flexible(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      // Song title (large, bold white)
                                      Text(
                                        song?.title ?? 'Not Playing',
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 32,
                                          fontWeight: FontWeight.w800,
                                          letterSpacing: -0.5,
                                        ),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),

                                      const SizedBox(height: 12),

                                      // Artist and album (clickable, semi-transparent grey)
                                      GestureDetector(
                                        onTap: () {
                                          // Navigate to artist detail
                                        },
                                        child: Text(
                                          '${playback.currentArtist} • ${song?.title ?? 'Album'}',
                                          style: TextStyle(
                                            color: Colors.white.withValues(
                                              alpha: 0.65,
                                            ),
                                            fontSize: 18,
                                            fontWeight: FontWeight.w400,
                                          ),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),

                                      const SizedBox(height: 36),

                                      // Action pill bar (Favorite, Download, Lyrics, More)
                                      Row(
                                        children: [
                                          Flexible(
                                            child: _buildFavoritePill(song),
                                          ),
                                          const SizedBox(width: 12),
                                          Flexible(
                                            child: _buildActionButton(
                                              Icons.download_outlined,
                                              'Download',
                                              () {},
                                            ),
                                          ),
                                          const SizedBox(width: 12),
                                          Flexible(
                                            child: _buildActionButton(
                                              Icons.chat_bubble_outline,
                                              'Lyrics',
                                              () {},
                                            ),
                                          ),
                                          const SizedBox(width: 12),
                                          Flexible(
                                            child: _buildActionButton(
                                              Icons.more_horiz,
                                              'More',
                                              song == null
                                                  ? () {}
                                                  : () =>
                                                        showAddToPlaylistSheet(
                                                          context,
                                                          songId: song.id,
                                                          songTitle: song.title,
                                                        ),
                                            ),
                                          ),
                                        ],
                                      ),

                                      const SizedBox(height: 56),

                                      // Track progress scrubber
                                      Column(
                                        children: [
                                          SliderTheme(
                                            data: SliderTheme.of(context)
                                                .copyWith(
                                                  trackHeight: 3,
                                                  thumbShape:
                                                      const RoundSliderThumbShape(
                                                        enabledThumbRadius: 7,
                                                        elevation: 2,
                                                      ),
                                                  activeTrackColor:
                                                      Colors.white,
                                                  inactiveTrackColor:
                                                      Colors.white24,
                                                  thumbColor: Colors.white,
                                                ),
                                            child: Slider(
                                              value: playback.progress.clamp(
                                                0.0,
                                                1.0,
                                              ),
                                              onChanged: (value) {
                                                playback.updateProgress(value);
                                              },
                                            ),
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 4,
                                            ),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Text(
                                                  playback
                                                      .currentPositionFormatted,
                                                  style: TextStyle(
                                                    color: Colors.white
                                                        .withValues(alpha: 0.6),
                                                    fontSize: 13,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                ),
                                                Text(
                                                  playback
                                                      .totalDurationFormatted,
                                                  style: TextStyle(
                                                    color: Colors.white
                                                        .withValues(alpha: 0.6),
                                                    fontSize: 13,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),

                                      const SizedBox(height: 32),

                                      // Main playback controls
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          // Shuffle
                                          _buildControlButton(
                                            Icons.shuffle,
                                            () {},
                                            size: 24,
                                            tooltip: 'Shuffle',
                                          ),

                                          // Skip Previous
                                          _buildControlButton(
                                            Icons.skip_previous_rounded,
                                            () => playback.playPrevious(),
                                            size: 36,
                                            tooltip: 'Previous',
                                          ),

                                          // Play/Pause (center, largest)
                                          GestureDetector(
                                            onTap: () =>
                                                playback.togglePlayPause(),
                                            child: Container(
                                              width: 72,
                                              height: 72,
                                              decoration: BoxDecoration(
                                                color: Colors.white.withValues(
                                                  alpha: 0.9,
                                                ),
                                                shape: BoxShape.circle,
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Colors.white
                                                        .withValues(alpha: 0.3),
                                                    blurRadius: 20,
                                                    spreadRadius: 2,
                                                  ),
                                                ],
                                              ),
                                              child: Center(
                                                child: Icon(
                                                  playback.isPlaying
                                                      ? Icons.pause_rounded
                                                      : Icons
                                                            .play_arrow_rounded,
                                                  color: Colors.black,
                                                  size: 40,
                                                ),
                                              ),
                                            ),
                                          ),

                                          // Skip Next
                                          _buildControlButton(
                                            Icons.skip_next_rounded,
                                            () => playback.playNext(),
                                            size: 36,
                                            tooltip: 'Next',
                                          ),

                                          // Repeat
                                          _buildControlButton(
                                            Icons.repeat,
                                            () {},
                                            size: 24,
                                            tooltip: 'Repeat',
                                          ),
                                        ],
                                      ),

                                      const SizedBox(height: 36),

                                      // Volume control slider (right side)
                                      Row(
                                        children: [
                                          const Text(
                                            'Volume',
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 13,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                          const SizedBox(width: 16),
                                          Expanded(
                                            child: SliderTheme(
                                              data: SliderTheme.of(context)
                                                  .copyWith(
                                                    trackHeight: 2,
                                                    thumbShape:
                                                        const RoundSliderThumbShape(
                                                          enabledThumbRadius: 6,
                                                        ),
                                                    activeTrackColor:
                                                        Colors.white,
                                                    inactiveTrackColor:
                                                        Colors.white24,
                                                    thumbColor: Colors.white,
                                                  ),
                                              child: Slider(
                                                value: _volume,
                                                onChanged: (value) {
                                                  setState(() {
                                                    _volume = value;
                                                  });
                                                },
                                                min: 0.0,
                                                max: 1.0,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),

                // Buttons rendered last (on top)
                // Top-left back button (mobile only, inside SafeArea)
                if (isMobile)
                  Positioned(
                    top: 24,
                    left: 24,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
                        child: Container(
                          width: 36,
                          height: 36,
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.12),
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.15),
                              width: 0.5,
                            ),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: IconButton(
                            icon: const Icon(
                              Icons.chevron_left,
                              color: Colors.white,
                              size: 22,
                            ),
                            padding: EdgeInsets.zero,
                            onPressed: () => Navigator.pop(context),
                            tooltip: 'Back',
                          ),
                        ),
                      ),
                    ),
                  ),

                // Top-right close button (rendered on top, last child)
                Positioned(
                  top: 24,
                  right: 24,
                  child: GestureDetector(
                    onTap: () => Navigator.of(context).maybePop(),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
                        child: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.12),
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.15),
                              width: 0.5,
                            ),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Center(
                            child: Icon(
                              Icons.close,
                              color: Colors.white,
                              size: 24,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  /// the scrubber and the transport controls, over the artwork-derived
  /// gradient that [build] already paints behind both layouts.
  ///
  /// The whole column scrolls: a small phone in landscape, or one with a large
  /// system font, has less height than the fixed stack of artwork + text +
  /// pill row + scrubber + transport needs, and a `Column` in a fixed-height
  /// sheet reports that as a RenderFlex overflow.
  Widget _buildMobile(
    BuildContext context,
    PlaybackProvider playback,
    Song? song,
  ) {
    return SafeArea(
      child: LayoutBuilder(
        builder: (context, constraints) {
          // The chrome below the artwork is a fixed set of heights; whatever
          // the viewport has left goes to the artwork instead of overflowing.
          const chromeHeight = 260.0;
          final artworkSize = (constraints.maxWidth.clamp(0.0, 320.0)).clamp(
            0.0,
            (constraints.maxHeight - chromeHeight).clamp(0.0, 320.0),
          );

          return SingleChildScrollView(
            child: ConstrainedBox(
              // minHeight lets a short viewport scroll while a tall one still
              // centres its content.
              constraints: BoxConstraints(minHeight: constraints.maxHeight),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(28, 16, 28, 24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const SizedBox(height: 24),
                    Center(child: _buildMobileArtwork(song, artworkSize)),
                    const SizedBox(height: 32),
                    Text(
                      song?.title ?? 'Not Playing',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.w700,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 6),
                    Text(
                      playback.currentArtist,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 15,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 24),
                    _buildPillRow(song),
                    const SizedBox(height: 28),
                    _buildMobileScrubber(playback),
                    const SizedBox(height: 24),
                    _buildMobileTransport(playback),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  /// Square artwork with rounded corners and a drop shadow, capped at [size].
  Widget _buildMobileArtwork(Song? song, double size) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.45),
            blurRadius: 28,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: song?.coverUrl != null
            ? Image.network(
                song!.coverUrl!,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) =>
                    _artworkFallback(),
              )
            : _artworkFallback(),
      ),
    );
  }

  Widget _artworkFallback() {
    return Container(
      color: Colors.white10,
      child: const Center(
        child: Icon(Icons.album, color: Colors.white38, size: 72),
      ),
    );
  }

  /// The translucent capsule of icon-only actions: Lyrics, Favorite, Audio
  /// stream, More, Queue.
  ///
  /// The Favorite button is its own `Consumer` so that `context.select` is only
  /// ever called from that widget's own build. It used to be called twice here
  /// — this is a plain method, not a widget's build — and provider throws
  /// "Tried to use context.select outside of the build method of a widget"
  /// for exactly that.
  Widget _buildPillRow(Song? song) {
    return Container(
      height: 52,
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: Colors.white.withValues(alpha: 0.14)),
      ),
      child: Row(
        children: [
          _buildPillAction(
            icon: Icons.chat_bubble_outline,
            tooltip: 'Lyrics',
            onPressed: () {},
          ),
          _FavoritePillAction(song: song),
          _buildPillAction(
            icon: Icons.graphic_eq,
            tooltip: 'Audio',
            onPressed: () {},
          ),
          _buildPillAction(
            icon: Icons.more_horiz,
            tooltip: 'More',
            onPressed: song == null
                ? () {}
                : () => showAddToPlaylistSheet(
                    context,
                    songId: song.id,
                    songTitle: song.title,
                  ),
          ),
          _buildPillAction(
            icon: Icons.format_list_bulleted,
            tooltip: 'Queue',
            onPressed: () {},
          ),
        ],
      ),
    );
  }

  Widget _buildPillAction({
    required IconData icon,
    required String tooltip,
    required VoidCallback onPressed,
    Color color = Colors.white,
  }) {
    return Expanded(
      child: Tooltip(
        message: tooltip,
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.circular(26),
          child: Center(child: Icon(icon, color: color, size: 20)),
        ),
      ),
    );
  }

  Widget _buildMobileScrubber(PlaybackProvider playback) {
    return Column(
      children: [
        SliderTheme(
          data: SliderTheme.of(context).copyWith(
            trackHeight: 4,
            thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
            overlayShape: const RoundSliderOverlayShape(overlayRadius: 14),
            activeTrackColor: Colors.white,
            inactiveTrackColor: Colors.white24,
            thumbColor: Colors.white,
          ),
          child: Slider(
            value: playback.progress.clamp(0.0, 1.0),
            onChanged: (value) => playback.updateProgress(value),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                playback.currentPositionFormatted,
                style: const TextStyle(color: Colors.white, fontSize: 11),
              ),
              Text(
                playback.totalDurationFormatted,
                style: const TextStyle(color: Colors.white, fontSize: 11),
              ),
            ],
          ),
        ),
      ],
    );
  }

  /// Symmetric transport row: AirPlay, shuffle, skip-previous, play/pause,
  /// skip-next, repeat.
  ///
  /// Skip-previous sits directly beside the play button rather than at the far
  /// edge, so the pair reads as one control with the play key centred between
  /// two equal-weight neighbours. AirPlay / shuffle lead and repeat closes, and
  /// shuffle and repeat are two independent toggles — the previous version
  /// overloaded one button to do both, so a user could not turn shuffle back
  /// off without first cycling the repeat mode.
  Widget _buildMobileTransport(PlaybackProvider playback) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        _buildControlButton(Icons.airplay, () {}, size: 20, tooltip: 'AirPlay'),
        IconButton(
          tooltip: playback.shuffleEnabled ? 'Shuffle on' : 'Shuffle off',
          iconSize: 22,
          icon: Icon(
            Icons.shuffle,
            color: playback.shuffleEnabled ? Colors.white : Colors.white54,
          ),
          onPressed: playback.hasQueue ? playback.toggleShuffle : null,
        ),
        _buildControlButton(
          Icons.skip_previous,
          playback.hasQueue ? playback.playPrevious : null,
          size: 36,
          tooltip: 'Previous',
        ),
        GestureDetector(
          onTap: playback.hasQueue ? playback.togglePlayPause : null,
          child: Container(
            width: 64,
            height: 64,
            decoration: const BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
            ),
            child: Icon(
              playback.isPlaying
                  ? Icons.pause_rounded
                  : Icons.play_arrow_rounded,
              color: Colors.black,
              size: 36,
            ),
          ),
        ),
        _buildControlButton(
          Icons.skip_next,
          playback.hasQueue ? playback.playNext : null,
          size: 36,
          tooltip: 'Next',
        ),
        IconButton(
          tooltip: playback.loopMode.name,
          iconSize: 22,
          icon: Icon(
            playback.loopMode == LoopMode.one
                ? Icons.repeat_one
                : Icons.repeat,
            color: playback.loopMode == LoopMode.off
                ? Colors.white54
                : Colors.white,
          ),
          onPressed: playback.hasQueue ? playback.cycleLoopMode : null,
        ),
      ],
    );
  }

  /// The Favorite pill. Reads the shared favourites state so it stays in sync
  /// with the heart on the mini player and every tracklist.
  Widget _buildFavoritePill(Song? song) {
    if (song == null) {
      return _buildActionButton(Icons.star_border, 'Favorite', () {});
    }

    return Consumer<FavoritesProvider>(
      builder: (context, favorites, _) {
        final isFavorite = favorites.isFavorite(song.id);
        return _buildActionButton(
          isFavorite ? Icons.favorite : Icons.star_border,
          'Favorite',
          () => context.read<FavoritesProvider>().toggle(song.id),
        );
      },
    );
  }

  Widget _buildActionButton(
    IconData icon,
    String label,
    VoidCallback onPressed,
  ) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.circular(24),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, color: Colors.white, size: 18),
                const SizedBox(width: 6),
                Text(
                  label,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Builds a control button (Shuffle, Skip Previous, Skip Next, Repeat)
  ///
  /// [onPressed] is nullable so a transport slot can stay visible but inert
  /// while nothing is queued — an `IconButton` that drops to zero width would
  /// shift every other control out of its symmetric slot.
  Widget _buildControlButton(
    IconData icon,
    VoidCallback? onPressed, {
    double size = 24,
    String tooltip = '',
  }) {
    return Tooltip(
      message: tooltip,
      child: IconButton(
        icon: Icon(
          icon,
          color: onPressed == null ? Colors.white24 : Colors.white,
          size: size,
        ),
        onPressed: onPressed,
        splashRadius: 28,
      ),
    );
  }
}

/// One slot of the pill row: the favourite toggle.
///
/// Extracted into a real widget so its `context.select` runs from a build
/// method. It renders as `Expanded` to keep its slot the same width as the
/// icon-only actions either side of it.
class _FavoritePillAction extends StatelessWidget {
  final Song? song;

  const _FavoritePillAction({required this.song});

  @override
  Widget build(BuildContext context) {
    final song = this.song;

    if (song == null) {
      return Expanded(
        child: Center(
          child: Icon(Icons.star_border, color: Colors.white, size: 20),
        ),
      );
    }

    return Expanded(
      child: Consumer<FavoritesProvider>(
        builder: (context, favorites, _) {
          final isFavorite = favorites.isFavorite(song.id);

          return Tooltip(
            message: 'Favorite',
            child: InkWell(
              onTap: () => context.read<FavoritesProvider>().toggle(song.id),
              borderRadius: BorderRadius.circular(26),
              child: Center(
                child: Icon(
                  isFavorite ? Icons.favorite : Icons.star_border,
                  color: isFavorite ? const Color(0xFFFA2D48) : Colors.white,
                  size: 20,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
