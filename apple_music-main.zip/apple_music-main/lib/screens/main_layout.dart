import 'package:flutter/material.dart';
import 'package:snortify/screens/listen_now_screen.dart';
import 'package:snortify/screens/tabs/browse_screen.dart';
import 'package:snortify/screens/tabs/radio_screen.dart';
import 'package:snortify/screens/tabs/library_screen.dart';
import 'package:snortify/screens/tabs/mobile_library_view.dart';
import 'package:snortify/screens/tabs/search_screen.dart';
import 'package:snortify/widgets/mini_player.dart';
import 'package:snortify/screens/fullscreen_player.dart';
import 'package:snortify/widgets/desktop_sidebar.dart';
import 'package:snortify/widgets/desktop_header.dart';
import 'package:snortify/widgets/mobile_bottom_nav.dart';
import 'package:snortify/widgets/account_sheet.dart';
import 'package:snortify/layout_breakpoints.dart';

class MainLayout extends StatefulWidget {
  const MainLayout({super.key});

  @override
  State<MainLayout> createState() => _MainLayoutState();
}

class _MainLayoutState extends State<MainLayout> {
  int _selectedIndex = 0;

  /// Which Library section the sidebar last asked for. Held here because the
  /// Library screen is built once and reused, so a new section has to be
  /// pushed in rather than remounted.
  LibrarySection _librarySection = LibrarySection.playlists;

  /// Sidebar label of the row that should render as active. Empty when the
  /// selection came from the header pill instead.
  String _activeSidebarLabel = 'Home';

  /// Tab index for each Library section, so header/sidebar stay in sync when
  /// the sidebar jumps straight to "Artists".
  int get _libraryTabIndex => 3;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
      _activeSidebarLabel = _labelForTab(index);
      if (index == _libraryTabIndex) {
        _librarySection = LibrarySection.playlists;
      }
    });
  }

  /// Handles a sidebar selection.
  void _onSidebarSelected(SidebarDestination destination) {
    switch (destination) {
      case SidebarTab(:final index):
        _onItemTapped(index);

      case SidebarLibrarySection(:final section):
        setState(() {
          _librarySection = section;
          _selectedIndex = _libraryTabIndex;
          _activeSidebarLabel = _labelForSection(section);
        });

      case SidebarNotice(:final message):
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(message),
            duration: const Duration(seconds: 2),
          ),
        );
    }
  }

  static String _labelForTab(int index) => switch (index) {
    0 => 'Home',
    1 => 'New',
    2 => 'Radio',
    3 => 'Library',
    4 => 'Search',
    _ => '',
  };

  static String _labelForSection(LibrarySection section) => switch (section) {
    LibrarySection.playlists => 'All Playlists',
    LibrarySection.songs => 'Songs',
    LibrarySection.artists => 'Artists',
    LibrarySection.albums => 'Albums',
  };

  void _showFullscreenPlayer(bool isMobile) {
    if (isMobile) {
      // On phones the player slides up over the content instead of taking it
      // over with a modal dialog — the nav pill and mini player stay reachable
      // underneath the scrim.
      showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        barrierColor: Colors.black54,
        builder: (context) => const FullscreenPlayer(),
      );
      return;
    }

    showDialog<void>(
      context: context,
      barrierColor: Colors.transparent,
      builder: (context) => const FullscreenPlayer(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isMobile = isMobileWidth(constraints.maxWidth);
        return isMobile ? _buildMobile() : _buildDesktop();
      },
    );
  }

  /// Rebuilt per section so switching it swaps in a fresh Library screen,
  /// while switching tabs keeps the existing state (scroll, fetches).
  ///
  /// Takes [isMobile] so the Library tab can pick its phone variant without
  /// `LibraryScreen` having to measure the viewport itself.
  Widget _pageFor(bool isMobile) => switch (_selectedIndex) {
    0 => const ListenNowScreen(),
    1 => const BrowseScreen(),
    2 => const RadioScreen(),
    3 =>
      isMobile
          ? MobileLibraryView(section: _librarySection)
          : LibraryScreen(section: _librarySection),
    _ => const SearchScreen(),
  };

  Widget _buildDesktop() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF121212),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white10),
      ),
      margin: const EdgeInsets.all(8),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: Row(
            children: [
              DesktopSidebar(
                activeLabel: _activeSidebarLabel,
                onSelected: _onSidebarSelected,
              ),
              Expanded(
                child: Stack(
                  children: [
                    Column(
                      children: [
                        DesktopHeader(
                          selectedIndex: _selectedIndex,
                          onTabSelected: _onItemTapped,
                        ),
                        Expanded(child: _pageFor(false)),
                      ],
                    ),
                    MiniPlayer(onTap: () => _showFullscreenPlayer(false)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMobile() {
    return Scaffold(
      backgroundColor: const Color(0xFF121212),
      body: Stack(
        children: [
          // Both overlays float above the page, so the page reserves room for
          // them in its bottom padding rather than the Stack clipping it.
          Positioned.fill(
            child: Padding(
              padding: const EdgeInsets.only(bottom: kMobileOverlayInset),
              child: _pageFor(true),
            ),
          ),
          // Signed-in identity, admin access and sign-out. Desktop has the same
          // button in its header; without it the phone build has no route to
          // any of them. Pages pad themselves by pageTopInset(context, base: n)
          // rather than a SafeArea here, since SafeArea would also inset the
          // bottom that the overlays already reserve.
          Positioned(
            top: pageTopInset(context, base: 8),
            right: 12,
            child: const AccountButton(size: 32),
          ),
          Positioned(
            left: 12,
            right: 12,
            bottom: 86,
            child: SafeArea(
              top: false,
              child: MiniPlayer(
                isMobile: true,
                onTap: () => _showFullscreenPlayer(true),
              ),
            ),
          ),
          Positioned(
            left: 12,
            right: 12,
            bottom: 12,
            child: SafeArea(
              top: false,
              child: MobileBottomNav(
                selectedIndex: _selectedIndex,
                onSelected: _onItemTapped,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
