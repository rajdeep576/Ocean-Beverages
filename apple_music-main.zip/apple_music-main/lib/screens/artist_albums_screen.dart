import 'package:flutter/material.dart';

import 'package:snortify/layout_breakpoints.dart';
import 'package:snortify/widgets/music_tile.dart';

class ArtistAlbumsScreen extends StatefulWidget {
  const ArtistAlbumsScreen({super.key});

  @override
  State<ArtistAlbumsScreen> createState() => _ArtistAlbumsScreenState();
}

class _ArtistAlbumsScreenState extends State<ArtistAlbumsScreen> {
  bool _isGridView = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1A1A1A),
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Row(
                children: [
                  const Text(
                    'Albums > LINKIN PARK',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const Spacer(),
                  IconButton(
                    onPressed: () {},
                    icon: const Icon(Icons.sort, color: Colors.white60),
                  ),
                  IconButton(
                    onPressed: () => setState(() => _isGridView = false),
                    icon: Icon(
                      Icons.list,
                      color: _isGridView ? Colors.white60 : Colors.white,
                    ),
                  ),
                  IconButton(
                    onPressed: () => setState(() => _isGridView = true),
                    icon: Icon(
                      Icons.grid_view,
                      color: _isGridView ? Colors.white : Colors.white60,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Container(
                    width: 200,
                    height: 35,
                    decoration: BoxDecoration(
                      color: Colors.white10,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const TextField(
                      decoration: InputDecoration(
                        prefixIcon: Icon(
                          Icons.search,
                          size: 18,
                          color: Colors.white54,
                        ),
                        hintText: 'Search Albums',
                        hintStyle: TextStyle(
                          color: Colors.white54,
                          fontSize: 13,
                        ),
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(vertical: 8),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            sliver: _isGridView
                ? SliverLayoutBuilder(
                    // The column count and the ratio both depend on the
                    // width, which a fixed `const` delegate cannot express.
                    // Five columns on a 360dp phone gave each tile ~48dp of
                    // width and ~64dp of height — less than the artwork alone,
                    // so the labels were clipped to nothing. `SliverLayoutBuilder`
                    // hands back the resolved extent to compute against.
                    builder: (context, constraints) {
                      const spacing = 20.0;
                      final available = constraints.crossAxisExtent - 40;
                      final columns = gridColumnCount(
                        available,
                        minItemWidth: 140,
                        spacing: spacing,
                        min: 2,
                        max: 6,
                      );
                      final tileWidth = gridTileWidth(
                        available,
                        columns,
                        spacing: spacing,
                      );

                      return SliverGrid.builder(
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: columns,
                          crossAxisSpacing: spacing,
                          mainAxisSpacing: spacing,
                          childAspectRatio: tileChildAspectRatio(tileWidth),
                        ),
                        itemCount: 10,
                        itemBuilder: (context, index) => const _AlbumCard(),
                      );
                    },
                  )
                : SliverList.builder(
                    itemCount: 10,
                    itemBuilder: (context, index) => ListTile(
                      title: Text(
                        'Album $index',
                        style: const TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

/// Placeholder album card.
///
/// Built with [MusicTile] rather than a hand-rolled `Column`: the card's two
/// labels had no `maxLines` and no `overflow`, so any title longer than the
/// (previously ~48dp) cell threw a RenderFlex overflow instead of
/// ellipsising.
class _AlbumCard extends StatelessWidget {
  const _AlbumCard();

  @override
  Widget build(BuildContext context) {
    return MusicTile(
      title: 'Album Title',
      subtitle: '2024 • 14 Songs',
      assetPath: 'assets/albums/album01.jpg',
    );
  }
}
