import 'dart:ui';

import 'package:flutter/material.dart';

/// The five top-level destinations, in the order the mobile design shows them.
///
/// Each entry carries the tab index `MainLayout` uses, so tapping a destination
/// and picking a destination programmatically go through the same path.
enum MobileDestination {
  home('Home', Icons.home_outlined, Icons.home, 0),
  trending('Trending', Icons.trending_up, Icons.trending_up, 1),
  forYou('For You', Icons.auto_awesome_outlined, Icons.auto_awesome, 2),
  library('Library', Icons.library_music_outlined, Icons.library_music, 3),
  search('Search', Icons.search, Icons.search, 4);

  const MobileDestination(
    this.label,
    this.icon,
    this.selectedIcon,
    this.tabIndex,
  );

  final String label;
  final IconData icon;
  final IconData selectedIcon;

  /// Index into `MainLayout`'s tab list — named `tabIndex` because `Enum` owns
  /// `index` and a concrete enum member cannot redeclare it.
  final int tabIndex;
}

/// The mobile navigation bar: a floating capsule pinned above the bottom edge.
///
/// It floats rather than spanning edge to edge so it reads as an overlay on top
/// of the content (and of the mini player stacked just above it), matching the
/// mobile design.
class MobileBottomNav extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onSelected;

  const MobileBottomNav({
    super.key,
    required this.selectedIndex,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(34),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
        child: Container(
          height: 68,
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.08),
            borderRadius: BorderRadius.circular(34),
            border: Border.all(color: Colors.white.withValues(alpha: 0.12)),
          ),
          child: Row(
            children: [
              for (final destination in MobileDestination.values)
                Expanded(
                  child: _MobileNavItem(
                    destination: destination,
                    isSelected: selectedIndex == destination.tabIndex,
                    onTap: () => onSelected(destination.tabIndex),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

/// One destination inside the capsule.
///
/// Selection is shown as a soft rounded-rectangle glow behind the icon rather
/// than a filled pill, so the capsule itself stays visually quiet.
class _MobileNavItem extends StatelessWidget {
  final MobileDestination destination;
  final bool isSelected;
  final VoidCallback onTap;

  const _MobileNavItem({
    required this.destination,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final icon = isSelected ? destination.selectedIcon : destination.icon;
    final color = isSelected ? Colors.white : Colors.white54;

    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Center(
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          curve: Curves.easeOut,
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 7),
          decoration: BoxDecoration(
            color: isSelected
                ? Colors.white.withValues(alpha: 0.14)
                : Colors.transparent,
            borderRadius: BorderRadius.circular(20),
            boxShadow: isSelected
                ? [
                    BoxShadow(
                      color: Colors.white.withValues(alpha: 0.10),
                      blurRadius: 12,
                      spreadRadius: 1,
                    ),
                  ]
                : null,
          ),
          child: Icon(icon, color: color, size: 22),
        ),
      ),
    );
  }
}
