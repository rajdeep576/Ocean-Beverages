import 'package:flutter/material.dart';

/// Renders artwork from either a bundled asset or a remote URL.
///
/// Callers holding a Supabase value (already resolved to a public URL by
/// `StorageHelper`) should pass [networkUrl]; existing screens that reference
/// files in `assets/` keep passing [assetPath].
class ArtworkImage extends StatelessWidget {
  final String? assetPath;
  final String? networkUrl;
  final double? width;
  final double? height;
  final BoxFit fit;

  const ArtworkImage({
    super.key,
    this.assetPath,
    this.networkUrl,
    this.width,
    this.height,
    this.fit = BoxFit.cover,
  }) : assert(
         assetPath != null || networkUrl != null,
         'Provide at least one of assetPath or networkUrl.',
       );

  @override
  Widget build(BuildContext context) {
    Widget errorBuilder(BuildContext context, Object error, StackTrace? stack) {
      return Container(
        color: Colors.grey[800],
        child: const Center(
          child: Icon(Icons.music_note, color: Colors.grey, size: 24),
        ),
      );
    }

    if (networkUrl != null) {
      return Image.network(
        networkUrl!,
        width: width,
        height: height,
        fit: fit,
        errorBuilder: errorBuilder,
        loadingBuilder: (context, child, progress) {
          if (progress == null) return child;
          return Container(
            color: Colors.grey[800],
            child: const Center(
              child: SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: Colors.white24,
                ),
              ),
            ),
          );
        },
      );
    }

    return Image.asset(
      assetPath!,
      width: width,
      height: height,
      fit: fit,
      errorBuilder: errorBuilder,
    );
  }
}
