import 'package:flutter/material.dart';
import 'package:snortify/layout_breakpoints.dart';
import 'package:snortify/widgets/music_tile.dart';

/// A titled, horizontally scrolling row of cover-art tiles.
///
/// Used by the Browse and Library tabs for the Snortify "shelf" pattern —
/// heading with a trailing chevron, then a horizontally scrolling strip.
class ContentShelf extends StatelessWidget {
  final String title;
  final String? subtitle;
  final int itemCount;
  final Widget Function(BuildContext context, int index) itemBuilder;

  /// Largest width of each tile's artwork.
  ///
  /// The real width is `min(itemWidth, a fraction of the available width)`, so
  /// a phone still shows a peek of the next tile — which is what tells the
  /// user the row scrolls at all.
  final double itemWidth;

  const ContentShelf({
    super.key,
    required this.title,
    required this.itemCount,
    required this.itemBuilder,
    this.subtitle,
    this.itemWidth = 180,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        // A fixed 180px tile left only one visible on a phone; scaling it to
        // the viewport keeps the shelf usable at every width.
        final width = (constraints.maxWidth / 2.6).clamp(110.0, itemWidth);

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      if (subtitle != null) ...[
                        const SizedBox(height: 2),
                        Text(
                          subtitle!,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Color(0xFF8E8E93),
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                const Icon(
                  Icons.chevron_right,
                  color: Colors.white38,
                  size: 22,
                ),
              ],
            ),
            const SizedBox(height: 14),
            SizedBox(
              // Square artwork plus the label block `MusicTile` puts under
              // it. Was a literal `42` here, about 15px less than the two
              // title lines and the subtitle actually need — so every shelf
              // tile clipped its own second line.
              height: tileHeight(width),
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                clipBehavior: Clip.none,
                itemCount: itemCount,
                separatorBuilder: (_, _) => const SizedBox(width: 18),
                itemBuilder: (context, index) =>
                    SizedBox(width: width, child: itemBuilder(context, index)),
              ),
            ),
          ],
        );
      },
    );
  }
}

/// A square tile used inside a [ContentShelf], where the parent has already
/// fixed the width. `MusicTile` sizes itself from its parent, so this just
/// pins the aspect ratio.
class ShelfTile extends StatelessWidget {
  final String title;
  final String? subtitle;
  final String? networkUrl;
  final String? assetPath;
  final VoidCallback? onTap;

  const ShelfTile({
    super.key,
    required this.title,
    this.subtitle,
    this.networkUrl,
    this.assetPath,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return MusicTile(
      title: title,
      subtitle: subtitle,
      networkUrl: networkUrl,
      assetPath: assetPath,
      onTap: onTap,
    );
  }
}
