import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:snortify/widgets/artwork_image.dart';

class MusicTile extends StatelessWidget {
  final String title;
  final String? subtitle;
  final String? assetPath;
  final String? networkUrl;
  final VoidCallback? onTap;

  const MusicTile({
    super.key,
    required this.title,
    this.subtitle,
    this.assetPath,
    this.networkUrl,
    this.onTap,
  }) : assert(
         assetPath != null || networkUrl != null,
         'Provide at least one of assetPath or networkUrl.',
       );

  @override
  Widget build(BuildContext context) {
    final tile = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: AspectRatio(
            aspectRatio: 1,
            child: Stack(
              children: [
                // 1. Artwork (local asset or remote URL)
                ArtworkImage(assetPath: assetPath, networkUrl: networkUrl),

                // 2. The Glass effect (optional, keep if it looks good, or remove if too dark)
                Positioned.fill(
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 0, sigmaY: 0),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.05),
                        border: Border.all(
                          color: Colors.white.withValues(alpha: 0.1),
                          width: 1,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        // `Flexible` (not `Expanded`) so the two labels can share whatever the
        // grid cell leaves, with maxLines holding each one to a fixed height —
        // a `Flexible` Text with no maxLines sizes to its content and overflows
        // the cell on a long title.
        Flexible(
          child: Text(
            title,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w600,
              fontSize: 14,
            ),
          ),
        ),
        if (subtitle != null)
          Flexible(
            child: Text(
              subtitle!,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(color: Colors.grey[400], fontSize: 12),
            ),
          ),
      ],
    );

    if (onTap == null) return tile;
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: MouseRegion(cursor: SystemMouseCursors.click, child: tile),
    );
  }
}
