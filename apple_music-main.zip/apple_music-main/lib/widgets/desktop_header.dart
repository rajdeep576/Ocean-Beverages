import 'dart:ui';

import 'package:flutter/material.dart';

import 'package:snortify/widgets/account_sheet.dart';
import 'package:snortify/widgets/traffic_lights.dart';

class DesktopHeader extends StatelessWidget {
  final int selectedIndex;
  final Function(int) onTabSelected;

  const DesktopHeader({
    super.key,
    required this.selectedIndex,
    required this.onTabSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Left: Traffic Lights
          const Align(alignment: Alignment.centerLeft, child: TrafficLights()),
          // Center: Buttons + Pill Navigation
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildNavButton(Icons.chevron_left),
              const SizedBox(width: 8),
              _buildNavButton(Icons.chevron_right),
              const SizedBox(width: 20),
              _buildNavPill(),
            ],
          ),
          // Right: Profile avatar button
          const Align(
            alignment: Alignment.centerRight,
            child: AccountButton(),
          ),
        ],
      ),
    );
  }

  Widget _buildNavButton(IconData icon) {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.05),
        shape: BoxShape.circle,
        border: Border.all(color: Colors.white.withValues(alpha: 0.1)),
      ),
      child: Icon(icon, color: Colors.white70, size: 16),
    );
  }

  Widget _buildNavPill() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(50),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.08),
            borderRadius: BorderRadius.circular(50),
            border: Border.all(color: Colors.white.withValues(alpha: 0.12)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _navItem(0, Icons.home_filled, 'Home'),
              _navItem(1, Icons.local_fire_department, 'Trending'),
              _navItem(2, Icons.auto_awesome, 'For You'),
              _navItem(3, Icons.library_music, 'Library'),
              _navItem(4, Icons.search, 'Search'),
            ],
          ),
        ),
      ),
    );
  }

  Widget _navItem(int index, IconData icon, String label) {
    bool isSelected = selectedIndex == index;
    return GestureDetector(
      onTap: () => onTabSelected(index),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected
              ? Colors.white.withValues(alpha: 0.15)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(50),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color: isSelected ? Colors.white : Colors.white70,
              size: 16,
            ),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                color: isSelected ? Colors.white : Colors.white70,
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
