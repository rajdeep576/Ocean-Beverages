import 'package:flutter/material.dart';
import 'package:snortify/widgets/song_actions_menu.dart';

class SongListItem extends StatefulWidget {
  final int trackNumber;
  final String title;

  /// Id of the underlying song, used to persist favorite / playlist actions.
  /// Null hides the row's trailing actions.
  final String? songId;

  final String duration;
  final bool isActive;
  final VoidCallback? onTap;

  const SongListItem({
    super.key,
    required this.trackNumber,
    required this.title,
    this.songId,
    required this.duration,
    this.isActive = false,
    this.onTap,
  });

  @override
  State<SongListItem> createState() => _SongListItemState();
}

class _SongListItemState extends State<SongListItem> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    // The playing row reads as an active playlist entry: tinted background,
    // accent-coloured title, and a pause glyph where the track number sits.
    final accent = widget.isActive;

    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      cursor: widget.onTap == null
          ? SystemMouseCursors.basic
          : SystemMouseCursors.click,
      child: GestureDetector(
        onTap: widget.onTap,
        behavior: HitTestBehavior.opaque,
        child: Container(
          color: accent
              ? Colors.white.withValues(alpha: 0.08)
              : _isHovered
              ? Colors.white.withValues(alpha: 0.05)
              : Colors.transparent,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: LayoutBuilder(
            builder: (context, constraints) {
              // IconButton's 48dp minimum plus the "…" menu left under 150px
              // for the title on a 360dp phone, so the download affordance —
              // which is a no-op anyway — is the first thing to go.
              final showDownload = constraints.maxWidth >= 420;

              return Row(
                children: [
                  SizedBox(
                    width: 30,
                    child: accent
                        ? const Icon(
                            Icons.graphic_eq,
                            color: Color(0xFFFA2D48),
                            size: 18,
                          )
                        : Text(
                            '${widget.trackNumber}',
                            style: const TextStyle(color: Colors.white70),
                          ),
                  ),
                  Expanded(
                    child: Text(
                      widget.title,
                      style: TextStyle(
                        color: accent ? const Color(0xFFFA2D48) : Colors.white,
                        fontSize: 15,
                        fontWeight: accent
                            ? FontWeight.w600
                            : FontWeight.normal,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  Text(
                    widget.duration,
                    style: const TextStyle(color: Colors.white70),
                  ),
                  SizedBox(width: showDownload ? 16 : 4),
                  if (showDownload)
                    IconButton(
                      onPressed: () {},
                      icon: const Icon(
                        Icons.download,
                        size: 18,
                        color: Colors.white60,
                      ),
                    ),
                  if (widget.songId != null)
                    SongActionsMenu(
                      songId: widget.songId!,
                      songTitle: widget.title,
                    ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}
