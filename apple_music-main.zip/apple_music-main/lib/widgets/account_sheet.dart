import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:snortify/screens/admin/admin_dashboard.dart';
import 'package:snortify/screens/auth_screen.dart';

/// The avatar button and the account sheet behind it.
///
/// Lives here rather than in `desktop_header.dart` so the desktop header and
/// the mobile shell open one implementation instead of two copies that drift.
class AccountButton extends StatelessWidget {
  const AccountButton({super.key, this.size = 36});

  /// Diameter of the circle. The mobile shell uses a smaller one so it can sit
  /// in a 44px touch target without dominating the top of the screen.
  final double size;

  @override
  Widget build(BuildContext context) {
    final user = Supabase.instance.client.auth.currentUser;
    final avatarUrl = user?.userMetadata?['avatar_url'] as String?;

    return GestureDetector(
      onTap: () => showAccountSheet(context),
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.white.withValues(alpha: 0.08),
          border: Border.all(
            color: Colors.white.withValues(alpha: 0.15),
            width: 0.5,
          ),
        ),
        child: ClipOval(
          child: avatarUrl != null
              ? Image.network(
                  avatarUrl,
                  fit: BoxFit.cover,
                  errorBuilder: (_, _, _) => const Icon(
                    Icons.person,
                    color: Colors.white54,
                    size: 18,
                  ),
                )
              : const Icon(Icons.person, color: Colors.white70, size: 18),
        ),
      ),
    );
  }
}

/// Opens the account sheet: identity, the admin link when the signed-in user
/// has the admin role, and log out.
Future<void> showAccountSheet(BuildContext context) async {
  final user = Supabase.instance.client.auth.currentUser;

  // Read the role rather than caching it, so an account promoted after its
  // last sign-in still sees the admin link. Any failure here means "not an
  // admin" — the dashboard enforces the same check server-side regardless.
  String role = 'user';
  if (user != null) {
    try {
      final res = await Supabase.instance.client
          .from('profiles')
          .select('role')
          .eq('id', user.id)
          .maybeSingle();
      role = res?['role']?.toString() ?? 'user';
    } catch (_) {
      role = 'user';
    }
  }

  if (!context.mounted) return;

  await showModalBottomSheet(
    context: context,
    backgroundColor: const Color(0xFF1a1a2e),
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (ctx) => Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            user?.email ?? 'Guest',
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w600,
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Account',
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.6),
              fontSize: 13,
            ),
          ),
          const SizedBox(height: 12),
          if (role == 'admin')
            ListTile(
              leading: const Icon(
                Icons.admin_panel_settings,
                color: Colors.white70,
              ),
              title: const Text(
                'Admin Dashboard',
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                Navigator.pop(ctx);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const AdminDashboardScreen(),
                  ),
                );
              },
            ),
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.white70),
            title: const Text(
              'Log Out',
              style: TextStyle(color: Colors.white),
            ),
            onTap: () {
              Navigator.pop(ctx);
              _confirmLogout(context);
            },
          ),
        ],
      ),
    ),
  );
}

void _confirmLogout(BuildContext context) {
  showDialog(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: const Color(0xFF2C2C2E),
      title: const Text('Log out?', style: TextStyle(color: Colors.white)),
      content: const Text(
        "You'll need to sign in again to access your account.",
        style: TextStyle(color: Colors.white70),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: const Text('Cancel', style: TextStyle(color: Colors.white70)),
        ),
        TextButton(
          onPressed: () async {
            Navigator.pop(ctx);
            await Supabase.instance.client.auth.signOut();
            if (!context.mounted) return;
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (_) => const AuthScreen()),
              (_) => false,
            );
          },
          child: const Text('Log Out', style: TextStyle(color: Colors.white)),
        ),
      ],
    ),
  );
}