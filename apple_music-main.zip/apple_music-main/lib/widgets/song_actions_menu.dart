import 'package:flutter/material.dart';

import 'package:snortify/widgets/add_to_playlist_sheet.dart';
import 'package:snortify/widgets/favorite_button.dart';

/// The "…" action menu shown on song rows and in the players.
///
/// The favorite entry is a [FavoriteButton] rather than a menu item so it
/// reflects live state, and "Add to Playlist" opens the shared picker sheet.
class SongActionsMenu extends StatelessWidget {
  final String songId;
  final String songTitle;

  /// Position the menu button appears in — the row's trailing slot, or the
  /// player's far-right cluster.
  final double iconSize;

  const SongActionsMenu({
    super.key,
    required this.songId,
    required this.songTitle,
    this.iconSize = 18,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        PopupMenuButton<String>(
          tooltip: 'More',
          iconSize: iconSize,
          icon: const Icon(Icons.more_horiz, color: Colors.white60),
          color: const Color(0xFF2C2C2E),
          onSelected: (value) {
            if (value == 'addToPlaylist') {
              showAddToPlaylistSheet(
                context,
                songId: songId,
                songTitle: songTitle,
              );
            }
          },
          itemBuilder: (context) => [
            const PopupMenuItem<String>(
              value: 'addToPlaylist',
              child: Row(
                children: [
                  Icon(Icons.playlist_add, size: 18, color: Colors.white70),
                  SizedBox(width: 12),
                  Text('Add to Playlist'),
                ],
              ),
            ),
          ],
        ),
        FavoriteButton(songId: songId, iconSize: iconSize),
      ],
    );
  }
}
