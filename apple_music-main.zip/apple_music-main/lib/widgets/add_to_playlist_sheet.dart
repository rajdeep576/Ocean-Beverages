import 'package:flutter/material.dart';

import 'package:snortify/models/music_models.dart';
import 'package:snortify/repository/music_repository.dart';

/// Shows a sheet listing the user's playlists, and adds [song] to whichever
/// one they tap.
///
/// Returns immediately; the sheet fetches its own list so callers only need a
/// song id. Success and failure both surface as a SnackBar from the app's
/// messenger, which reads the same whether the sheet was opened over a track
/// row or the player.
Future<void> showAddToPlaylistSheet(
  BuildContext context, {
  required String songId,
  required String songTitle,
}) {
  return showModalBottomSheet<void>(
    context: context,
    backgroundColor: const Color(0xFF2C2C2E),
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
    ),
    isScrollControlled: true,
    builder: (sheetContext) =>
        _AddToPlaylistSheet(songId: songId, songTitle: songTitle),
  );
}

class _AddToPlaylistSheet extends StatefulWidget {
  final String songId;
  final String songTitle;

  const _AddToPlaylistSheet({required this.songId, required this.songTitle});

  @override
  State<_AddToPlaylistSheet> createState() => _AddToPlaylistSheetState();
}

class _AddToPlaylistSheetState extends State<_AddToPlaylistSheet> {
  final MusicRepository _repository = MusicRepository();

  List<Playlist> _playlists = const [];
  bool _isLoading = true;
  String? _error;

  /// The playlist currently being written to, or having a track appended to.
  /// Non-null disables the whole list so a second tap can't queue a second
  /// write against the same row.
  String? _busyPlaylistId;

  /// True while the "New Playlist" composer is open above the list.
  bool _isCreating = false;

  @override
  void initState() {
    super.initState();
    _loadPlaylists();
  }

  Future<void> _loadPlaylists() async {
    try {
      final playlists = await _repository.fetchUserPlaylists();
      if (!mounted) return;
      setState(() {
        _playlists = playlists;
        _isLoading = false;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString();
        _isLoading = false;
      });
    }
  }

  /// Reports an outcome on the app's messenger, then dismisses the sheet.
  ///
  /// The messenger is captured before any await so the SnackBar still has
  /// somewhere to go once the route is gone.
  void _finish(String message, {bool isError = false}) {
    final navigator = Navigator.of(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? const Color(0xFF8E1B2A) : null,
      ),
    );
    // `pop` returns the route's result, which is void here — dismiss without
    // awaiting it.
    navigator.pop();
  }

  Future<void> _addTo(Playlist playlist) async {
    setState(() => _busyPlaylistId = playlist.id);

    try {
      await _repository.addSongToPlaylist(playlist.id, widget.songId);
      _finish('Added "${widget.songTitle}" to ${playlist.title}');
    } catch (e) {
      if (!mounted) return;
      setState(() => _busyPlaylistId = null);
      // The sheet stays open so the user can pick a different playlist.
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Couldn't add to ${playlist.title}"),
          backgroundColor: const Color(0xFF8E1B2A),
        ),
      );
    }
  }

  /// Creates the playlist and adds the track in one go, so the user does not
  /// have to create it and then find it in the list to add the song.
  Future<void> _createAndAdd(String title) async {
    setState(() => _busyPlaylistId = _newPlaylistRowId);

    try {
      final playlist = await _repository.createPlaylist(title);
      await _repository.addSongToPlaylist(playlist.id, widget.songId);
      _finish('Created ${playlist.title} and added "${widget.songTitle}"');
    } catch (e) {
      if (!mounted) return;
      setState(() => _busyPlaylistId = null);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            e is MusicRepositoryException &&
                    e.message.startsWith('Playlist needs a title')
                ? 'Give the playlist a name first'
                : "Couldn't create that playlist",
          ),
          backgroundColor: const Color(0xFF8E1B2A),
        ),
      );
    }
  }

  /// Sentinel id for the composer's row. A real playlist id is a UUID, so this
  /// cannot collide with one.
  static const _newPlaylistRowId = '__new__';

  /// Opens the title composer. Returns the entered title, or null if the user
  /// backed out.
  Future<String?> _promptForTitle() {
    return showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF1C1C1E),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (sheetContext) => const _NewPlaylistSheet(),
    );
  }

  Future<void> _startNewPlaylist() async {
    // The busy flag stays set across the composer, not just across the write —
    // otherwise a tap on a playlist row behind the composer would queue a
    // second write.
    setState(() {
      _isCreating = true;
      _busyPlaylistId = _newPlaylistRowId;
    });

    final title = await _promptForTitle();
    if (!mounted) return;

    if (title == null) {
      setState(() {
        _isCreating = false;
        _busyPlaylistId = null;
      });
      return;
    }

    await _createAndAdd(title);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(
          // `isScrollControlled` lets the sheet go past the half-height default
          // when the composer is open; the cap keeps it from becoming a
          // full-screen dialog.
          maxHeight: _isCreating ? 520 : 420,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 16),
            Center(
              child: Container(
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                'Add to Playlist',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            const SizedBox(height: 12),
            Flexible(child: _buildBody()),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 40),
        child: Center(child: CircularProgressIndicator(color: Colors.white54)),
      );
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // The composer sits at the top of the list rather than the bottom so it
        // doesn't move when the playlist count changes.
        _NewPlaylistTile(
          isBusy: _busyPlaylistId == _newPlaylistRowId,
          onPressed: _startNewPlaylist,
        ),
        const Divider(height: 1, color: Colors.white12),

        // One error message covers both the fetch and the composer: when the
        // list can't load, "New Playlist" is the only action that can work.
        if (_error != null)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
            child: Text(
              "Couldn't load your playlists.",
              style: const TextStyle(color: Colors.white54),
            ),
          )
        else if (_playlists.isEmpty)
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 24),
            child: Text(
              "You don't have any playlists yet — make one above.",
              style: TextStyle(color: Colors.white54),
            ),
          )
        else
          Flexible(
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: _playlists.length,
              itemBuilder: (context, index) {
                final playlist = _playlists[index];
                final isBusy = _busyPlaylistId == playlist.id;

                return ListTile(
                  enabled: _busyPlaylistId == null,
                  leading: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: Colors.white10,
                      borderRadius: BorderRadius.circular(6),
                      image: DecorationImage(
                        image: NetworkImage(playlist.coverUrl),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  title: Text(
                    playlist.title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  trailing: isBusy
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white54,
                          ),
                        )
                      : const Icon(Icons.chevron_right, color: Colors.white30),
                  onTap: () => _addTo(playlist),
                );
              },
            ),
          ),
      ],
    );
  }
}

/// The "New Playlist" row: the plus button that opens the title composer.
class _NewPlaylistTile extends StatelessWidget {
  final bool isBusy;
  final VoidCallback onPressed;

  const _NewPlaylistTile({required this.isBusy, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      enabled: !isBusy,
      leading: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: Colors.white10,
          borderRadius: BorderRadius.circular(6),
        ),
        child: isBusy
            ? const Padding(
                padding: EdgeInsets.all(11),
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: Colors.white54,
                ),
              )
            : const Icon(Icons.add, color: Colors.white70, size: 22),
      ),
      title: const Text(
        'New Playlist',
        style: TextStyle(
          color: Colors.white,
          fontSize: 14,
          fontWeight: FontWeight.w500,
        ),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      onTap: onPressed,
    );
  }
}

/// The title composer for a new playlist.
///
/// Pops with the trimmed title, or null if the user dismisses it.
class _NewPlaylistSheet extends StatefulWidget {
  const _NewPlaylistSheet();

  @override
  State<_NewPlaylistSheet> createState() => _NewPlaylistSheetState();
}

class _NewPlaylistSheetState extends State<_NewPlaylistSheet> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focus = FocusNode();

  @override
  void initState() {
    super.initState();
    // Raised after the sheet's entrance animation settles, so the keyboard
    // doesn't animate in underneath it.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _focus.requestFocus();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _submit() {
    final title = _controller.text.trim();
    if (title.isEmpty) return;
    Navigator.of(context).pop(title);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      // Lifts the sheet clear of the keyboard, which would otherwise cover the
      // field outright.
      padding: EdgeInsets.only(bottom: MediaQuery.viewInsetsOf(context).bottom),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 20),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                'New Playlist',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: TextField(
                controller: _controller,
                focusNode: _focus,
                autofocus: false,
                autocorrect: false,
                textCapitalization: TextCapitalization.words,
                textInputAction: TextInputAction.done,
                style: const TextStyle(color: Colors.white, fontSize: 15),
                cursorColor: const Color(0xFFFA2D48),
                onSubmitted: (_) => _submit(),
                decoration: InputDecoration(
                  hintText: 'Playlist name',
                  hintStyle: const TextStyle(
                    color: Colors.white38,
                    fontSize: 15,
                  ),
                  filled: true,
                  fillColor: Colors.white.withValues(alpha: 0.06),
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 14,
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
              child: Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: () => Navigator.of(context).pop(),
                      style: TextButton.styleFrom(
                        foregroundColor: Colors.white70,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      child: const Text('Cancel'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextButton(
                      onPressed: _submit,
                      style: TextButton.styleFrom(
                        foregroundColor: const Color(0xFFFA2D48),
                        backgroundColor: Colors.white.withValues(alpha: 0.08),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      child: const Text('Create'),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
