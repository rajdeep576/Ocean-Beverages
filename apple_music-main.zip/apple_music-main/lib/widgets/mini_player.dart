import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:ui';
import 'package:snortify/providers/playback_provider.dart';
import 'package:snortify/widgets/song_actions_menu.dart';
import 'package:snortify/models/music_models.dart';

class MiniPlayer extends StatelessWidget {
  final VoidCallback onTap;

  /// Renders the compact mobile card instead of the desktop transport bar.
  ///
  /// The mobile card carries only artwork, title, artist, AirPlay and
  /// play/pause — the rest of the transport lives in the full-screen player,
  /// which is what tapping this opens.
  final bool isMobile;

  const MiniPlayer({super.key, required this.onTap, this.isMobile = false});

  @override
  Widget build(BuildContext context) {
    return Consumer<PlaybackProvider>(
      builder: (context, playback, child) {
        final song = playback.currentSong;

        if (isMobile) {
          return _buildMobile(context, playback, song);
        }

        return Align(
          alignment: Alignment.bottomCenter,
          child: Padding(
            padding: const EdgeInsets.only(bottom: 24),
            child: GestureDetector(
              onTap: onTap,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                  child: Container(
                    width: 700,
                    height: 70,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.05),
                      border: Border.all(
                        color: Colors.white.withValues(alpha: 0.1),
                      ),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // Left: Artwork, Info & Slider
                        Row(
                          children: [
                            Container(
                              width: 50,
                              height: 50,
                              decoration: BoxDecoration(
                                color: Colors.white10,
                                borderRadius: BorderRadius.circular(8),
                                image: song?.coverUrl != null
                                    ? DecorationImage(
                                        image: NetworkImage(song!.coverUrl!),
                                        fit: BoxFit.cover,
                                      )
                                    : null,
                              ),
                              child: song?.coverUrl == null
                                  ? const Icon(
                                      Icons.music_note,
                                      color: Colors.white54,
                                      size: 24,
                                    )
                                  : null,
                            ),
                            const SizedBox(width: 12),
                            Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  song?.title ?? 'Not Playing',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                Text(
                                  song == null
                                      ? 'Unknown Artist'
                                      : '${playback.currentArtist} · '
                                            '${playback.currentPositionFormatted} / '
                                            '${playback.totalDurationFormatted}',
                                  style: const TextStyle(
                                    color: Colors.white54,
                                    fontSize: 11,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                SizedBox(
                                  width: 150,
                                  height: 2,
                                  child: LinearProgressIndicator(
                                    value: playback.progress,
                                    color: Colors.white70,
                                    backgroundColor: Colors.white24,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),

                        // Center/Right Controls
                        Row(
                          children: [
                            IconButton(
                              tooltip: 'Shuffle',
                              iconSize: 20,
                              icon: Icon(
                                Icons.shuffle,
                                color: playback.shuffleEnabled
                                    ? Colors.white
                                    : Colors.white54,
                              ),
                              onPressed: playback.hasQueue
                                  ? playback.toggleShuffle
                                  : null,
                            ),
                            IconButton(
                              iconSize: 24,
                              icon: const Icon(
                                Icons.skip_previous,
                                color: Colors.white,
                              ),
                              onPressed: playback.hasQueue
                                  ? () => playback.playPrevious()
                                  : null,
                            ),
                            IconButton(
                              iconSize: 32,
                              icon: Icon(
                                playback.isPlaying
                                    ? Icons.pause_circle_filled
                                    : Icons.play_circle_fill,
                                color: Colors.white,
                              ),
                              onPressed: playback.hasQueue
                                  ? () => playback.togglePlayPause()
                                  : null,
                            ),
                            IconButton(
                              iconSize: 24,
                              icon: const Icon(
                                Icons.skip_next,
                                color: Colors.white,
                              ),
                              onPressed: playback.hasQueue
                                  ? () => playback.playNext()
                                  : null,
                            ),
                            IconButton(
                              tooltip: playback.loopMode.name,
                              iconSize: 20,
                              icon: Icon(
                                playback.loopMode == LoopMode.one
                                    ? Icons.repeat_one
                                    : Icons.repeat,
                                color: playback.loopMode == LoopMode.off
                                    ? Colors.white54
                                    : Colors.white,
                              ),
                              onPressed: playback.hasQueue
                                  ? playback.cycleLoopMode
                                  : null,
                            ),
                          ],
                        ),

                        // Far Right Actions
                        Row(
                          children: [
                            if (song != null)
                              SongActionsMenu(
                                songId: song.id,
                                songTitle: song.title,
                              )
                            else ...[
                              IconButton(
                                iconSize: 18,
                                icon: const Icon(
                                  Icons.more_horiz,
                                  color: Colors.white54,
                                ),
                                onPressed: null,
                              ),
                              IconButton(
                                iconSize: 18,
                                icon: const Icon(
                                  Icons.favorite_border,
                                  color: Colors.white38,
                                ),
                                onPressed: null,
                              ),
                            ],
                            IconButton(
                              iconSize: 18,
                              icon: const Icon(
                                Icons.airplay,
                                color: Colors.white54,
                              ),
                              onPressed: () {},
                            ),
                            IconButton(
                              iconSize: 18,
                              icon: const Icon(
                                Icons.volume_up,
                                color: Colors.white54,
                              ),
                              onPressed: () => _showVolumePopup(context),
                            ),
                            IconButton(
                              iconSize: 18,
                              icon: const Icon(
                                Icons.chat_bubble_outline,
                                color: Colors.white54,
                              ),
                              onPressed: () {},
                            ),
                            IconButton(
                              iconSize: 18,
                              icon: const Icon(
                                Icons.format_list_bulleted,
                                color: Colors.white54,
                              ),
                              onPressed: () {},
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  /// The mobile mini player: a frosted card sized by its parent, floating
  /// directly above the bottom nav pill.
  ///
  /// A `Stack` rather than a padded `Row` because the progress hairline has to
  /// sit flush against the card's bottom edge. Inside a padded row it would be
  /// inset by the card padding and read as a third line of content between the
  /// text and the bottom edge, which is not how the design shows it.
  Widget _buildMobile(
    BuildContext context,
    PlaybackProvider playback,
    Song? song,
  ) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
          child: Container(
            // Fixed height, so the card never grows a row of text and pushes
            // itself into the nav pill below.
            height: 60,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.white.withValues(alpha: 0.12)),
            ),
            child: Stack(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: Row(
                    children: [
                      _buildMobileArtwork(song),
                      const SizedBox(width: 10),
                      // The only elastic child: the trailing buttons keep
                      // their intrinsic width, so a long track title
                      // ellipsises rather than pushing them out of the row.
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              song?.title ?? 'Not Playing',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            Text(
                              playback.currentArtist,
                              style: const TextStyle(
                                color: Colors.white60,
                                fontSize: 11,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                      _buildMobileIcon(
                        icon: playback.isPlaying
                            ? Icons.pause
                            : Icons.play_arrow,
                        tooltip: playback.isPlaying ? 'Pause' : 'Play',
                        size: 28,
                        onPressed: playback.hasQueue
                            ? playback.togglePlayPause
                            : null,
                      ),
                      _buildMobileIcon(
                        icon: Icons.skip_next,
                        tooltip: 'Next',
                        size: 26,
                        onPressed: playback.hasQueue
                            ? playback.playNext
                            : null,
                      ),
                    ],
                  ),
                ),
                // Flush against the bottom edge, and given a wider hit area
                // than its 2px height by wrapping it in an IgnorePointer-
                // free `Positioned` with vertical slack — the card's own
                // `onTap` already opens the full player, so the hairline
                // must not swallow any taps.
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: ClipRRect(
                    borderRadius: const BorderRadius.vertical(
                      bottom: Radius.circular(14),
                    ),
                    child: LinearProgressIndicator(
                      value: playback.progress,
                      minHeight: 2,
                      color: Colors.white70,
                      backgroundColor: Colors.transparent,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// A trailing mini-player button with an explicit tap target.
  ///
  /// `IconButton`'s default 48dp minimum is wider than the card can spare on a
  /// small phone, so both the size and the target are pinned here.
  Widget _buildMobileIcon({
    required IconData icon,
    required String tooltip,
    required double size,
    required VoidCallback? onPressed,
  }) {
    return SizedBox(
      width: 40,
      height: 40,
      child: IconButton(
        tooltip: tooltip,
        padding: EdgeInsets.zero,
        iconSize: size,
        constraints: const BoxConstraints.tightFor(width: 40, height: 40),
        icon: Icon(icon, color: Colors.white),
        onPressed: onPressed,
      ),
    );
  }

  Widget _buildMobileArtwork(Song? song) {
    return Container(
      width: 42,
      height: 42,
      decoration: BoxDecoration(
        color: Colors.white10,
        borderRadius: BorderRadius.circular(8),
        image: song?.coverUrl != null
            ? DecorationImage(
                image: NetworkImage(song!.coverUrl!),
                fit: BoxFit.cover,
              )
            : null,
      ),
      child: song?.coverUrl == null
          ? const Icon(Icons.music_note, color: Colors.white54, size: 20)
          : null,
    );
  }

  /// Vertical volume slider, matching the macOS Music popover.
  void _showVolumePopup(BuildContext context) {
    double volume = 0.8;
    showDialog<void>(
      context: context,
      barrierColor: Colors.transparent,
      builder: (dialogContext) => _VolumeDialog(
        initialVolume: volume,
        onChanged: (value) {
          volume = value;
          context.read<PlaybackProvider>().setVolume(value);
        },
      ),
    );
  }
}

class _VolumeDialog extends StatefulWidget {
  final double initialVolume;
  final ValueChanged<double> onChanged;

  const _VolumeDialog({required this.initialVolume, required this.onChanged});

  @override
  State<_VolumeDialog> createState() => _VolumeDialogState();
}

class _VolumeDialogState extends State<_VolumeDialog> {
  late double _volume = widget.initialVolume;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF2C2C2E),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.volume_mute, color: Colors.white54, size: 18),
            SizedBox(
              width: 140,
              child: SliderTheme(
                data: SliderTheme.of(context).copyWith(
                  activeTrackColor: Colors.white,
                  inactiveTrackColor: Colors.white24,
                  thumbColor: Colors.white,
                  trackHeight: 3,
                ),
                child: Slider(
                  value: _volume,
                  onChanged: (value) {
                    setState(() => _volume = value);
                    widget.onChanged(value);
                  },
                ),
              ),
            ),
            const Icon(Icons.volume_up, color: Colors.white54, size: 18),
          ],
        ),
      ),
    );
  }
}
