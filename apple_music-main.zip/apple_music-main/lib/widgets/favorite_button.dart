import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:snortify/providers/favorites_provider.dart';

/// The heart toggle used everywhere a song can be favourited.
///
/// Reads and writes shared state via [FavoritesProvider], so the same song
/// shows a filled heart in the mini player, the full-screen player and every
/// tracklist at once, and the change is persisted immediately.
class FavoriteButton extends StatelessWidget {
  final String songId;
  final double iconSize;
  final String tooltip;
  final Color? activeColor;

  const FavoriteButton({
    super.key,
    required this.songId,
    this.iconSize = 18,
    this.tooltip = 'Favorite',
    this.activeColor = const Color(0xFFFA2D48),
  });

  @override
  Widget build(BuildContext context) {
    return Consumer<FavoritesProvider>(
      builder: (context, favorites, _) {
        final isFavorite = favorites.isFavorite(songId);

        // Dim while the write is in flight so a double tap reads as ignored
        // rather than queued.
        final pending = favorites.isPending(songId);

        return IconButton(
          iconSize: iconSize,
          tooltip: isFavorite ? 'Remove from Favorites' : tooltip,
          icon: Icon(
            isFavorite ? Icons.favorite : Icons.favorite_border,
            color: isFavorite
                ? activeColor
                : (pending ? Colors.white24 : Colors.white60),
          ),
          onPressed: () => _toggle(context),
        );
      },
    );
  }

  Future<void> _toggle(BuildContext context) async {
    final messenger = ScaffoldMessenger.of(context);
    final result = await context.read<FavoritesProvider>().toggle(songId);

    if (result == null) {
      messenger.showSnackBar(
        const SnackBar(content: Text("Couldn't update favorite")),
      );
    }
  }
}
