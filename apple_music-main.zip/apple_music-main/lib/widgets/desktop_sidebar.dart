import 'package:flutter/material.dart';
import 'package:snortify/screens/tabs/library_screen.dart';

/// Where each sidebar entry sends the user.
///
/// The top-level entries map onto [MainLayout]'s tab index; the rest carry
/// enough information for the layout to decide what to show (a Library
/// section, a notice, or a genre sheet).
sealed class SidebarDestination {
  const SidebarDestination();
}

/// Switches to a top-level tab by index.
class SidebarTab extends SidebarDestination {
  const SidebarTab(this.index);

  final int index;

  @override
  bool operator ==(Object other) => other is SidebarTab && other.index == index;

  @override
  int get hashCode => index.hashCode;
}

/// Opens the Library tab on a specific section.
class SidebarLibrarySection extends SidebarDestination {
  const SidebarLibrarySection(this.section);

  final LibrarySection section;

  @override
  bool operator ==(Object other) =>
      other is SidebarLibrarySection && other.section == section;

  @override
  int get hashCode => section.hashCode;
}

/// Nothing to show yet — the layout surfaces a notice instead.
class SidebarNotice extends SidebarDestination {
  const SidebarNotice(this.message);

  final String message;

  @override
  bool operator ==(Object other) =>
      other is SidebarNotice && other.message == message;

  @override
  int get hashCode => message.hashCode;
}

class DesktopSidebar extends StatelessWidget {
  final String activeLabel;
  final void Function(SidebarDestination) onSelected;

  const DesktopSidebar({
    super.key,
    required this.activeLabel,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 220,
      // Refined surface to match reference darker translucent style
      decoration: BoxDecoration(
        color: const Color(0xFF0A0A0A).withValues(alpha: 0.5),
        border: Border(
          right: BorderSide(
            color: Colors.white.withValues(alpha: 0.08),
            width: 0.5,
          ),
        ),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: ListView(
        children: [
          const SizedBox(height: 50), // Header spacing
          _buildNavItem(
            Icons.search,
            'Search',
            onTap: () => onSelected(const SidebarTab(4)),
          ),
          _buildNavItem(
            Icons.home_outlined,
            'Home',
            onTap: () => onSelected(const SidebarTab(0)),
          ),
          _buildNavItem(
            Icons.fiber_new_outlined,
            'New',
            onTap: () => onSelected(const SidebarTab(1)),
          ),
          _buildNavItem(
            Icons.radio_outlined,
            'Radio',
            onTap: () => onSelected(const SidebarTab(2)),
          ),

          const SizedBox(height: 24),
          _buildSectionHeader('Library'),
          _buildNavItem(
            Icons.push_pin_outlined,
            'Pins',
            onTap: () =>
                onSelected(const SidebarNotice('Pins aren\'t wired up yet.')),
          ),
          _buildNavItem(
            Icons.history,
            'Recently Added',
            onTap: () => onSelected(
              const SidebarNotice('Recently Added isn\'t wired up yet.'),
            ),
          ),
          _buildNavItem(
            Icons.music_note,
            'Songs',
            onTap: () =>
                onSelected(SidebarLibrarySection(LibrarySection.songs)),
          ),
          _buildNavItem(
            Icons.person_outline,
            'Artists',
            onTap: () =>
                onSelected(SidebarLibrarySection(LibrarySection.artists)),
          ),
          _buildNavItem(
            Icons.album_outlined,
            'Albums',
            onTap: () =>
                onSelected(SidebarLibrarySection(LibrarySection.albums)),
          ),
          _buildNavItem(
            Icons.category_outlined,
            'Genres',
            onTap: () => onSelected(const SidebarTab(1)),
          ),

          const SizedBox(height: 24),
          _buildSectionHeader('Playlists'),
          _buildNavItem(
            Icons.playlist_play,
            'All Playlists',
            onTap: () => onSelected(
              const SidebarLibrarySection(LibrarySection.playlists),
            ),
          ),
          _buildNavItem(
            Icons.favorite_border,
            'Favorite Songs',
            onTap: () =>
                onSelected(const SidebarLibrarySection(LibrarySection.songs)),
          ),
          _buildNavItem(
            Icons.music_note,
            'Chill Songs',
            onTap: () => onSelected(
              const SidebarNotice(
                'Curated playlists need seeded data — see supabase/playlists.sql.',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.4),
              fontSize: 11,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.4,
            ),
          ),
          Icon(
            Icons.chevron_right,
            color: Colors.white.withValues(alpha: 0.3),
            size: 14,
          ),
        ],
      ),
    );
  }

  Widget _buildNavItem(
    IconData icon,
    String label, {
    required VoidCallback onTap,
  }) {
    final isSelected = activeLabel == label;

    return _SidebarRow(
      icon: icon,
      label: label,
      isSelected: isSelected,
      onTap: onTap,
    );
  }
}

/// One sidebar row. Handles its own hover state so the sidebar stays a
/// stateless widget driven entirely by [activeLabel].
class _SidebarRow extends StatefulWidget {
  final IconData icon;
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  const _SidebarRow({
    required this.icon,
    required this.label,
    required this.isSelected,
    required this.onTap,
  });

  @override
  State<_SidebarRow> createState() => _SidebarRowState();
}

class _SidebarRowState extends State<_SidebarRow> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    final isSelected = widget.isSelected;

    // Selection wins over hover so the active row stays put while the mouse
    // travels across it.
    final background = isSelected
        ? Colors.white.withValues(alpha: 0.12)
        : _isHovered
        ? Colors.white.withValues(alpha: 0.06)
        : Colors.transparent;

    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      child: GestureDetector(
        onTap: widget.onTap,
        behavior: HitTestBehavior.opaque,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          margin: const EdgeInsets.symmetric(vertical: 2, horizontal: 8),
          decoration: BoxDecoration(
            color: background,
            borderRadius: BorderRadius.circular(8),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          child: Row(
            children: [
              Icon(
                widget.icon,
                color: isSelected ? Colors.redAccent : Colors.white60,
                size: 18,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  widget.label,
                  style: TextStyle(
                    color: isSelected ? Colors.white : Colors.white60,
                    fontSize: 14,
                    fontWeight: isSelected ? FontWeight.w500 : FontWeight.w400,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
