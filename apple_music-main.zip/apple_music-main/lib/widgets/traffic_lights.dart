import 'package:flutter/material.dart';

class TrafficLights extends StatelessWidget {
  const TrafficLights({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _buildLight(const Color(0xFFFF5F56)),
        const SizedBox(width: 8),
        _buildLight(const Color(0xFFFFBD2E)),
        const SizedBox(width: 8),
        _buildLight(const Color(0xFF27C93F)),
      ],
    );
  }

  Widget _buildLight(Color color) {
    return Container(
      width: 12,
      height: 12,
      decoration: BoxDecoration(color: color, shape: BoxShape.circle),
    );
  }
}
