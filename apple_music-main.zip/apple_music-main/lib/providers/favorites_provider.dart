import 'package:flutter/foundation.dart';
import 'package:snortify/repository/music_repository.dart';

/// Shared favourite state.
///
/// The heart icon appears in the mini player, the full-screen player, album
/// tracklists, artist pages and the library. Keeping the set of favourited
/// song ids in one provider means a heart filled in any one of those places
/// fills everywhere immediately, and survives switching tabs — each screen
/// used to hold its own boolean, which could not do that.
class FavoritesProvider extends ChangeNotifier {
  final MusicRepository _repository = MusicRepository();

  /// Song ids the user has hearted. Empty until [load] completes, so screens
  /// must treat "not in the set" as unknown rather than false on first paint.
  Set<String> _favoriteIds = <String>{};
  bool _isLoaded = false;
  bool _isLoading = false;

  Set<String> get favoriteIds => _favoriteIds;
  bool get isLoaded => _isLoaded;

  /// Number of songs currently pending a write, used to disable repeat taps.
  final Set<String> _pending = <String>{};
  bool isPending(String songId) => _pending.contains(songId);

  bool isFavorite(String songId) => _favoriteIds.contains(songId);

  /// Loads the user's favourites. Safe to call repeatedly; concurrent calls
  /// reuse the in-flight future rather than stacking requests.
  Future<void> load() async {
    if (_isLoading) return;

    _isLoading = true;
    try {
      final ids = await _repository.fetchFavoriteSongIds();
      _favoriteIds = ids;
      _isLoaded = true;
    } catch (e) {
      // Leave the set as-is; hearts stay unlit rather than flipping wrongly.
      debugPrint('FavoritesProvider: failed to load favourites: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Toggles [songId] in the database, updating the UI optimistically so the
  /// heart responds on the same frame as the tap.
  ///
  /// Returns the resulting state (true if now favourited), or null if the
  /// write failed and the change was rolled back.
  Future<bool?> toggle(String songId) async {
    if (songId.isEmpty) return null;
    if (_pending.contains(songId)) return isFavorite(songId);

    final wasFavorite = _favoriteIds.contains(songId);

    // Optimistic update.
    _setFavorited(songId, !wasFavorite);
    _pending.add(songId);
    notifyListeners();

    try {
      await _repository.toggleFavoriteSong(songId);
      return !wasFavorite;
    } catch (e) {
      debugPrint('FavoritesProvider: toggle failed for $songId: $e');
      // Roll back to the server's state.
      _setFavorited(songId, wasFavorite);
      return null;
    } finally {
      _pending.remove(songId);
      notifyListeners();
    }
  }

  void _setFavorited(String songId, bool favorited) {
    if (favorited) {
      _favoriteIds = {..._favoriteIds, songId};
    } else {
      _favoriteIds = {..._favoriteIds}..remove(songId);
    }
  }

  /// Called after LibraryScreen removes a row, so the heart elsewhere updates
  /// without a round trip.
  void removeLocally(String songId) {
    if (!_favoriteIds.contains(songId)) return;
    _setFavorited(songId, false);
    notifyListeners();
  }
}
