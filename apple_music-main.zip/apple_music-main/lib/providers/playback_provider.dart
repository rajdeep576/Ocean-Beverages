import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:snortify/models/music_models.dart';

/// How the queue behaves when it reaches the end.
enum LoopMode { off, all, one }

class PlaybackProvider with ChangeNotifier {
  final AudioPlayer _audioPlayer = AudioPlayer();

  /// Songs in their original order. [currentSong] always indexes into this list.
  List<Song> _queue = const [];
  int _currentIndex = 0;

  /// Index of [_currentIndex] within the shuffled play order, or -1 when not
  /// shuffling. Kept separate so toggling shuffle off returns to album order.
  final List<int> _shuffleOrder = [];
  int _shufflePosition = -1;

  LoopMode _repeatMode = LoopMode.off;
  bool _shuffleEnabled = false;

  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;

  final List<StreamSubscription<dynamic>> _subscriptions = [];
  final Random _random = Random();

  PlaybackProvider() {
    _init();
  }

  void _init() {
    // One listener for the lifetime of the provider. Previously each
    // playQueue() call registered an additional completed-state listener, so
    // every queue change multiplied how many times playNext() fired.
    _subscriptions.add(
      _audioPlayer.playerStateStream.listen((state) {
        notifyListeners();
        if (state.processingState == ProcessingState.completed) {
          _handleTrackCompleted();
        }
      }),
    );

    _subscriptions.add(
      _audioPlayer.positionStream.listen((pos) {
        _position = pos;
        notifyListeners();
      }),
    );

    _subscriptions.add(
      _audioPlayer.durationStream.listen((dur) {
        _duration = dur ?? Duration.zero;
        notifyListeners();
      }),
    );
  }

  // --- Getters -----------------------------------------------------------

  bool get isPlaying => _audioPlayer.playing;
  Song? get currentSong => _queue.isEmpty ? null : _queue[_currentIndex];
  String get currentArtist => currentSong?.artistName ?? 'Unknown Artist';
  List<Song> get queue => List.unmodifiable(_queue);
  int get currentIndex => _currentIndex;
  bool get hasQueue => _queue.isNotEmpty;

  /// Elapsed playback time.
  Duration get position => _position;

  LoopMode get loopMode => _repeatMode;
  bool get shuffleEnabled => _shuffleEnabled;

  double get progress {
    final total = totalDuration;
    if (total.inMilliseconds == 0) return 0.0;
    final value = _position.inMilliseconds / total.inMilliseconds;
    return value.clamp(0.0, 1.0);
  }

  /// Length of the active track.
  ///
  /// Prefers the duration the player actually loaded from the stream, which is
  /// authoritative. Before metadata arrives (and if a stream never reports one)
  /// falls back to `songs.duration_seconds` from the database, so the timeline
  /// shows a sensible length instead of zero while loading.
  Duration get totalDuration {
    if (_duration > Duration.zero) return _duration;

    final fallbackSeconds = currentSong?.durationSeconds ?? 0;
    if (fallbackSeconds > 0) return Duration(seconds: fallbackSeconds);

    return Duration.zero;
  }

  /// Elapsed playback time, as "M:SS" (or "H:MM:SS" past an hour).
  String get currentPositionFormatted => formatDuration(_position);

  /// Total track length, as "M:SS". Falls back to "--:--" when unknown.
  String get totalDurationFormatted {
    final total = totalDuration;
    if (total <= Duration.zero) return '--:--';
    return formatDuration(total);
  }

  /// "M:SS", zero-padding the seconds. Negative input is treated as zero.
  static String formatDuration(Duration duration) {
    if (duration.isNegative) duration = Duration.zero;

    final hours = duration.inHours;
    final minutes = duration.inMinutes.remainder(60);
    final seconds = duration.inSeconds.remainder(60);
    final paddedSeconds = seconds.toString().padLeft(2, '0');

    if (hours > 0) {
      final paddedMinutes = minutes.toString().padLeft(2, '0');
      return '$hours:$paddedMinutes:$paddedSeconds';
    }
    return '$minutes:$paddedSeconds';
  }

  // --- Playback ----------------------------------------------------------

  /// Plays [song] on its own, replacing any existing queue.
  Future<void> playSong(Song song) => playQueue([song], 0);

  /// Plays [songs] starting at [initialIndex].
  Future<void> playQueue(List<Song> songs, int initialIndex) async {
    if (songs.isEmpty) return;

    _queue = List.of(songs);
    _currentIndex = initialIndex.clamp(0, _queue.length - 1);

    // Rebuild the shuffle order for the new queue, keeping the song the user
    // actually tapped pinned at the front so playback doesn't jump elsewhere.
    if (_shuffleEnabled) {
      _rebuildShuffleOrder(pinnedTo: _currentIndex);
    }

    await _loadAndPlay(_queue[_currentIndex]);
  }

  Future<void> _loadAndPlay(Song song) async {
    if (song.audioUrl.isEmpty) return;

    _position = Duration.zero;
    // Clear the previous track's length so its duration doesn't leak into the
    // new track's timeline while metadata is still loading.
    _duration = Duration.zero;
    notifyListeners();

    try {
      await _audioPlayer.setUrl(song.audioUrl);
      await _audioPlayer.play();
    } catch (e) {
      debugPrint('PlaybackProvider: failed to play "${song.title}": $e');
    }
  }

  Future<void> togglePlayPause() async {
    if (!hasQueue) return;
    if (_audioPlayer.playing) {
      await _audioPlayer.pause();
    } else {
      await _audioPlayer.play();
    }
  }

  Future<void> playNext() async {
    if (_queue.isEmpty) return;

    final next = _peekNextIndex();
    if (next == null) {
      await _audioPlayer.pause();
      return;
    }

    _currentIndex = next;
    await _loadAndPlay(_queue[_currentIndex]);
  }

  Future<void> playPrevious() async {
    if (_queue.isEmpty) return;

    // Apple Music behaviour: restart the track if we're past the intro.
    if (_position.inSeconds > 3) {
      await seek(Duration.zero);
      return;
    }

    final previous = _peekPreviousIndex();
    if (previous == null) return;

    _currentIndex = previous;
    await _loadAndPlay(_queue[_currentIndex]);
  }

  Future<void> seek(Duration position) => _audioPlayer.seek(position);

  /// Queues [song] to play immediately after the current track.
  ///
  /// No-op when there is nothing playing or [song] is already the current
  /// track — inserting a duplicate of what's playing would make "next" a no-op
  /// that looks broken.
  void insertNext(Song song) {
    if (_queue.isEmpty || song.id == _queue[_currentIndex].id) return;

    final insertIndex = _currentIndex + 1;
    _queue.insert(insertIndex, song);

    if (_shuffleOrder.isNotEmpty) {
      // Every existing entry above the insert point shifts down one, otherwise
      // the shuffled play order would point at the wrong tracks.
      for (var i = 0; i < _shuffleOrder.length; i++) {
        if (_shuffleOrder[i] >= insertIndex) _shuffleOrder[i] += 1;
      }
      _shuffleOrder.insert(_shufflePosition + 1, insertIndex);
    }

    notifyListeners();
  }

  void updateProgress(double value) {
    if (_duration.inMilliseconds > 0) {
      final newMilliseconds = (value * _duration.inMilliseconds).round();
      seek(Duration(milliseconds: newMilliseconds));
    }
  }

  /// Jumps to [index] in the queue.
  Future<void> jumpToQueueIndex(int index) async {
    if (index < 0 || index >= _queue.length) return;
    _currentIndex = index;
    if (_shuffleEnabled) {
      _shufflePosition = _shuffleOrder.indexOf(index);
    }
    await _loadAndPlay(_queue[_currentIndex]);
  }

  Future<void> _handleTrackCompleted() async {
    switch (_repeatMode) {
      case LoopMode.one:
        await _audioPlayer.seek(Duration.zero);
        await _audioPlayer.play();
        return;
      case LoopMode.off:
        if (_peekNextIndex() == null) {
          await _audioPlayer.pause();
          await seek(Duration.zero);
        }
        return;
      case LoopMode.all:
        break;
    }
    await playNext();
  }

  // --- Queue navigation, shuffle aware -----------------------------------

  int? _peekNextIndex() {
    if (_shuffleEnabled && _shuffleOrder.isNotEmpty) {
      if (_shufflePosition < _shuffleOrder.length - 1) {
        return _shuffleOrder[_shufflePosition + 1];
      }
      return _repeatMode == LoopMode.all ? _shuffleOrder.first : null;
    }

    if (_currentIndex < _queue.length - 1) return _currentIndex + 1;
    return _repeatMode == LoopMode.all ? 0 : null;
  }

  int? _peekPreviousIndex() {
    if (_shuffleEnabled && _shuffleOrder.isNotEmpty) {
      if (_shufflePosition > 0) return _shuffleOrder[_shufflePosition - 1];
      return _repeatMode == LoopMode.all ? _shuffleOrder.last : null;
    }

    if (_currentIndex > 0) return _currentIndex - 1;
    return _repeatMode == LoopMode.all ? _queue.length - 1 : null;
  }

  /// Builds a shuffled permutation of [_queue]'s indices.
  void _rebuildShuffleOrder({int? pinnedTo}) {
    _shuffleOrder
      ..clear()
      ..addAll(List.generate(_queue.length, (i) => i));

    if (pinnedTo != null && _shuffleOrder.isNotEmpty) {
      _shuffleOrder.remove(pinnedTo);
      _shuffleOrder.insert(0, pinnedTo);
      // Everything after the pinned track is shuffled; the rest of the order
      // stays in album order so skipping backwards feels predictable.
      _shufflePosition = 0;
      return;
    }

    // Fisher-Yates over the whole list.
    for (var i = _shuffleOrder.length - 1; i > 0; i--) {
      final j = _random.nextInt(i + 1);
      final tmp = _shuffleOrder[i];
      _shuffleOrder[i] = _shuffleOrder[j];
      _shuffleOrder[j] = tmp;
    }
    _shufflePosition = _shuffleOrder.indexOf(_currentIndex);
  }

  // --- Shuffle / repeat toggles ------------------------------------------

  void toggleShuffle() {
    _shuffleEnabled = !_shuffleEnabled;

    if (_shuffleEnabled) {
      // Replay history: tracks already played stay in order ahead of the
      // current one, so toggling shuffle mid-song doesn't lose your place.
      final played = _shuffleOrder.isNotEmpty && _shufflePosition >= 0
          ? _shuffleOrder.take(_shufflePosition + 1).toList()
          : <int>[];
      _rebuildShuffleOrder(pinnedTo: _currentIndex);
      // Rebuild shuffled remaining, then splice the played prefix back on.
      _shuffleOrder.insertAll(0, played.where((i) => i != _currentIndex));
      _shufflePosition = _shuffleOrder.indexOf(_currentIndex);
    }

    notifyListeners();
  }

  void cycleLoopMode() {
    _repeatMode =
        LoopMode.values[(_repeatMode.index + 1) % LoopMode.values.length];
    notifyListeners();
  }

  void setVolume(double value) {
    _audioPlayer.setVolume(value.clamp(0.0, 1.0));
  }

  @override
  void dispose() {
    for (final sub in _subscriptions) {
      sub.cancel();
    }
    _audioPlayer.dispose();
    super.dispose();
  }
}
