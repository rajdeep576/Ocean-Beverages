import 'package:flutter/widgets.dart';

/// Widths below this get the phone layout.
///
/// Lives on its own so `FullscreenPlayer` can pick a layout without importing
/// `MainLayout` — which would be a circular import, since the layout is what
/// launches the player.
const double kMobileBreakpoint = 600;

/// Whether [width] should use the phone layout.
bool isMobileWidth(double width) => width < kMobileBreakpoint;

/// Vertical space the mobile shell's floating mini player and nav pill occupy.
///
/// Both overlays are `Positioned` above the bottom edge, so scrolling page
/// content has to reserve this much room or its last rows sit underneath them.
/// The two heights (60 + 68) plus the gaps between and below them.
const double kMobileOverlayInset = 172;

/// Horizontal page gutter — tight on phones, roomy on desktop.
double pageGutter(double width) => isMobileWidth(width) ? 16.0 : 40.0;

/// Top inset a page needs so its header clears the status bar and cutout.
///
/// A `Scaffold` without an `AppBar` hands its body the raw
/// `MediaQuery.padding`, so a page whose first child is a title or a header
/// row starts drawing at y=0 and slides under the clock. This is that padding
/// plus [base], the page's own breathing room on top.
///
/// Deliberately not a `SafeArea`: the mobile shell stacks the mini player and
/// nav pill over the page with `Positioned`, and a `SafeArea` around the whole
/// page would also inset the bottom — the overlay inset already reserves that.
double pageTopInset(BuildContext context, {double base = 0}) =>
    MediaQuery.paddingOf(context).top + base;

/// Padding for a scrolling page, sized to [width].
///
/// [bottom] is the screen's own trailing space; the mobile overlay inset is
/// added on top of it so every page clears the floating player and nav pill
/// without each one remembering the constant.
EdgeInsets pagePadding(double width, {double top = 0, double bottom = 0}) {
  final gutter = pageGutter(width);
  return EdgeInsets.fromLTRB(
    gutter,
    top,
    gutter,
    bottom + (isMobileWidth(width) ? kMobileOverlayInset : 0),
  );
}

/// Columns for a fixed-count grid whose tiles never shrink below
/// [minItemWidth].
///
/// [spacing] is the delegate's cross-axis gap and is added back before
/// dividing, since every column but the last also pays for one gap. Clamping
/// keeps the result inside [min]..[max] so a very narrow phone still shows
/// something rather than a single sliver of a tile.
int gridColumnCount(
  double availableWidth, {
  required double minItemWidth,
  double spacing = 0,
  int min = 1,
  int max = 6,
}) {
  if (availableWidth <= 0) return min;
  final columns = ((availableWidth + spacing) / (minItemWidth + spacing))
      .floor();
  return columns.clamp(min, max);
}

/// Width of one cell in a grid of [columns] columns spanning [availableWidth].
///
/// Every column but the last also pays for a [spacing] gap, hence the
/// subtraction. Feed this to [tileChildAspectRatio] so the cell height matches
/// the width the delegate is about to hand the child.
double gridTileWidth(
  double availableWidth,
  int columns, {
  double spacing = 0,
}) => (availableWidth - spacing * (columns - 1)) / columns;

/// Vertical space a square-artwork tile needs below the artwork itself: the
/// 8px gap, two lines of 14px title, and one line of 12px subtitle.
///
/// Exported rather than measured so the grid delegate, the shelf, and
/// `MusicTile` all agree on one number. If it is derived from font metrics
/// independently in each place, the three drift apart and the labels clip — the
/// failure is invisible in code review and only shows up as a chopped-off
/// second line on a real device.
const double kTileLabelBlock = 57;

/// Height of a tile whose artwork is [tileWidth] square.
double tileHeight(double tileWidth) => tileWidth + kTileLabelBlock;

/// `childAspectRatio` for a grid of square-artwork tiles [tileWidth] wide.
///
/// A hardcoded ratio is a guess about how many lines the label needs, and it
/// can only be wrong in one direction: too small clips the title's second line,
/// too large wastes a row's worth of space on every cell. Deriving the ratio
/// from the width the delegate actually produces means the labels fit at every
/// column count.
double tileChildAspectRatio(double tileWidth) =>
    tileWidth / (tileWidth + kTileLabelBlock);
