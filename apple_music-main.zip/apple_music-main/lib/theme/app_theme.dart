import 'package:flutter/material.dart';

class AppTheme {
  static ThemeData get darkTheme {
    return ThemeData(
      brightness: Brightness.dark,
      primaryColor: Colors.redAccent,
      scaffoldBackgroundColor: const Color(
        0xFF1A1A1A,
      ), // Deep matte dark charcoal
      colorScheme: const ColorScheme.dark(
        primary: Colors.redAccent,
        secondary: Colors.redAccent,
        surface: Color(0xFF1C1C1E), // Apple Music-ish background grey
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Colors.black,
        selectedItemColor: Colors.redAccent,
        unselectedItemColor: Colors.grey,
        type: BottomNavigationBarType.fixed,
      ),
      useMaterial3: true,
    );
  }
}
