import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:snortify/models/music_models.dart';

class MusicRepositoryException implements Exception {
  final String message;
  MusicRepositoryException(this.message);
  @override
  String toString() => 'MusicRepositoryException: $message';
}

class MusicRepository {
  // Singleton instance
  static final MusicRepository instance = MusicRepository._internal();
  factory MusicRepository() => instance;
  MusicRepository._internal();

  final SupabaseClient _client = Supabase.instance.client;

  Future<List<Album>> fetchFeaturedAlbums() async {
    try {
      final response = await _client
          .from('albums')
          .select('*, artists(*)')
          .limit(8);

      return (response as List).map((json) => Album.fromJson(json)).toList();
    } catch (e) {
      throw MusicRepositoryException('Failed to fetch featured albums: $e');
    }
  }

  Future<Map<String, dynamic>> fetchArtistDetails(String artistId) async {
    try {
      final response = await _client
          .from('artists')
          .select('*, songs(*), albums(*)')
          .eq('id', artistId)
          .single();
      // NOTE: Here you would map this to a specific ArtistDetail model
      return response;
    } catch (e) {
      throw MusicRepositoryException('Failed to fetch artist details: $e');
    }
  }

  Future<Album> fetchAlbumWithSongs(String albumId) async {
    try {
      final response = await _client
          .from('albums')
          .select('*, songs(*)')
          .eq('id', albumId)
          .order('track_number', referencedTable: 'songs')
          .single();

      return Album.fromJson(response);
    } catch (e) {
      throw MusicRepositoryException('Failed to fetch album details: $e');
    }
  }

  /// Fetches an album's tracks in playback order, with cover art and artist
  /// name embedded so `Song.fromJson` can populate both for the mini player.
  Future<List<Song>> fetchSongsForAlbum(String albumId) async {
    try {
      final response = await _client
          .from('songs')
          .select('*, albums(cover_url, artists(name))')
          .eq('album_id', albumId)
          .order('track_number');

      return (response as List).map((json) => Song.fromJson(json)).toList();
    } catch (e) {
      throw MusicRepositoryException('Failed to fetch songs for album: $e');
    }
  }

  Future<List<Playlist>> fetchUserPlaylists() async {
    try {
      final userId = _client.auth.currentUser?.id;
      if (userId == null) throw Exception('User not logged in');

      final response = await _client
          .from('playlists')
          .select('*')
          .eq('user_id', userId);

      return (response as List).map((json) => Playlist.fromJson(json)).toList();
    } catch (e) {
      throw MusicRepositoryException('Failed to fetch playlists: $e');
    }
  }

  /// Every artist in the catalogue, alphabetically — the Library's Artists
  /// section and the sidebar's "Artists" link.
  Future<List<Artist>> fetchAllArtists() async {
    try {
      final response = await _client.from('artists').select('*').order('name');

      return (response as List).map((json) => Artist.fromJson(json)).toList();
    } catch (e) {
      throw MusicRepositoryException('Failed to fetch artists: $e');
    }
  }

  /// Newest albums first — the Browse tab's "New Releases" shelf.
  Future<List<Album>> fetchNewReleases({int limit = 12}) async {
    try {
      final response = await _client
          .from('albums')
          .select('*, artists(*)')
          .order('release_year', ascending: false)
          .limit(limit);

      return (response as List).map((json) => Album.fromJson(json)).toList();
    } catch (e) {
      throw MusicRepositoryException('Failed to fetch new releases: $e');
    }
  }

  /// Albums matching a genre, used by the Browse genre tiles.
  Future<List<Album>> fetchAlbumsByGenre(String genre, {int limit = 12}) async {
    try {
      final response = await _client
          .from('albums')
          .select('*, artists(*)')
          .ilike('genre', genre)
          .limit(limit);

      return (response as List).map((json) => Album.fromJson(json)).toList();
    } catch (e) {
      throw MusicRepositoryException('Failed to fetch $genre albums: $e');
    }
  }

  /// Every distinct genre present in the catalogue, alphabetically.
  Future<List<String>> fetchGenres() async {
    try {
      final response = await _client
          .from('albums')
          .select('genre')
          .not('genre', 'is', null);

      final genres = <String>{};
      for (final row in (response as List)) {
        final genre = row['genre'];
        if (genre is String && genre.isNotEmpty) genres.add(genre);
      }

      final sorted = genres.toList()..sort();
      return sorted;
    } catch (e) {
      throw MusicRepositoryException('Failed to fetch genres: $e');
    }
  }

  /// Tracks the signed-in user has hearted, newest first.
  Future<List<Song>> fetchFavoriteSongs() async {
    try {
      final userId = _client.auth.currentUser?.id;
      if (userId == null) throw Exception('User not logged in');

      final response = await _client
          .from('user_favorites')
          .select(
            'created_at, songs(*, albums(cover_url, title, genre, release_year, artists(name)))',
          )
          .eq('user_id', userId)
          .order('created_at', ascending: false);

      return (response as List)
          .map((json) => json['songs'])
          .whereType<Map<String, dynamic>>()
          .map(Song.fromJson)
          .toList();
    } catch (e) {
      throw MusicRepositoryException('Failed to fetch favorite songs: $e');
    }
  }

  /// The ids of every song the user has hearted, for showing filled stars
  /// without a second round trip per row.
  Future<Set<String>> fetchFavoriteSongIds() async {
    try {
      final userId = _client.auth.currentUser?.id;
      if (userId == null) return const {};

      final response = await _client
          .from('user_favorites')
          .select('song_id')
          .eq('user_id', userId);

      return (response as List)
          .map((row) => row['song_id'])
          .whereType<String>()
          .toSet();
    } catch (e) {
      throw MusicRepositoryException('Failed to fetch favorites: $e');
    }
  }

  /// Top tracks across the whole catalogue — stands in for charts, which need
  /// play-count data this schema doesn't have.
  ///
  /// Filters on `is_published` when that column exists. This is subtler than it
  /// looks: admin_setup.sql added `is_published` with a `default false`, so the
  /// 28 seeded tracks — every song that predates publishing — all read as
  /// `false`. Filtering on it therefore matches *nothing*, which is exactly how
  /// the catalogue came to look empty: not an error, just zero rows. So an
  /// empty published result falls back to the unfiltered catalogue rather than
  /// reporting an empty shelf.
  Future<List<Song>> fetchTopSongs({int limit = 10}) async {
    try {
      const select = '*, albums(cover_url, artists(name))';

      // The two chains are written out rather than reassigned because
      // select() returns a transform builder and eq() returns a filter
      // builder — they are different types, so there is no common variable to
      // hold them in.
      List<dynamic> rows = [];
      if (await _hasColumn('is_published')) {
        rows = await _client
            .from('songs')
            .select(select)
            .eq('is_published', true)
            .limit(limit);
      }
      if (rows.isEmpty) {
        rows = await _client.from('songs').select(select).limit(limit);
      }

      return rows.map((json) => Song.fromJson(json)).toList();
    } catch (e) {
      throw MusicRepositoryException('Failed to fetch top songs: $e');
    }
  }

  /// Searches songs, albums, and artists using case-insensitive partial matching (ilike)
  Future<Map<String, dynamic>> searchAll(String query) async {
    try {
      final cleanQuery = query.trim();
      if (cleanQuery.isEmpty) {
        return {'songs': [], 'albums': [], 'artists': []};
      }

      final likePattern = '%$cleanQuery%';

      // Fetch songs (with album and artist info)
      final songsResponse = await _client
          .from('songs')
          .select('*, albums(cover_url, artists(name))')
          .ilike('title', likePattern)
          .limit(10);

      // Fetch albums (with artist info)
      final albumsResponse = await _client
          .from('albums')
          .select('*, artists(*)')
          .ilike('title', likePattern)
          .limit(10);

      // Fetch artists
      final artistsResponse = await _client
          .from('artists')
          .select('*')
          .ilike('name', likePattern)
          .limit(10);

      return {
        'songs': (songsResponse as List)
            .map((json) => Song.fromJson(json))
            .toList(),
        'albums': (albumsResponse as List)
            .map((json) => Album.fromJson(json))
            .toList(),
        'artists': (artistsResponse as List)
            .map((json) => Artist.fromJson(json))
            .toList(),
      };
    } catch (e) {
      throw MusicRepositoryException('Failed to search: $e');
    }
  }

  /// Searches only songs
  Future<List<Song>> searchSongs(String query) async {
    try {
      final cleanQuery = query.trim();
      if (cleanQuery.isEmpty) return [];

      final likePattern = '%$cleanQuery%';
      final response = await _client
          .from('songs')
          .select('*, albums(cover_url, artists(name))')
          .ilike('title', likePattern)
          .limit(20);

      return (response as List).map((json) => Song.fromJson(json)).toList();
    } catch (e) {
      throw MusicRepositoryException('Failed to search songs: $e');
    }
  }

  /// Searches only albums
  Future<List<Album>> searchAlbums(String query) async {
    try {
      final cleanQuery = query.trim();
      if (cleanQuery.isEmpty) return [];

      final likePattern = '%$cleanQuery%';
      final response = await _client
          .from('albums')
          .select('*, artists(*)')
          .ilike('title', likePattern)
          .limit(20);

      return (response as List).map((json) => Album.fromJson(json)).toList();
    } catch (e) {
      throw MusicRepositoryException('Failed to search albums: $e');
    }
  }

  /// Searches only artists
  Future<List<Artist>> searchArtists(String query) async {
    try {
      final cleanQuery = query.trim();
      if (cleanQuery.isEmpty) return [];

      final likePattern = '%$cleanQuery%';
      final response = await _client
          .from('artists')
          .select('*')
          .ilike('name', likePattern)
          .limit(20);

      return (response as List).map((json) => Artist.fromJson(json)).toList();
    } catch (e) {
      throw MusicRepositoryException('Failed to search artists: $e');
    }
  }

  /// Whether [songId] is in the signed-in user's favourites.
  ///
  /// Returns false when signed out rather than throwing — callers use this to
  /// decide whether a heart renders filled, and a logged-out user should simply
  /// see unfilled hearts.
  Future<bool> isSongFavorite(String songId) async {
    try {
      final userId = _client.auth.currentUser?.id;
      if (userId == null) return false;

      final existing = await _client
          .from('user_favorites')
          .select('song_id')
          .eq('user_id', userId)
          .eq('song_id', songId)
          .maybeSingle();

      return existing != null;
    } catch (e) {
      throw MusicRepositoryException('Failed to check favorite: $e');
    }
  }

  Future<void> toggleFavoriteSong(String songId) async {
    try {
      final userId = _client.auth.currentUser?.id;
      if (userId == null) throw Exception('User not logged in');

      final existing = await _client
          .from('user_favorites')
          .select('*')
          .eq('user_id', userId)
          .eq('song_id', songId)
          .maybeSingle();

      if (existing == null) {
        await _client.from('user_favorites').insert({
          'user_id': userId,
          'song_id': songId,
        });
      } else {
        await _client
            .from('user_favorites')
            .delete()
            .eq('user_id', userId)
            .eq('song_id', songId);
      }
    } catch (e) {
      throw MusicRepositoryException('Failed to toggle favorite: $e');
    }
  }

  /// Creates a playlist owned by the signed-in user and returns it.
  ///
  /// [title] is trimmed and rejected when blank — the column is NOT NULL, so
  /// an empty string would otherwise insert a row the UI then has to filter
  /// out anyway. `cover_url` is left null: `Playlist.fromJson` substitutes a
  /// placeholder, so a new playlist renders with artwork instead of a hole.
  Future<Playlist> createPlaylist(String title) async {
    final trimmed = title.trim();
    if (trimmed.isEmpty) {
      throw MusicRepositoryException('Playlist needs a title');
    }

    try {
      final userId = _client.auth.currentUser?.id;
      if (userId == null) throw Exception('User not logged in');

      final response = await _client
          .from('playlists')
          .insert({'user_id': userId, 'title': trimmed})
          .select()
          .single();

      return Playlist.fromJson(Map<String, dynamic>.from(response));
    } catch (e) {
      if (e is MusicRepositoryException) rethrow;
      throw MusicRepositoryException('Failed to create playlist: $e');
    }
  }

  /// Appends [songId] to [playlistId].
  ///
  /// Requires a `playlist_songs` table, which the seed script does not create.
  /// `ignoreDuplicates: true` (ON CONFLICT DO NOTHING) makes re-adding the
  /// same track a no-op instead of an error, so the caller can always show a
  /// success confirmation.
  Future<void> addSongToPlaylist(String playlistId, String songId) async {
    try {
      final userId = _client.auth.currentUser?.id;
      if (userId == null) throw Exception('User not logged in');

      // Verify the playlist belongs to this user before writing. Without this,
      // a crafted playlistId could append to someone else's list, since the
      // RLS policy would have to be the only thing stopping it.
      final owned = await _client
          .from('playlists')
          .select('id')
          .eq('id', playlistId)
          .eq('user_id', userId)
          .maybeSingle();

      if (owned == null) {
        throw MusicRepositoryException('Playlist not found');
      }

      await _client
          .from('playlist_songs')
          .upsert(
            {'playlist_id': playlistId, 'song_id': songId},
            // Requires a unique constraint on (playlist_id, song_id) to conflict
            // against; absent one this behaves as a plain insert.
            onConflict: 'playlist_id,song_id',
            ignoreDuplicates: true,
          );
    } catch (e) {
      if (e is MusicRepositoryException) rethrow;
      throw MusicRepositoryException('Failed to add to playlist: $e');
    }
  }

  /// Whether [songId] is already in [playlistId], used to grey out entries the
  /// song has been added to.
  Future<bool> isSongInPlaylist(String playlistId, String songId) async {
    try {
      final existing = await _client
          .from('playlist_songs')
          .select('song_id')
          .eq('playlist_id', playlistId)
          .eq('song_id', songId)
          .maybeSingle();

      return existing != null;
    } catch (e) {
      throw MusicRepositoryException('Failed to check playlist contents: $e');
    }
  }

  /// How many tracks each playlist holds, keyed by playlist id.
  ///
  /// PostgREST can return a per-row aggregate, so this is a single round trip
  /// rather than one count query per card in the Library grid.
  Future<Map<String, int>> fetchPlaylistSongCounts() async {
    try {
      final userId = _client.auth.currentUser?.id;
      if (userId == null) return const {};

      final response = await _client
          .from('playlist_songs')
          .select('playlist_id, playlists!inner(user_id)')
          .eq('playlists.user_id', userId);

      final counts = <String, int>{};
      for (final row in (response as List)) {
        final playlistId = row['playlist_id'];
        if (playlistId is String) {
          counts[playlistId] = (counts[playlistId] ?? 0) + 1;
        }
      }
      return counts;
    } catch (e) {
      throw MusicRepositoryException('Failed to count playlist tracks: $e');
    }
  }

  /// The tracks in [playlistId], in the order they should play.
  ///
  /// Ordered by `added_at` and then `song_id`, which is what this schema
  /// actually has. An earlier version selected and ordered by `position` and
  /// `id`; neither column exists on `playlist_songs`, so PostgREST rejected
  /// the whole request with 42703 and the screen showed "Couldn't load this
  /// playlist" for every playlist, full or empty.
  ///
  /// `song_id` breaks the tie: tracks added in the same batch share an
  /// `added_at`, and without a tiebreaker the list reshuffles between loads.
  Future<List<Song>> fetchSongsForPlaylist(String playlistId) async {
    try {
      final response = await _client
          .from('playlist_songs')
          .select(
            // One closing paren per opened one. An extra `)` does not throw
            // locally — PostgREST rejects the request, and the screen reports
            // it as "Couldn't load this playlist" either way.
            'added_at, songs(*, albums(cover_url, title, genre, release_year, artists(name)))',
          )
          .eq('playlist_id', playlistId)
          .order('added_at')
          .order('song_id');

      return (response as List)
          .map((row) => row['songs'])
          .whereType<Map<String, dynamic>>()
          .map(Song.fromJson)
          .toList();
    } catch (e) {
      throw MusicRepositoryException('Failed to fetch playlist tracks: $e');
    }
  }

  /// Removes [songId] from [playlistId].
  ///
  /// Scoped by playlist id only — RLS decides whether the caller owns the
  /// parent playlist, and an explicit ownership check would duplicate that
  /// with a second round trip on every removal.
  Future<void> removeSongFromPlaylist(String playlistId, String songId) async {
    try {
      await _client
          .from('playlist_songs')
          .delete()
          .eq('playlist_id', playlistId)
          .eq('song_id', songId);
    } catch (e) {
      throw MusicRepositoryException('Failed to remove from playlist: $e');
    }
  }

// ---------------------------------------------------------------------
  // Admin
  //
  // Authorization is enforced by RLS (supabase/admin_setup.sql), which calls
  // public.is_admin() server-side. Nothing here re-checks the role in Dart —
  // the client cannot be trusted to enforce it, and a Dart check would give the
  // appearance of security without providing any.
  //
  // Some of these columns come from admin_setup.sql and are absent until it is
  // applied. PostgREST resolves the select clause before matching rows, so
  // naming a missing column fails the whole request with 42703/PGRST204 rather
  // than returning fewer columns — one absent column takes down the whole
  // query, including the parts that would otherwise have worked.
  //
  // That makes a single "did admin_setup.sql run?" flag unsafe. The script adds
  // its columns in one statement, but a project can end up with a partial set,
  // and this one has exactly that: is_published and created_by landed, while
  // created_at, audio_path, cover_path and cover_url did not. Probing a single
  // column then reports "present" and the queries go on to name the others,
  // failing exactly as they would have with no probe at all. So every column is
  // probed on its own — see [_hasColumn].
  // ---------------------------------------------------------------------

  /// Columns already found to be absent from `songs`. Cached for the life of
  /// the process; the schema cannot change under a running app.
  final Set<String> _missingColumns = {};

  /// Columns confirmed present, so they are never re-probed.
  final Set<String> _knownColumns = {};

  /// Whether `songs` has [column], asked of PostgREST directly.
  ///
  /// Absent columns are remembered, so each costs at most one request per run
  /// however many queries depend on it.
  Future<bool> _hasColumn(String column) async {
    if (_knownColumns.contains(column)) return true;
    if (_missingColumns.contains(column)) return false;

    try {
      await _client.from('songs').select('id,$column').limit(1);
      _knownColumns.add(column);
      return true;
    } catch (_) {
      _missingColumns.add(column);
      return false;
    }
  }

  /// [columns] narrowed to those this database actually has, in original order.
  Future<List<String>> _existingColumns(List<String> columns) async {
    final present = <String>[];
    for (final column in columns) {
      if (await _hasColumn(column)) present.add(column);
    }
    return present;
  }

  /// Every song in the catalogue, published or not.
  ///
  /// Ordering is by `created_at` (newest first) when that column exists and by
  /// `title` when it does not — ordering by a missing column is the same
  /// parse-time 42703 as selecting it.
  Future<List<Song>> fetchAllSongsAdmin() async {
    // Probe per column, not per script: `is_published` exists here while
    // `created_at` and `audio_path` do not, so one flag would put all of them
    // in the select and fail the request outright.
    final optional = await _existingColumns(_adminOptionalColumns);

    try {
      final select = [..._adminColumns, ...optional, ..._adminEmbeds].join(',');

      final ordered = optional.contains('created_at')
          ? _client
              .from('songs')
              .select(select)
              .order('created_at', ascending: false)
          : _client.from('songs').select(select).order('title');

      final response = await ordered;

      return (response as List).map((json) => Song.fromJson(json)).toList();
    } catch (e) {
      throw MusicRepositoryException('Failed to fetch songs: $e');
    }
  }

  /// Sets a song's published flag.
  ///
  /// Returns the updated row so the caller can swap it into its list instead of
  /// re-fetching every row.
  Future<Song> setSongPublished(String songId, bool published) async {
    if (!await _hasColumn('is_published')) {
      throw MusicRepositoryException(
        'This database has no is_published column — run supabase/admin_setup.sql.',
      );
    }

    try {
      final response = await _client
          .from('songs')
          .update({'is_published': published})
          .eq('id', songId)
          .select([..._adminColumns, ..._adminEmbeds].join(','))
          .single();

      return Song.fromJson(Map<String, dynamic>.from(response));
    } catch (e) {
      throw MusicRepositoryException('Failed to update song: $e');
    }
  }

  /// Deletes a song row and, when it was an uploaded track, its own audio.
  ///
  /// Order matters: the row goes first. If storage removal then fails the track
  /// is already gone from the catalogue and the leftover is an orphan object,
  /// which is recoverable — the reverse order would delete audio that a live
  /// song still points at. Seeded tracks have no `audio_path` and their URLs
  /// point at SoundHelix rather than a bucket, so their audio is left alone.
  ///
  /// Album artwork is deliberately NOT deleted: it belongs to the album, and
  /// every other track on that album points at the same object. Removing it
  /// would blank the covers of songs this call never touched.
  Future<void> deleteSong(String songId) async {
    // `audio_path` is absent on this database, so it is probed on its own:
    // asking for a missing column fails the whole select with 42703 and the
    // delete would abort before it had deleted anything.
    final hasAudioPath = await _hasColumn('audio_path');

    String? audioPath;
    try {
      final response = await _client
          .from('songs')
          .select(hasAudioPath ? 'id,audio_path' : 'id')
          .eq('id', songId)
          .maybeSingle();
      if (response == null) {
        throw MusicRepositoryException('Song not found');
      }
      audioPath = response['audio_path']?.toString();
    } catch (e) {
      if (e is MusicRepositoryException) rethrow;
      throw MusicRepositoryException('Failed to load song: $e');
    }

    try {
      // playlist_songs and user_favorites cascade from this delete.
      await _client.from('songs').delete().eq('id', songId);
    } catch (e) {
      throw MusicRepositoryException('Failed to delete song: $e');
    }

    await _removeStoredFile('audio-files', audioPath);
  }

  /// Deletes one object, tolerating "already gone".
  ///
  /// Storage is cleanup, not the user-visible operation, so a failure here is
  /// swallowed: the song row is already deleted and surfacing a storage error
  /// would report the whole delete as failed when it wasn't.
  Future<void> _removeStoredFile(String bucket, String? path) async {
    if (path == null || path.isEmpty) return;
    try {
      await _client.storage.from(bucket).remove([path]);
    } catch (_) {
      // Left as an orphan object; the dashboard no longer lists the track.
    }
  }

  /// Finds an artist by exact name, or null.
  ///
  /// Used by the upload screen to attach a track to an existing artist rather
  /// than creating a duplicate row for every upload.
  Future<String?> findArtistIdByName(String name) async {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return null;
    try {
      final response = await _client
          .from('artists')
          .select('id')
          .ilike('name', trimmed)
          .maybeSingle();
      return response?['id']?.toString();
    } catch (e) {
      throw MusicRepositoryException('Failed to look up artist: $e');
    }
  }

  /// Creates an artist row and returns its id.
  Future<String> createArtist(String name) async {
    final trimmed = name.trim();
    if (trimmed.isEmpty) {
      throw MusicRepositoryException('Artist needs a name');
    }
    try {
      final response = await _client
          .from('artists')
          .insert({'name': trimmed})
          .select('id')
          .single();
      return response['id'].toString();
    } catch (e) {
      throw MusicRepositoryException('Failed to create artist: $e');
    }
  }

  /// Finds an album by exact title under [artistId], or null.
  Future<String?> findAlbumIdByTitle(String title, String artistId) async {
    final trimmed = title.trim();
    if (trimmed.isEmpty) return null;
    try {
      final response = await _client
          .from('albums')
          .select('id')
          .ilike('title', trimmed)
          .eq('artist_id', artistId)
          .maybeSingle();
      return response?['id']?.toString();
    } catch (e) {
      throw MusicRepositoryException('Failed to look up album: $e');
    }
  }

  /// Creates an album under [artistId] and returns its id.
  ///
  /// [coverUrl] is only set here — on a genuinely new album. The upload screen
  /// calls this only after [findAlbumIdByTitle] finds nothing, so artwork from
  /// a new upload never overwrites the cover of an existing album.
  Future<String> createAlbum({
    required String title,
    required String artistId,
    String? coverUrl,
  }) async {
    final trimmed = title.trim();
    if (trimmed.isEmpty) {
      throw MusicRepositoryException('Album needs a title');
    }
    try {
      final response = await _client
          .from('albums')
          .insert({
            'title': trimmed,
            'artist_id': artistId,
            if (coverUrl != null && coverUrl.isNotEmpty) 'cover_url': coverUrl,
          })
          .select('id')
          .single();
      return response['id'].toString();
    } catch (e) {
      throw MusicRepositoryException('Failed to create album: $e');
    }
  }

  /// Inserts a song row for an uploaded track.
  ///
  /// [audioUrl] and [coverUrl] are bucket-relative paths, not absolute URLs:
  /// `StorageHelper.getPublicUrl` resolves those against the bucket, which is
  /// the convention `seed.sql` documents. Storing the path rather than the
  /// resolved URL means the same value serves playback, display, and the
  /// delete flow's `audio_path` lookup.
  ///
  /// [trackNumber] is the position of the song within its album (1-indexed).
  /// For uploaded songs without explicit ordering, defaults to 1.
  Future<String> insertSong({
    required String id,
    required String title,
    required String audioUrl,
    required String audioPath,
    required int durationSeconds,
    String? artistId,
    String? albumId,
    String? coverUrl,
    int trackNumber = 1,
    bool isPublished = false,
  }) async {
    final trimmed = title.trim();
    if (trimmed.isEmpty) {
      throw MusicRepositoryException('Song needs a title');
    }

    try {
      final userId = _client.auth.currentUser?.id;
      final cover = coverUrl?.trim();

      // Only columns this database actually has are written. Naming an absent
      // one fails the insert with 42703, so on the current schema an upload
      // would fail outright even though `audio_url` alone is enough for
      // playback and `albums.cover_url` for artwork.
      final optional = await _existingColumns(_adminOptionalColumns);

      final row = <String, dynamic>{
        'id': id,
        'title': trimmed,
        'audio_url': audioUrl,
        'duration_seconds': durationSeconds,
        'track_number': trackNumber,
      };
      // Null-aware entries are omitted rather than sent as SQL null, so an
      // upload with no album still produces a valid row.
      if (artistId != null) row['artist_id'] = artistId;
      if (albumId != null) row['album_id'] = albumId;
      if (optional.contains('audio_path')) row['audio_path'] = audioPath;
      if (optional.contains('cover_url') && cover != null && cover.isNotEmpty) {
        row['cover_url'] = cover;
      }
      if (optional.contains('is_published')) row['is_published'] = isPublished;
      if (optional.contains('created_by') && userId != null) {
        row['created_by'] = userId;
      }

      await _client.from('songs').insert(row);
      return id;
    } catch (e) {
      throw MusicRepositoryException('Failed to insert song: $e');
    }
  }
}

/// Columns `songs` is guaranteed to have. Naming any other column in a select
/// fails the entire request with 42703 while admin_setup.sql is unapplied.
const List<String> _adminColumns = [
  'id',
  'title',
  'duration_seconds',
  'track_number',
  'audio_url',
  'album_id',
  'artist_id',
];

/// Columns added by supabase/admin_setup.sql, included only once it has run.
const List<String> _adminOptionalColumns = [
  'is_published',
  'created_by',
  'created_at',
  'audio_path',
  'cover_url',
];

/// Artist and album names for the row subtitles. Verified to resolve against
/// the live schema.
const List<String> _adminEmbeds = [
  'artists(name)',
  'albums(id,title,cover_url,artists(name))',
];
