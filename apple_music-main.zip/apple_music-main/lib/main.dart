import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:snortify/providers/playback_provider.dart';
import 'package:snortify/providers/favorites_provider.dart';
import 'package:snortify/screens/splash_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: 'https://wbjzagagthoijygcrmdo.supabase.co',
    publishableKey:
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndianphZ2FndGhvaWp5Z2NybWRvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTA4Mjg0MDYsImV4cCI6MjEwNjQwNDQwNn0.fdN-QOnIOT4OxyVJUgFG-qNCtDhU8qcWC2vb3RG8Bn0',
  );
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => PlaybackProvider()),
        ChangeNotifierProvider(create: (_) => FavoritesProvider()),
      ],
      child: const MusicPlayerApp(),
    ),
  );
}

class MusicPlayerApp extends StatelessWidget {
  const MusicPlayerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Snortify Redesign',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true),
      // SplashScreen checks the session and routes to AuthScreen or MainLayout.
      // Setting MainLayout here directly left AuthScreen unreachable on every
      // screen size, so there was no way to sign in or out from the app.
      home: const SplashScreen(),
    );
  }
}