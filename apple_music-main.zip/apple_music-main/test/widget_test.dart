import 'package:flutter_test/flutter_test.dart';

import 'package:apple_music/models/music_models.dart';

/// The default counter test that shipped with `flutter create` never applied to
/// this app — it referenced a `MyApp` that does not exist. It is replaced with
/// a pure-model test: pumping `MusicPlayerApp` in a widget test would call
/// `Supabase.initialize` against no project, so anything exercising the widget
/// tree belongs on a device.
void main() {
  group('Song', () {
    test('reads is_published only when the column came back', () {
      final withColumn = Song.fromJson({
        'id': 'a',
        'title': 'Halcyon',
        'audio_url': 'https://example.com/a.mp3',
        'is_published': true,
      });
      expect(withColumn.isPublished, isTrue);
      expect(withColumn.hasPublishingColumn, isTrue);

      // Before admin_setup.sql is applied the column is absent. Reporting that
      // as "draft" would label the whole seeded catalogue unpublished, which
      // is what hasPublishingColumn exists to prevent.
      final withoutColumn = Song.fromJson({
        'id': 'b',
        'title': 'Cielo',
        'audio_url': 'https://example.com/b.mp3',
      });
      expect(withoutColumn.isPublished, isFalse);
      expect(withoutColumn.hasPublishingColumn, isFalse);
    });

    test('formats duration as m:ss', () {
      Song of(int? seconds) => Song(
            id: 'x',
            title: 'x',
            audioUrl: 'https://example.com/x.mp3',
            durationSeconds: seconds,
          );

      expect(of(188).durationLabel, '3:08');
      expect(of(59).durationLabel, '0:59');
      expect(of(null).durationLabel, '--:--');
      expect(of(0).durationLabel, '--:--');
    });
  });
}