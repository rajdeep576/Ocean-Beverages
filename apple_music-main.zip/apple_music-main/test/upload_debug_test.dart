import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

void main() {
  group('Upload Debug Tests', () {
    test('Check auth state and Storage access', () async {
      // Initialize Supabase
      await Supabase.initialize(
        url: 'https://wbjzagagthoijygcrmdo.supabase.co',
        publishableKey:
            'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndianphZ2FndGhvaWp5Z2NybWRvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTA4Mjg0MDYsImV4cCI6MjEwNjQwNDQwNn0.fdN-QOnIOT4OxyVJUgFG-qNCtDhU8qcWC2vb3RG8Bn0',
      );

      final client = Supabase.instance.client;
      final currentUser = client.auth.currentUser;
      final currentSession = client.auth.currentSession;

      print('=== AUTH STATE ===');
      print('Current user: $currentUser');
      print('Current user ID: ${currentUser?.id}');
      print('Current user email: ${currentUser?.email}');
      print('Session: $currentSession');
      print('Session user ID: ${currentSession?.user.id}');

      // Try to upload a test file
      print('\n=== STORAGE TEST ===');
      final testData = Uint8List.fromList('test content'.codeUnits);
      final testPath = 'test/debug-upload.txt';

      try {
        final storage = client.storage;
        print('Storage instance: $storage');
        print('Audio-files bucket: ${storage.from('audio-files')}');

        // Try audio-files bucket
        print('\nAttempting upload to audio-files bucket...');
        await storage.from('audio-files').uploadBinary(
          testPath,
          testData,
          fileOptions: const FileOptions(contentType: 'text/plain', upsert: true),
        );
        print('Upload to audio-files succeeded!');
      } catch (e) {
        print('Upload to audio-files failed: $e');
        print('Error type: ${e.runtimeType}');
        if (e is StorageException) {
          print('Storage error - statusCode: ${e.statusCode}');
          print('Storage error - message: ${e.message}');
          print('Storage error - error: ${e.error}');
        }
      }
    });
  });
}
