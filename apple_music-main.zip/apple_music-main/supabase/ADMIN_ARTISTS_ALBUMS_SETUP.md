# Admin Artists & Albums RLS Setup

## Summary

Added Row-Level Security (RLS) policies to the `artists` and `albums` tables to enable admin users to create and modify catalog entries during the song upload workflow.

## What Was Changed

### File: `supabase/admin_setup.sql`

Added four new policy sections after the songs policies:

1. **artists table RLS** (lines ~138-163)
   - SELECT: Public read access (everyone can view artists)
   - INSERT: Admin-only (only admins can create artists)
   - UPDATE: Admin-only (only admins can modify artists)
   - DELETE: Admin-only (only admins can remove artists)

2. **albums table RLS** (lines ~165-190)
   - SELECT: Public read access (everyone can view albums)
   - INSERT: Admin-only (only admins can create albums)
   - UPDATE: Admin-only (only admins can modify albums)
   - DELETE: Admin-only (only admins can remove albums)

## Policy Details

Each policy uses `public.is_admin()` to verify the authenticated user has the `admin` role in the `profiles` table. This function is defined in the same file and uses SECURITY DEFINER to safely check admin status without infinite recursion.

### Artists Policies

```sql
CREATE POLICY artists_select_public ON artists
  FOR SELECT USING (true);

CREATE POLICY artists_admin_insert ON artists
  FOR INSERT WITH CHECK (public.is_admin());

CREATE POLICY artists_admin_update ON artists
  FOR UPDATE USING (public.is_admin())
  WITH CHECK (public.is_admin());

CREATE POLICY artists_admin_delete ON artists
  FOR DELETE USING (public.is_admin());
```

### Albums Policies

```sql
CREATE POLICY albums_select_public ON albums
  FOR SELECT USING (true);

CREATE POLICY albums_admin_insert ON albums
  FOR INSERT WITH CHECK (public.is_admin());

CREATE POLICY albums_admin_update ON albums
  FOR UPDATE USING (public.is_admin())
  WITH CHECK (public.is_admin());

CREATE POLICY albums_admin_delete ON albums
  FOR DELETE USING (public.is_admin());
```

## How to Apply

### Option 1: If starting fresh
Run `supabase/admin_setup.sql` as instructed in CLAUDE.md — it now includes the artists/albums policies.

### Option 2: If admin_setup.sql was already run
Run only the new policies in your Supabase SQL Editor:

```sql
-- Run this in Supabase Dashboard > SQL Editor
ALTER TABLE artists ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS artists_select_public ON artists;
CREATE POLICY artists_select_public ON artists FOR SELECT USING (true);
DROP POLICY IF EXISTS artists_admin_insert ON artists;
CREATE POLICY artists_admin_insert ON artists FOR INSERT WITH CHECK (public.is_admin());
DROP POLICY IF EXISTS artists_admin_update ON artists;
CREATE POLICY artists_admin_update ON artists FOR UPDATE USING (public.is_admin()) WITH CHECK (public.is_admin());
DROP POLICY IF EXISTS artists_admin_delete ON artists;
CREATE POLICY artists_admin_delete ON artists FOR DELETE USING (public.is_admin());

ALTER TABLE albums ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS albums_select_public ON albums;
CREATE POLICY albums_select_public ON albums FOR SELECT USING (true);
DROP POLICY IF EXISTS albums_admin_insert ON albums;
CREATE POLICY albums_admin_insert ON albums FOR INSERT WITH CHECK (public.is_admin());
DROP POLICY IF EXISTS albums_admin_update ON albums;
CREATE POLICY albums_admin_update ON albums FOR UPDATE USING (public.is_admin()) WITH CHECK (public.is_admin());
DROP POLICY IF EXISTS albums_admin_delete ON albums;
CREATE POLICY albums_admin_delete ON albums FOR DELETE USING (public.is_admin());
```

## Impact on Upload Workflow

The admin song upload now flows through without RLS rejection:

1. ✅ Upload audio to `audio-files` bucket (Storage policies)
2. ✅ Upload artwork to `album-covers` bucket (Storage policies)
3. ✅ **Create or find artist** (new artists policies)
4. ✅ **Create or find album** (new albums policies)
5. ✅ Create song metadata (existing songs policies)
6. ✅ Publish song (existing songs policies)

## Security Model

- **Normal users**: Can read/view all artists and albums (public catalog), but cannot create, modify, or delete them
- **Admin users**: Can create, update, and delete artists and albums
- **Anonymous users**: Can read/view published content only
- **All writes**: Protected by `public.is_admin()` SECURITY DEFINER function that checks `profiles.role`

## Verification

To verify the policies are in place, run this query in Supabase SQL Editor:

```sql
SELECT schemaname, tablename, policyname, permissive, roles, qual, with_check
FROM pg_policies
WHERE tablename IN ('artists', 'albums')
ORDER BY tablename, policyname;
```

Expected output: 8 policies (4 per table: select_public, admin_insert, admin_update, admin_delete)
