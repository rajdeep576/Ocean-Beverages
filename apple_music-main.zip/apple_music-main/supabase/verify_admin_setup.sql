-- Admin Setup Verification Script
-- Run this in the Supabase SQL editor to diagnose upload issues

-- 1. Check if is_admin() function exists
SELECT
  routine_name,
  routine_definition
FROM information_schema.routines
WHERE routine_schema = 'public'
  AND routine_name = 'is_admin';

-- 2. Check profiles table structure
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_schema = 'public' AND table_name = 'profiles'
ORDER BY ordinal_position;

-- 3. Check your admin account
SELECT id, email, role, created_at
FROM profiles
WHERE email = 'admin@applmusic.com'
ORDER BY created_at DESC;

-- 4. Check storage policies
SELECT
  policy_name,
  definition
FROM pg_policies
WHERE schemaname = 'storage'
  AND tablename = 'objects'
ORDER BY policy_name;

-- 5. Check if is_published column exists on songs
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_schema = 'public'
  AND table_name = 'songs'
  AND column_name IN ('is_published', 'created_by', 'audio_path', 'cover_path', 'cover_url')
ORDER BY ordinal_position;

-- 6. Test is_admin() function (only works when logged in as admin)
-- Uncomment to test after signing in as admin:
-- SELECT public.is_admin();
