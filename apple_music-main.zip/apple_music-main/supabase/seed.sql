-- ============================================================
-- Apple Music Redesign — Sample Data Seed Script
-- ============================================================
-- Target: PostgreSQL (Supabase)
--
-- Run: paste into Supabase Dashboard > SQL Editor > New query > Run
--   (or: psql "$SUPABASE_DB_URL" -f supabase/seed.sql)
--
-- Contents: 3 artists, 6 albums, 28 tracks
--
-- ID strategy: fixed UUIDs are assigned explicitly so the
-- foreign keys below are guaranteed to match, and so re-running
-- this script is idempotent (ON CONFLICT DO UPDATE). See the
-- "Matching your real schema" note at the bottom — the FK
-- column names below are inferred, since no schema file exists
-- in this repo. Verify them before running.
-- ============================================================

-- ------------------------------------------------------------
-- 1. Artists
-- ------------------------------------------------------------
INSERT INTO artists (id, name, hero_image_url, bio, is_verified)
VALUES
  ('a1000000-0000-4000-8000-000000000001', 'Nova Vale',
   'https://picsum.photos/600/600',
   'Dream-pop architect layering analog synths with close-mic vocal layers. Based in Lisbon, three albums in, still writing everything in a single take.',
   true),
  ('a1000000-0000-4000-8000-000000000002', 'Kite Arcade',
   'https://picsum.photos/600/600',
   'Four-piece indie band out of Manchester. Built around a tape-saturated rhythm section and a rotating cast of guest vocalists.',
   true),
  ('a1000000-0000-4000-8000-000000000003', 'Marisol Vega',
   'https://picsum.photos/600/600',
   'Latin-jazz guitarist and producer. Blends nylon-string fingerstyle with modular synthesis, collaborating with vocalists across three continents.',
   true)
ON CONFLICT (id) DO UPDATE SET
  name           = EXCLUDED.name,
  hero_image_url = EXCLUDED.hero_image_url,
  bio            = EXCLUDED.bio,
  is_verified    = EXCLUDED.is_verified;

-- ------------------------------------------------------------
-- 2. Albums  (2 per artist)
-- ------------------------------------------------------------
INSERT INTO albums (id, title, cover_url, release_year, genre, artist_id)
VALUES
  -- Nova Vale
  ('b2000000-0000-4000-8000-000000000001', 'Paper Lanterns',   'https://picsum.photos/600/600', 2021, 'Dream Pop',      'a1000000-0000-4000-8000-000000000001'),
  ('b2000000-0000-4000-8000-000000000002', 'Slow Static',      'https://picsum.photos/600/600', 2024, 'Dream Pop',      'a1000000-0000-4000-8000-000000000001'),
  -- Kite Arcade
  ('b2000000-0000-4000-8000-000000000003', 'Long Player',      'https://picsum.photos/600/600', 2022, 'Indie Rock',     'a1000000-0000-4000-8000-000000000002'),
  ('b2000000-0000-4000-8000-000000000004', 'Wire and Tin',     'https://picsum.photos/600/600', 2025, 'Indie Rock',     'a1000000-0000-4000-8000-000000000002'),
  -- Marisol Vega
  ('b2000000-0000-4000-8000-000000000005', 'Cielo Roto',       'https://picsum.photos/600/600', 2023, 'Latin Jazz',     'a1000000-0000-4000-8000-000000000003'),
  ('b2000000-0000-4000-8000-000000000006', 'Casa de Colors',   'https://picsum.photos/600/600', 2025, 'Latin Jazz',     'a1000000-0000-4000-8000-000000000003')
ON CONFLICT (id) DO UPDATE SET
  title        = EXCLUDED.title,
  cover_url    = EXCLUDED.cover_url,
  release_year = EXCLUDED.release_year,
  genre        = EXCLUDED.genre,
  artist_id    = EXCLUDED.artist_id;

-- ------------------------------------------------------------
-- 3. Songs  (4-5 per album, ordered by track_number)
--
-- audio_url: full public HTTPS URLs. StorageHelper.getPublicUrl()
--   in lib/models/music_models.dart passes these through
--   unchanged (it returns early for paths starting with "http"),
--   so these bypass the audio-files bucket entirely and work
--   before you upload any audio to Supabase Storage.
--
--   If you later upload your own files, swap the value for a
--   BUCKET PATH (e.g. 'paper-lanterns/01-halcyon.mp3') and
--   it will resolve against the audio-files bucket instead.
--
-- duration_seconds: measured from the actual MP3 frame headers
--   of each file, not estimated.
-- ------------------------------------------------------------
INSERT INTO songs (id, title, duration_seconds, track_number, audio_url, album_id)
VALUES
  -- Album 1: Paper Lanterns (5 tracks)
  ('c3000000-0000-4000-8000-000000000001', 'Halcyon',          373, 1, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3', 'b2000000-0000-4000-8000-000000000001'),
  ('c3000000-0000-4000-8000-000000000002', 'Paper Lanterns',   426, 2, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3', 'b2000000-0000-4000-8000-000000000001'),
  ('c3000000-0000-4000-8000-000000000003', 'Low Tide Radio',   344, 3, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3', 'b2000000-0000-4000-8000-000000000001'),
  ('c3000000-0000-4000-8000-000000000004', 'Blue Hour',        303, 4, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3', 'b2000000-0000-4000-8000-000000000001'),
  ('c3000000-0000-4000-8000-000000000005', 'North Window',     354, 5, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3', 'b2000000-0000-4000-8000-000000000001'),

  -- Album 2: Slow Static (4 tracks)
  ('c3000000-0000-4000-8000-000000000006', 'Hum',              280, 1, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3', 'b2000000-0000-4000-8000-000000000002'),
  ('c3000000-0000-4000-8000-000000000007', 'Signal Lost',      421, 2, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3', 'b2000000-0000-4000-8000-000000000002'),
  ('c3000000-0000-4000-8000-000000000008', 'Fathoms',          325, 3, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3', 'b2000000-0000-4000-8000-000000000002'),
  ('c3000000-0000-4000-8000-000000000009', 'Antenna',          373, 4, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3', 'b2000000-0000-4000-8000-000000000002'),

  -- Album 3: Long Player (5 tracks)
  ('c3000000-0000-4000-8000-000000000010', 'Opening Credits',  426, 1, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3', 'b2000000-0000-4000-8000-000000000003'),
  ('c3000000-0000-4000-8000-000000000011', 'Cassette Culture', 344, 2, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3', 'b2000000-0000-4000-8000-000000000003'),
  ('c3000000-0000-4000-8000-000000000012', 'B-Side Blues',     303, 3, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3', 'b2000000-0000-4000-8000-000000000003'),
  ('c3000000-0000-4000-8000-000000000013', 'Side B',           354, 4, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3', 'b2000000-0000-4000-8000-000000000003'),
  ('c3000000-0000-4000-8000-000000000014', 'Fade to Grey',     280, 5, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3', 'b2000000-0000-4000-8000-000000000003'),

  -- Album 4: Wire and Tin (5 tracks)
  ('c3000000-0000-4000-8000-000000000015', 'Tin Roof',         421, 1, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3', 'b2000000-0000-4000-8000-000000000004'),
  ('c3000000-0000-4000-8000-000000000016', 'Copper Wire',      325, 2, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3', 'b2000000-0000-4000-8000-000000000004'),
  ('c3000000-0000-4000-8000-000000000017', 'Overhead',         373, 3, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3', 'b2000000-0000-4000-8000-000000000004'),
  ('c3000000-0000-4000-8000-000000000018', 'Live Wire',        426, 4, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3', 'b2000000-0000-4000-8000-000000000004'),
  ('c3000000-0000-4000-8000-000000000019', 'Solder',           344, 5, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3', 'b2000000-0000-4000-8000-000000000004'),

  -- Album 5: Cielo Roto (5 tracks)
  ('c3000000-0000-4000-8000-000000000020', 'Amanecer',         303, 1, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3', 'b2000000-0000-4000-8000-000000000005'),
  ('c3000000-0000-4000-8000-000000000021', 'Sal y Sol',        354, 2, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3', 'b2000000-0000-4000-8000-000000000005'),
  ('c3000000-0000-4000-8000-000000000022', 'Cielo Roto',       280, 3, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3', 'b2000000-0000-4000-8000-000000000005'),
  ('c3000000-0000-4000-8000-000000000023', 'Norte',            421, 4, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3', 'b2000000-0000-4000-8000-000000000005'),
  ('c3000000-0000-4000-8000-000000000024', 'Luz de Enero',     325, 5, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3', 'b2000000-0000-4000-8000-000000000005'),

  -- Album 6: Casa de Colores (4 tracks)
  ('c3000000-0000-4000-8000-000000000025', 'Casa de Colores', 373, 1, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3', 'b2000000-0000-4000-8000-000000000006'),
  ('c3000000-0000-4000-8000-000000000026', 'Verde',            426, 2, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3', 'b2000000-0000-4000-8000-000000000006'),
  ('c3000000-0000-4000-8000-000000000027', 'Azul',             344, 3, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3', 'b2000000-0000-4000-8000-000000000006'),
  ('c3000000-0000-4000-8000-000000000028', 'Rojo',             303, 4, 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3', 'b2000000-0000-4000-8000-000000000006')
ON CONFLICT (id) DO UPDATE SET
  title            = EXCLUDED.title,
  duration_seconds = EXCLUDED.duration_seconds,
  track_number     = EXCLUDED.track_number,
  audio_url        = EXCLUDED.audio_url,
  album_id         = EXCLUDED.album_id;

-- ------------------------------------------------------------
-- 4. Verify  --  expect: 3 artists, 6 albums, 28 songs
-- ------------------------------------------------------------
SELECT 'artists' AS entity, COUNT(*) FROM artists
UNION ALL SELECT 'albums',  COUNT(*) FROM albums
UNION ALL SELECT 'songs',   COUNT(*) FROM songs;
