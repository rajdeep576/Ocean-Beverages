-- Admin RLS policies for artists and albums tables
--
-- Enables admins to create, read, update, and delete artists and albums.
-- Normal users can only READ (for the public catalogue).
--
-- Run this in Supabase SQL Editor after running admin_setup.sql.

-- ---------------------------------------------------------------------------
-- 1. Artists table RLS
-- ---------------------------------------------------------------------------
-- Enable RLS on artists (if not already enabled)
ALTER TABLE artists ENABLE ROW LEVEL SECURITY;

-- SELECT: Everyone can read all artists (public catalogue)
DROP POLICY IF EXISTS artists_select_public ON artists;
CREATE POLICY artists_select_public ON artists
  FOR SELECT USING (true);

-- INSERT: Only admins can create artists
DROP POLICY IF EXISTS artists_admin_insert ON artists;
CREATE POLICY artists_admin_insert ON artists
  FOR INSERT WITH CHECK (public.is_admin());

-- UPDATE: Only admins can update artists
DROP POLICY IF EXISTS artists_admin_update ON artists;
CREATE POLICY artists_admin_update ON artists
  FOR UPDATE USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- DELETE: Only admins can delete artists
DROP POLICY IF EXISTS artists_admin_delete ON artists;
CREATE POLICY artists_admin_delete ON artists
  FOR DELETE USING (public.is_admin());


-- ---------------------------------------------------------------------------
-- 2. Albums table RLS
-- ---------------------------------------------------------------------------
-- Enable RLS on albums (if not already enabled)
ALTER TABLE albums ENABLE ROW LEVEL SECURITY;

-- SELECT: Everyone can read all albums (public catalogue)
DROP POLICY IF EXISTS albums_select_public ON albums;
CREATE POLICY albums_select_public ON albums
  FOR SELECT USING (true);

-- INSERT: Only admins can create albums
DROP POLICY IF EXISTS albums_admin_insert ON albums;
CREATE POLICY albums_admin_insert ON albums
  FOR INSERT WITH CHECK (public.is_admin());

-- UPDATE: Only admins can update albums
DROP POLICY IF EXISTS albums_admin_update ON albums;
CREATE POLICY albums_admin_update ON albums
  FOR UPDATE USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- DELETE: Only admins can delete albums
DROP POLICY IF EXISTS albums_admin_delete ON albums;
CREATE POLICY albums_admin_delete ON albums
  FOR DELETE USING (public.is_admin());


-- ---------------------------------------------------------------------------
-- 3. Verification
-- ---------------------------------------------------------------------------
-- List all policies on artists and albums to confirm they're in place
SELECT schemaname, tablename, policyname, permissive, roles, qual, with_check
FROM pg_policies
WHERE tablename IN ('artists', 'albums')
ORDER BY tablename, policyname;
