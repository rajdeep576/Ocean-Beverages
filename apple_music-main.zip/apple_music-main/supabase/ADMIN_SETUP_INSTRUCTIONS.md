# Admin Upload Setup Instructions

## Problem Diagnosis

The storage upload was being rejected due to **infinite recursion in RLS policies**.

### Root Cause
- `admin_storage.sql` used a direct `SELECT` from the `profiles` table within storage policies
- This caused Postgres to recursively evaluate its own RLS rules, which it blocks
- Solution: Use the `is_admin()` SECURITY DEFINER function instead

### Fix Applied
- ✅ Deleted conflicting `admin_storage.sql`
- ✅ Kept `admin_setup.sql` which has the correct policies using `is_admin()`

---

## Step-by-Step Setup

### 1. Run the Admin Setup SQL
In your Supabase SQL editor, run:
```sql
-- Copy and paste the contents of supabase/admin_setup.sql
```

**This creates:**
- `is_admin()` function (SECURITY DEFINER) — avoids infinite recursion
- Auto-creates profiles for new signups
- RLS policies for songs and storage buckets
- Storage policies for `audio-files` and `album-covers` buckets

### 2. Sign In Once
Sign into the Flutter app with your admin account:
- Email: `admin@applmusic.com`
- Password: `strongpassword`

This creates a profile row in the database.

### 3. Verify the Profile Exists
Run this query in Supabase SQL editor:
```sql
SELECT id, email, role FROM profiles ORDER BY created_at DESC;
```

You should see your admin account with `role = 'user'` (default).

### 4. Promote to Admin
Copy your UUID from the query above, then run:
```sql
UPDATE profiles SET role = 'admin' WHERE email = 'admin@applmusic.com';
```

Or by UUID (safer):
```sql
UPDATE profiles SET role = 'admin' WHERE id = '<your-uuid-here>';
```

### 5. Sign Out and Back In
- Sign out of the Flutter app
- Sign back in with the same credentials
- The app reads the role when the account sheet opens, but RLS evaluates against the session

---

## Verify Storage Policies

Run this in the Supabase SQL editor to confirm policies are in place:

```sql
SELECT policy_name, definition 
FROM pg_policies 
WHERE schemaname = 'storage' 
  AND tablename = 'objects'
ORDER BY policy_name;
```

You should see:
- `admin_audio_insert`
- `admin_audio_update`
- `admin_audio_delete`
- `admin_covers_insert`
- `admin_covers_update`
- `admin_covers_delete`

All should use `public.is_admin()` — not a direct SELECT from profiles.

---

## Troubleshooting

### "Storage rejected the upload" error
- ✅ Confirmed policies exist (query above)
- ✅ Admin role set to 'admin' (not 'user')
- ✅ Signed out and back in after role change
- **If still failing:** Check browser console for the exact error code

### "Run supabase/admin_setup.sql before uploading" error
- The `is_published` column is missing from the songs table
- Run `supabase/admin_setup.sql` again
- It's idempotent — safe to re-run

### Upload succeeds but track doesn't appear
- Check that `is_published` is `true` or you are logged in as admin
- Run: `SELECT id, title, is_published, created_by FROM songs ORDER BY created_at DESC;`
