-- Make the existing catalogue visible again. Run in the SQL editor.
--
-- WHY NO SONGS APPEAR
--   `songs.is_published` exists and every one of the 28 seeded tracks has it
--   set to false. admin_setup.sql adds the column as
--
--     ALTER TABLE songs ADD COLUMN is_published boolean NOT NULL DEFAULT false;
--
--   so every row that predates publishing landed as a draft. The app then asks
--   for published songs and gets an empty set — not an error, just zero rows,
--   which is why the app looked healthy while every shelf was blank.
--
--   The backfill at the bottom of admin_setup.sql exists for exactly this, but
--   it never ran on this project.
--
-- SCOPE
--   One UPDATE. No schema, policy or storage changes, so nothing else can be
--   disturbed. Songs uploaded later through the admin dashboard get their own
--   is_published from the upload form, so they are untouched by this.
--
-- Idempotent — re-running flips nothing, because the WHERE excludes rows
-- already published.


-- ---------------------------------------------------------------------------
-- 1. Publish everything currently unpublished
-- ---------------------------------------------------------------------------
-- Set to 'false' instead if you would rather mark seeded tracks as drafts and
-- publish them deliberately from the admin dashboard. That is the only reason
-- to change this line.

UPDATE songs SET is_published = true WHERE is_published = false;


-- ---------------------------------------------------------------------------
-- 2. Verify
-- ---------------------------------------------------------------------------
-- Expect 28. If this returns 0, the UPDATE did not match anything and the
-- column may have a different default than assumed.

SELECT count(*) AS published_songs FROM songs WHERE is_published = true;

-- The full picture, published and draft:

SELECT is_published, count(*) FROM songs GROUP BY is_published ORDER BY 1;


-- ---------------------------------------------------------------------------
-- 3. Then relaunch the app
-- ---------------------------------------------------------------------------
-- Browse's "Top Songs" and every other shelf read back immediately — no sign-in
-- needed, since these rows were already visible under the public read policy.