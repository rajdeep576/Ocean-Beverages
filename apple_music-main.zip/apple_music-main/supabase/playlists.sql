-- ============================================================
-- Apple Music Redesign — Playlists & Playlist Tracks
-- ============================================================
-- Target: PostgreSQL (Supabase)
--
-- Run: paste into Supabase Dashboard > SQL Editor > New query > Run
--
-- Why this file exists: `addSongToPlaylist` and `fetchUserPlaylists` are
-- already wired into the app, but the seed script only creates artists,
-- albums and songs. Without these two tables the Add-to-Playlist sheet has
-- nothing to list and no place to write to.
--
-- The (playlist_id, song_id) unique constraint is load-bearing, not
-- cosmetic: the repository upserts with
--   onConflict: 'playlist_id,song_id', ignoreDuplicates: true
-- so re-adding a track is a silent no-op rather than a duplicate-key error.
-- Without the constraint that upsert degrades to a plain insert and the app
-- will happily add the same song twice.
--
-- NOTE ON AN EXISTING playlist_songs TABLE
-- If the table already exists with a different shape, `CREATE TABLE IF NOT
-- EXISTS` below leaves it alone and the app will keep failing against it.
-- The live version of this table is (playlist_id, song_id, added_at) — no
-- `id`, no `position` — and `fetchSongsForPlaylist` is written against that.
-- Section 5 reports what is actually there, and aligns the table if it isn't.
-- ============================================================

-- ------------------------------------------------------------
-- 1. playlists
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS playlists (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES auth.users (id) ON DELETE CASCADE,
  title       TEXT NOT NULL,
  cover_url   TEXT,
  description TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Cheap per-user listing, which is the only query the sheet makes.
CREATE INDEX IF NOT EXISTS playlists_user_id_idx ON playlists (user_id);

-- ------------------------------------------------------------
-- 2. playlist_songs
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS playlist_songs (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  playlist_id UUID NOT NULL REFERENCES playlists (id) ON DELETE CASCADE,
  song_id     UUID NOT NULL REFERENCES songs (id) ON DELETE CASCADE,
  -- NULL means "play in stored order"; a number pins the track. Matches
  -- `songs.track_number` on the albums side.
  position    INTEGER,
  added_at    TIMESTAMPTZ NOT NULL DEFAULT now(),

  -- Conflict target for the app's upsert. See the note at the top.
  CONSTRAINT playlist_songs_playlist_id_song_id_key UNIQUE (playlist_id, song_id)
);

CREATE INDEX IF NOT EXISTS playlist_songs_playlist_id_idx
  ON playlist_songs (playlist_id);

-- ------------------------------------------------------------
-- 3. Row Level Security
-- ------------------------------------------------------------
-- Both tables are per-user. Without these policies the tables are readable
-- by anyone with the anon key, which for the publishable key in main.dart
-- means every signed-out visitor.
-- ------------------------------------------------------------
ALTER TABLE playlists       ENABLE ROW LEVEL SECURITY;
ALTER TABLE playlist_songs  ENABLE ROW LEVEL SECURITY;

-- playlists: full access to your own rows, read-only to nobody else's.
DROP POLICY IF EXISTS "playlists_select_own" ON playlists;
CREATE POLICY "playlists_select_own" ON playlists
  FOR SELECT USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "playlists_insert_own" ON playlists;
CREATE POLICY "playlists_insert_own" ON playlists
  FOR INSERT WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "playlists_update_own" ON playlists;
CREATE POLICY "playlists_update_own" ON playlists
  FOR UPDATE USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "playlists_delete_own" ON playlists;
CREATE POLICY "playlists_delete_own" ON playlists
  FOR DELETE USING (auth.uid() = user_id);

-- playlist_songs: gated on the parent playlist's owner rather than carrying
-- its own user_id, so there is exactly one place ownership is decided and a
-- row can't be inserted into someone else's list.
DROP POLICY IF EXISTS "playlist_songs_select_own" ON playlist_songs;
CREATE POLICY "playlist_songs_select_own" ON playlist_songs
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM playlists
      WHERE playlists.id = playlist_songs.playlist_id
        AND playlists.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "playlist_songs_insert_own" ON playlist_songs;
CREATE POLICY "playlist_songs_insert_own" ON playlist_songs
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM playlists
      WHERE playlists.id = playlist_songs.playlist_id
        AND playlists.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "playlist_songs_delete_own" ON playlist_songs;
CREATE POLICY "playlist_songs_delete_own" ON playlist_songs
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM playlists
      WHERE playlists.id = playlist_songs.playlist_id
        AND playlists.user_id = auth.uid()
    )
  );

-- ------------------------------------------------------------
-- 5. Verify the live schema matches what the app queries
--
-- `CREATE TABLE IF NOT EXISTS` is a no-op against a table that already
-- exists, so this file cannot repair a `playlist_songs` with the wrong
-- columns — the app simply keeps failing against it. The query that fails is
--
--   select('added_at, songs(*, albums(...))').order('added_at').order('song_id')
--
-- and PostgREST rejects the ENTIRE request if any named column is missing,
-- with 42703 "column playlist_songs.<name> does not exist". That surfaces in
-- the app as "Couldn't load this playlist" on every playlist, including ones
-- that are genuinely empty.
--
-- Run this section first. If the report shows the expected shape, the Dart
-- side is already correct and nothing needs changing.
-- ------------------------------------------------------------

-- The columns `playlist_songs` must have for the app's queries to parse.
-- Expect three rows: playlist_id, song_id, added_at.
SELECT
  a.attname AS column_name,
  format_type(a.atttypid, a.atttypmod) AS data_type
FROM pg_attribute a
WHERE a.attrelid = 'public.playlist_songs'::regclass
  AND a.attnum > 0
  AND NOT a.attisdropped
ORDER BY a.attnum;

-- Foreign keys the nested `songs(...)` embed is resolved through. Expect two
-- rows, both reporting playlist_id -> playlists and song_id -> songs.
SELECT
  c.conname                        AS fk_name,
  (SELECT attname FROM pg_attribute
     WHERE attrelid = c.conrelid AND attnum = c.conkey[1]) AS column_name,
  (SELECT relname FROM pg_class WHERE oid = c.confrelid) AS references_table,
  pg_get_constraintdef(c.oid)      AS definition
FROM pg_constraint c
WHERE c.conrelid = 'public.playlist_songs'::regclass
  AND c.contype = 'f'
ORDER BY c.conname;

-- The unique constraint the app's upsert conflicts against. Without this row,
-- `addSongToPlaylist` degrades to a plain insert and can add a duplicate.
SELECT
  indexname,
  indexdef
FROM pg_indexes
WHERE schemaname = 'public'
  AND tablename = 'playlist_songs'
  AND indexdef LIKE 'CREATE UNIQUE%';