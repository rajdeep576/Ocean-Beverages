-- Admin feature setup: roles, publishing, and the policies that gate them.
--
-- Run this in the Supabase SQL editor. It is additive and idempotent — it adds
-- columns, tables, a function, a trigger and policies, and drops nothing. Safe
-- to re-run.
--
-- BEFORE YOU START
--   1. Run this file.
--   2. Sign in to the app once so a profiles row exists for your account.
--   3. Run the bootstrap query at the very bottom of this file, replacing the
--      uuid with your own.
--
-- WHY THIS FILE REWRITES THE OLD ONE
--   The previous version asked each policy for
--     (SELECT role FROM profiles WHERE id = auth.uid())
--   including the policy ON profiles itself. That is self-referential RLS:
--   Postgres rejects it outright with "infinite recursion detected in policy
--   for relation profiles". The check now lives in a SECURITY DEFINER
--   function, which reads profiles while its policies are mid-evaluation
--   without recursing.
--
--   It also never inserted a profiles row, so even past the recursion the
--   lookup returned null and denied every admin. handle_new_user() below
--   fixes that for future signups; step 3 covers accounts that already exist.


-- ---------------------------------------------------------------------------
-- 1. Role lookup
-- ---------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'
  );
$$;

REVOKE ALL ON FUNCTION public.is_admin() FROM public;
GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated;

-- Make sure profiles exists and has an email column before the trigger uses it.
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text,
  role text NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin')),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE profiles ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS role text NOT NULL DEFAULT 'user';
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();

-- A profile row for every new signup, so is_admin() has something to read.
-- Without this a fresh account has no row, the lookup returns false, and the
-- admin screens deny everyone including the person who owns the account.
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email)
  VALUES (new.id, new.email)
  ON CONFLICT (id) DO NOTHING;
  RETURN new;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();


-- ---------------------------------------------------------------------------
-- 2. Songs: publishing and upload bookkeeping
-- ---------------------------------------------------------------------------
-- cover_url is per-song on purpose. Artwork normally lives on albums.cover_url
-- and Song.fromJson already falls back to songs.cover_url, so an uploaded
-- track can carry its own image without repainting the album it belongs to.

ALTER TABLE songs ADD COLUMN IF NOT EXISTS is_published boolean NOT NULL DEFAULT false;
ALTER TABLE songs ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES auth.users(id);
ALTER TABLE songs ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();

-- Bucket-relative paths, e.g. songs/<uuid>/audio.mp3. StorageHelper turns
-- these into public URLs on read; MusicRepository.deleteSong uses audio_path
-- to remove the object again. NULL for seeded tracks, whose audio_url is an
-- absolute SoundHelix URL.
ALTER TABLE songs ADD COLUMN IF NOT EXISTS audio_path text;
ALTER TABLE songs ADD COLUMN IF NOT EXISTS cover_path text;
ALTER TABLE songs ADD COLUMN IF NOT EXISTS cover_url text;

-- Everything published so far is already live in Browse and Search; marking it
-- draft here would empty the app on first login.
UPDATE songs SET is_published = true WHERE is_published = false;


-- ---------------------------------------------------------------------------
-- 3. Row level security
-- ---------------------------------------------------------------------------
-- On profiles. Note the WITH CHECK pins role to 'user': an admin is promoted
-- by the SQL at the bottom of this file, never from the app, or any user could
-- grant themselves the admin role through this same endpoint.

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS profiles_select_self_or_admin ON profiles;
CREATE POLICY profiles_select_self_or_admin ON profiles
  FOR SELECT USING (auth.uid() = id OR public.is_admin());

DROP POLICY IF EXISTS profiles_update_own ON profiles;
CREATE POLICY profiles_update_own ON profiles
  FOR UPDATE USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id AND role = 'user');

-- On songs. The SELECT policy deliberately admits published rows to everyone,
-- including signed-out visitors: enabling RLS here without it would lock the
-- public catalogue and break Browse for a signed-out user.

ALTER TABLE songs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS songs_select_published ON songs;
CREATE POLICY songs_select_published ON songs
  FOR SELECT USING (is_published OR public.is_admin());

DROP POLICY IF EXISTS songs_admin_all ON songs;
CREATE POLICY songs_admin_all ON songs
  FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

-- On artists. Admins can create and modify; everyone can read.
ALTER TABLE artists ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS artists_select_public ON artists;
CREATE POLICY artists_select_public ON artists
  FOR SELECT USING (true);

DROP POLICY IF EXISTS artists_admin_insert ON artists;
CREATE POLICY artists_admin_insert ON artists
  FOR INSERT WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS artists_admin_update ON artists;
CREATE POLICY artists_admin_update ON artists
  FOR UPDATE USING (public.is_admin())
  WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS artists_admin_delete ON artists;
CREATE POLICY artists_admin_delete ON artists
  FOR DELETE USING (public.is_admin());

-- On albums. Admins can create and modify; everyone can read.
ALTER TABLE albums ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS albums_select_public ON albums;
CREATE POLICY albums_select_public ON albums
  FOR SELECT USING (true);

DROP POLICY IF EXISTS albums_admin_insert ON albums;
CREATE POLICY albums_admin_insert ON albums
  FOR INSERT WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS albums_admin_update ON albums;
CREATE POLICY albums_admin_update ON albums
  FOR UPDATE USING (public.is_admin())
  WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS albums_admin_delete ON albums;
CREATE POLICY albums_admin_delete ON albums
  FOR DELETE USING (public.is_admin());


-- ---------------------------------------------------------------------------
-- 4. Storage policies
-- ---------------------------------------------------------------------------
-- Buckets stay public for reading — the player streams audio straight from a
-- public URL, so a read policy would have to cover the anon role anyway.
-- These govern writes only.

DROP POLICY IF EXISTS admin_audio_insert ON storage.objects;
CREATE POLICY admin_audio_insert ON storage.objects
  FOR INSERT WITH CHECK (
    bucket_id = 'audio-files' AND public.is_admin()
  );

DROP POLICY IF EXISTS admin_audio_update ON storage.objects;
CREATE POLICY admin_audio_update ON storage.objects
  FOR UPDATE USING (
    bucket_id = 'audio-files' AND public.is_admin()
  ) WITH CHECK (
    bucket_id = 'audio-files' AND public.is_admin()
  );

DROP POLICY IF EXISTS admin_audio_delete ON storage.objects;
CREATE POLICY admin_audio_delete ON storage.objects
  FOR DELETE USING (
    bucket_id = 'audio-files' AND public.is_admin()
  );

DROP POLICY IF EXISTS admin_covers_insert ON storage.objects;
CREATE POLICY admin_covers_insert ON storage.objects
  FOR INSERT WITH CHECK (
    bucket_id = 'album-covers' AND public.is_admin()
  );

DROP POLICY IF EXISTS admin_covers_update ON storage.objects;
CREATE POLICY admin_covers_update ON storage.objects
  FOR UPDATE USING (
    bucket_id = 'album-covers' AND public.is_admin()
  ) WITH CHECK (
    bucket_id = 'album-covers' AND public.is_admin()
  );

DROP POLICY IF EXISTS admin_covers_delete ON storage.objects;
CREATE POLICY admin_covers_delete ON storage.objects
  FOR DELETE USING (
    bucket_id = 'album-covers' AND public.is_admin()
  );


-- ---------------------------------------------------------------------------
-- 5. Promote your account to admin
-- ---------------------------------------------------------------------------
-- Run this SEPARATELY, after signing in once. Find your id with:
--
--   select id, email, role from profiles order by created_at;
--
-- then:
--
--   update profiles set role = 'admin' where email = 'you@example.com';
--
-- Sign out and back in on the device afterwards — the account sheet reads the
-- role when it opens, but the session itself is what RLS evaluates.