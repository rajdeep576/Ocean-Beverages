-- Restore song loading. Run this in the Supabase SQL editor.
--
-- WHY SONGS STOPPED LOADING
--   Every read of `songs` (and of `profiles`) fails with:
--
--     500 42P17  infinite recursion detected in policy for relation "profiles"
--
--   That is server-side, not a Dart bug. The `songs` table became unreadable
--   for every client, so Listen Now, Search, albums' tracklists and the
--   queue all came back empty. Artists and Albums still load because their
--   policies are fine — which is why the app looked partly alive.
--
--   The cause is a self-referential RLS policy:
--
--     CREATE POLICY profiles_select_self_or_admin ON profiles
--       FOR SELECT USING (
--         auth.uid() = id
--         OR (SELECT role FROM profiles WHERE id = auth.uid()) = 'admin'
--       );
--
--   Evaluating that policy on `profiles` requires reading `profiles`, which
--   re-enters the same policy. Postgres detects the loop and refuses the query
--   rather than recursing.
--
-- THE FIX
--   Move the role lookup into a SECURITY DEFINER function. A definer function
--   runs with the owner's rights and its own search_path, so it reads
--   `profiles` while the policy is mid-evaluation without re-entering RLS on
--   it. Policies then call public.is_admin().
--
-- SCOPE — DELIBERATELY MINIMAL
--   This file touches policies and nothing else. It adds NO columns, so it
--   cannot make the `is_published` / `audio_path` state any worse than it
--   already is. Applying supabase/admin_setup.sql afterwards adds the
--   publishing columns and swaps these policies for the publishing-aware ones;
--   it drops `songs_public_read` first, so the two files compose cleanly.
--
-- Idempotent — safe to re-run.


-- ---------------------------------------------------------------------------
-- 1. The role lookup, out of the policy's way
-- ---------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'
  );
$$;

REVOKE ALL ON FUNCTION public.is_admin() FROM public;
GRANT EXECUTE ON FUNCTION public.is_admin() TO authenticated;


-- ---------------------------------------------------------------------------
-- 2. Replace the recursive policies
-- ---------------------------------------------------------------------------

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS profiles_select_self_or_admin ON profiles;
CREATE POLICY profiles_select_self_or_admin ON profiles
  FOR SELECT USING (auth.uid() = id OR public.is_admin());

-- WITH CHECK pins role to 'user' on self-service updates: an admin is granted
-- by SQL, never from the app, or any user could promote themselves through
-- this same endpoint.
DROP POLICY IF EXISTS profiles_update_own ON profiles;
CREATE POLICY profiles_update_own ON profiles
  FOR UPDATE USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id AND role = 'user');

-- `songs_public_read` is deliberately USING (true): the catalogue has to stay
-- readable to signed-out visitors, which is how the app behaved before and
-- how just_audio streams the audio URLs.
ALTER TABLE songs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS songs_public_read ON songs;
CREATE POLICY songs_public_read ON songs FOR SELECT USING (true);

DROP POLICY IF EXISTS songs_select_published ON songs;
DROP POLICY IF EXISTS songs_admin_all ON songs;
CREATE POLICY songs_admin_all ON songs
  FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());


-- ---------------------------------------------------------------------------
-- 3. Verify
-- ---------------------------------------------------------------------------
-- songs must report rows now (expect 28 for the seeded catalogue), and this
-- query must return no rows. If it does, there is still a recursive policy
-- somewhere else in the project.
--
--   SELECT count(*) FROM songs;
--
--   SELECT count(*) FROM pg_policies
--    WHERE schemaname = 'public'
--      AND qual LIKE '%FROM profiles WHERE%';
--
-- Both should come back clean. Then relaunch the app: Listen Now, Search,
-- an album's tracklist and the queue should all populate again.


-- ---------------------------------------------------------------------------
-- LATER: promote your account to admin
-- ---------------------------------------------------------------------------
--   update profiles set role = 'admin' where email = 'you@example.com';
--
-- Sign out and back in on the device afterwards. The account sheet reads the
-- role when it opens, but the session is what RLS evaluates.